# Shut the Box (Cierra la caja)

Juego de dados tradicional para Android. Sin Internet, sin publicidad, en castellano.

Modos: partida individual, de 2 a 4 jugadores en el mismo móvil (sin conexión) y de 2 a 4 móviles en la misma WiFi.
Cada jugador pone su nombre y su foto; cuando a alguien le toca suena una campana y vibra el móvil,
y cuando alguien se queda sin jugada los personajes se burlan de él con su cara.

## Compilar
Al subir el proyecto a GitHub, la acción **Compilar APK** se ejecuta sola:
1. Valida la lógica del juego (`node tests/logic.test.js`).
2. Compila el APK.
3. Lo publica en **Releases** como `ShutTheBox.apk`, listo para descargar e instalar.

También se puede lanzar a mano desde *Actions → Compilar APK → Run workflow*.

## Estructura
- `app/src/main/assets/js/logic.js` – reglas del juego (independiente de la interfaz).
- `app/src/main/assets/js/netgame.js` – reglas de la partida de varios jugadores (turnos, eliminación, clasificación).
- `app/src/main/assets/js/net.js` – partida en el mismo móvil y en red (anfitrión / invitados).
- `app/src/main/assets/js/photo.js` – foto de cada jugador y encuadre de la cara.
- `app/src/main/assets/characters/characters.js` – **personajes que se burlan** (aquí se ponen los definitivos).
- `app/src/main/java/.../NetBridge.java` – conexión entre móviles (TCP + búsqueda automática por UDP).
- `app/src/main/assets/js/ui.js` – pantallas, animaciones y flujo de partida.
- `app/src/main/assets/js/audio.js` – sonidos sintetizados (dados, fichas, victoria).
- `app/src/main/assets/js/storage.js` – estadísticas y récord guardados en el móvil.
- `app/src/main/assets/css/style.css` – estética de madera, fieltro y latón.
- `app/src/main/java/.../MainActivity.java` – contenedor Android.
- `tests/netgame.test.js` – validación de la partida de varios jugadores.
- `tests/logic.test.js` – validación: combinaciones, repetidos, fin de partida, victoria, puntuación y reinicio.

Para probarlo en un ordenador basta con abrir `app/src/main/assets/index.html` en el navegador.
