/*
 * PERSONAJES QUE SE BURLAN DEL JUGADOR
 * -----------------------------------
 * Estos dos son PROVISIONALES. Para poner los tuyos:
 *   1. Copia sus imágenes (PNG con fondo transparente) en esta carpeta, p. ej. characters/pepe.png
 *   2. Añade una entrada con  img: 'characters/pepe.png'  en lugar de  svg.
 *   3. Escribe sus frases. {nombre} se cambia por el nombre del jugador y {puntos} por su puntuación.
 */
window.STB_CHARACTERS = [
  {
    id: 'dado',
    name: 'Don Dado',
    svg:
      '<svg viewBox="0 0 120 160" xmlns="http://www.w3.org/2000/svg">' +
      '<line x1="22" y1="70" x2="4" y2="44" stroke="#3a2210" stroke-width="7" stroke-linecap="round"/>' +
      '<line x1="98" y1="70" x2="116" y2="96" stroke="#3a2210" stroke-width="7" stroke-linecap="round"/>' +
      '<circle cx="4" cy="42" r="7" fill="#f7f2e8" stroke="#3a2210" stroke-width="3"/>' +
      '<circle cx="116" cy="98" r="7" fill="#f7f2e8" stroke="#3a2210" stroke-width="3"/>' +
      '<line x1="45" y1="118" x2="40" y2="150" stroke="#3a2210" stroke-width="7" stroke-linecap="round"/>' +
      '<line x1="75" y1="118" x2="82" y2="150" stroke="#3a2210" stroke-width="7" stroke-linecap="round"/>' +
      '<ellipse cx="36" cy="153" rx="12" ry="5" fill="#3a2210"/><ellipse cx="86" cy="153" rx="12" ry="5" fill="#3a2210"/>' +
      '<rect x="18" y="20" width="84" height="100" rx="18" fill="#f7f2e8" stroke="#3a2210" stroke-width="4"/>' +
      '<circle cx="34" cy="34" r="5" fill="#1a1a1a"/><circle cx="86" cy="34" r="5" fill="#1a1a1a"/>' +
      '<circle cx="34" cy="106" r="5" fill="#1a1a1a"/><circle cx="86" cy="106" r="5" fill="#1a1a1a"/>' +
      '<path d="M38 58 q8 -10 16 0" fill="none" stroke="#1a1a1a" stroke-width="4" stroke-linecap="round"/>' +
      '<path d="M66 58 q8 -10 16 0" fill="none" stroke="#1a1a1a" stroke-width="4" stroke-linecap="round"/>' +
      '<path d="M38 72 q22 34 44 0 z" fill="#7a1d1d" stroke="#1a1a1a" stroke-width="3" stroke-linejoin="round"/>' +
      '<path d="M44 74 h32" stroke="#fff" stroke-width="5"/>' +
      '<ellipse cx="60" cy="88" rx="9" ry="4" fill="#e06666"/>' +
      '<path d="M30 10 l12 8 M90 10 l-12 8" stroke="#3a2210" stroke-width="3" stroke-linecap="round"/>' +
      '</svg>',
    phrases: [
      '¡Ja, ja, ja! ¡{nombre} se queda con {puntos} puntos!',
      '¿{puntos}? ¡Yo saco más durmiendo!',
      '¡Pa’ casa, {nombre}! ¡Pa’ casa!',
      '¡Los dados no te quieren hoy, {nombre}!'
    ]
  },
  {
    id: 'ficha',
    name: 'La Nueve',
    svg:
      '<svg viewBox="0 0 120 160" xmlns="http://www.w3.org/2000/svg">' +
      '<line x1="30" y1="66" x2="8" y2="88" stroke="#5a3218" stroke-width="7" stroke-linecap="round"/>' +
      '<line x1="90" y1="66" x2="112" y2="40" stroke="#5a3218" stroke-width="7" stroke-linecap="round"/>' +
      '<circle cx="8" cy="90" r="7" fill="#ecd2a3" stroke="#5a3218" stroke-width="3"/>' +
      '<circle cx="112" cy="38" r="7" fill="#ecd2a3" stroke="#5a3218" stroke-width="3"/>' +
      '<line x1="48" y1="140" x2="44" y2="154" stroke="#5a3218" stroke-width="7" stroke-linecap="round"/>' +
      '<line x1="72" y1="140" x2="78" y2="154" stroke="#5a3218" stroke-width="7" stroke-linecap="round"/>' +
      '<rect x="28" y="6" width="64" height="136" rx="8" fill="#ddb57f" stroke="#5a3218" stroke-width="4"/>' +
      '<path d="M34 20 v110 M46 12 v126 M76 12 v126" stroke="#c59660" stroke-width="2" opacity=".6"/>' +
      '<text x="60" y="52" font-family="Georgia,serif" font-size="40" font-weight="bold" text-anchor="middle" fill="#4b2a11">9</text>' +
      '<path d="M40 76 q6 -8 12 0 M68 76 q6 -8 12 0" fill="none" stroke="#1a1a1a" stroke-width="4" stroke-linecap="round"/>' +
      '<path d="M42 88 q18 30 36 0 z" fill="#7a1d1d" stroke="#1a1a1a" stroke-width="3" stroke-linejoin="round"/>' +
      '<path d="M47 90 h26" stroke="#fff" stroke-width="4"/>' +
      '<circle cx="36" cy="92" r="5" fill="#e88" opacity=".6"/><circle cx="84" cy="92" r="5" fill="#e88" opacity=".6"/>' +
      '</svg>',
    phrases: [
      '¡Esa caja sigue más abierta que un bar en fiestas!',
      '¡Mírale la cara a {nombre}! ¡Ja, ja!',
      '{puntos} puntos… ¡qué desastre, {nombre}!',
      '¡A mí no me abates tú ni en sueños!'
    ]
  }
];
