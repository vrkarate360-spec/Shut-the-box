/*
 * DISFRACES PARA LAS BURLAS
 * -------------------------
 * Cuando un jugador se queda sin jugada aparece con su cara dentro de uno de estos disfraces,
 * bailando, mientras el disfraz se burla de él.
 * Cada disfraz está separado en cabeza y cuerpo (carpeta disfraces/) para poder animarlo.
 *  - face: posición del óvalo de la cara (x, y, ancho, alto) en píxeles de la imagen
 *  - neck: punto sobre el que gira la cabeza
 *  - dance: sway (contoneo) · bounce (saltitos) · stomp (pisotones) · shake (temblor) · float (flotar)
 *  - phrases: {nombre} = nombre del jugador, {puntos} = su puntuación
 */
window.STB_COSTUMES = [
 {
  "id": "flamenca",
  "name": "La Flamenca",
  "dance": "sway",
  "w": 583,
  "h": 760,
  "face": [
   215.1,
   103.6,
   141.2,
   194.6
  ],
  "neck": [
   285.7,
   300.2
  ],
  "body": "characters/disfraces/flamenca_cuerpo.webp",
  "head": "characters/disfraces/flamenca_cabeza.webp",
  "phrases": [
   "¡Olé, olé! {nombre} se marca unas sevillanas con {puntos} puntos.",
   "¡Arsa! Con {puntos} puntos mejor dedícate al baile, {nombre}."
  ]
 },
 {
  "id": "policia_rizos",
  "name": "La Agente",
  "dance": "bounce",
  "w": 480,
  "h": 760,
  "face": [
   144.5,
   123.2,
   179.8,
   291.7
  ],
  "neck": [
   234.5,
   417.0
  ],
  "body": "characters/disfraces/policia_rizos_cuerpo.webp",
  "head": "characters/disfraces/policia_rizos_cabeza.webp",
  "phrases": [
   "¡Alto ahí, {nombre}! {puntos} puntos de multa por jugar tan mal.",
   "¡Documentación! Con {puntos} puntos queda usted detenido."
  ]
 },
 {
  "id": "torero",
  "name": "El Torero",
  "dance": "sway",
  "w": 474,
  "h": 760,
  "face": [
   89.8,
   105.7,
   181.5,
   303.9
  ],
  "neck": [
   180.5,
   411.6
  ],
  "body": "characters/disfraces/torero_cuerpo.webp",
  "head": "characters/disfraces/torero_cabeza.webp",
  "phrases": [
   "¡Olé! Los dados te han dado una cornada de {puntos} puntos.",
   "¡{nombre}, al callejón! Con {puntos} puntos no sales por la puerta grande."
  ]
 },
 {
  "id": "policia",
  "name": "El Guardia",
  "dance": "stomp",
  "w": 321,
  "h": 760,
  "face": [
   56.6,
   144.5,
   190.5,
   285.1
  ],
  "neck": [
   151.9,
   431.6
  ],
  "body": "characters/disfraces/policia_cuerpo.webp",
  "head": "characters/disfraces/policia_cabeza.webp",
  "phrases": [
   "¡Circule, {nombre}! Aquí no hay nada que cerrar.",
   "{puntos} puntos… ¡Esto es un delito, {nombre}!"
  ]
 },
 {
  "id": "abeja",
  "name": "La Abeja",
  "dance": "float",
  "w": 616,
  "h": 760,
  "face": [
   173.5,
   129.3,
   147.1,
   259.3
  ],
  "neck": [
   247.1,
   390.6
  ],
  "body": "characters/disfraces/abeja_cuerpo.webp",
  "head": "characters/disfraces/abeja_cabeza.webp",
  "phrases": [
   "¡Bzzz! {nombre} se ha quedado zumbando con {puntos} puntos.",
   "¡Qué picadura, {nombre}! {puntos} puntos."
  ]
 },
 {
  "id": "vaca",
  "name": "La Vaca",
  "dance": "bounce",
  "w": 550,
  "h": 760,
  "face": [
   117.4,
   75.2,
   193.3,
   321.3
  ],
  "neck": [
   214.1,
   398.5
  ],
  "body": "characters/disfraces/vaca_cuerpo.webp",
  "head": "characters/disfraces/vaca_cabeza.webp",
  "phrases": [
   "¡Muuuu! {nombre} se queda pastando con {puntos} puntos.",
   "¡A ordeñar, {nombre}! Que con {puntos} puntos no ganas."
  ]
 },
 {
  "id": "astronauta",
  "name": "El Astronauta",
  "dance": "float",
  "w": 629,
  "h": 760,
  "face": [
   181.1,
   19.2,
   211.5,
   290.1
  ],
  "neck": [
   286.8,
   311.3
  ],
  "body": "characters/disfraces/astronauta_cuerpo.webp",
  "head": "characters/disfraces/astronauta_cabeza.webp",
  "phrases": [
   "Houston, tenemos un problema: {nombre} ha sacado {puntos}.",
   "{nombre} está en la Luna… ¡{puntos} puntos!"
  ]
 },
 {
  "id": "pirata",
  "name": "El Pirata",
  "dance": "sway",
  "w": 373,
  "h": 760,
  "face": [
   126.0,
   102.9,
   153.7,
   240.8
  ],
  "neck": [
   202.9,
   345.7
  ],
  "body": "characters/disfraces/pirata_cuerpo.webp",
  "head": "characters/disfraces/pirata_cabeza.webp",
  "phrases": [
   "¡Arrr! ¡{nombre} al agua con {puntos} puntos!",
   "¡Por mil barriles! {puntos} puntos y ni un doblón."
  ]
 },
 {
  "id": "chef",
  "name": "El Cocinero",
  "dance": "shake",
  "w": 595,
  "h": 760,
  "face": [
   272.6,
   168.2,
   150.9,
   240.0
  ],
  "neck": [
   348.1,
   410.3
  ],
  "body": "characters/disfraces/chef_cuerpo.webp",
  "head": "characters/disfraces/chef_cabeza.webp",
  "phrases": [
   "¡Marchando una de {puntos} puntos bien quemada para {nombre}!",
   "¡A la sartén, {nombre}! Con {puntos} puntos estás frito."
  ]
 },
 {
  "id": "ninja",
  "name": "El Ninja",
  "dance": "stomp",
  "w": 503,
  "h": 760,
  "face": [
   64.2,
   38.1,
   273.4,
   358.9
  ],
  "neck": [
   200.9,
   399.0
  ],
  "body": "characters/disfraces/ninja_cuerpo.webp",
  "head": "characters/disfraces/ninja_cabeza.webp",
  "phrases": [
   "{nombre} quería pasar desapercibido… pero sus {puntos} puntos se ven desde lejos.",
   "¡Hiá! Golpe ninja de {puntos} puntos."
  ]
 },
 {
  "id": "payaso",
  "name": "El Bufón",
  "dance": "bounce",
  "w": 600,
  "h": 760,
  "face": [
   239.5,
   102.3,
   156.4,
   255.3
  ],
  "neck": [
   317.7,
   359.6
  ],
  "body": "characters/disfraces/payaso_cuerpo.webp",
  "head": "characters/disfraces/payaso_cabeza.webp",
  "phrases": [
   "¡Pero qué payasada, {nombre}! ¡{puntos} puntos!",
   "¡Que pase el siguiente! {nombre} ya ha hecho el ridículo."
  ]
 },
 {
  "id": "dinosaurio",
  "name": "El Dinosaurio",
  "dance": "stomp",
  "w": 693,
  "h": 760,
  "face": [
   128.1,
   87.8,
   171.7,
   268.7
  ],
  "neck": [
   213.9,
   358.6
  ],
  "body": "characters/disfraces/dinosaurio_cuerpo.webp",
  "head": "characters/disfraces/dinosaurio_cabeza.webp",
  "phrases": [
   "¡Grrr! {nombre} juega como en el Jurásico: {puntos} puntos.",
   "¡Extinguido! {nombre} se queda con {puntos} puntos."
  ]
 },
 {
  "id": "mariachi",
  "name": "El Mariachi",
  "dance": "sway",
  "w": 620,
  "h": 760,
  "face": [
   254.9,
   126.1,
   154.0,
   293.4
  ],
  "neck": [
   331.9,
   421.5
  ],
  "body": "characters/disfraces/mariachi_cuerpo.webp",
  "head": "characters/disfraces/mariachi_cabeza.webp",
  "phrases": [
   "♪ Ay, ay, ay… ¡{puntos} puntos, {nombre}! ♪",
   "¡Ándale, {nombre}! Esos {puntos} puntos merecen serenata."
  ]
 }
];
