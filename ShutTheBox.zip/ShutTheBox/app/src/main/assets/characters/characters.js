/*
 * DISFRACES PARA LAS BURLAS
 * -------------------------
 * Cuando un jugador se queda sin jugada aparece con su cara dentro de uno de estos disfraces,
 * bailando, mientras el disfraz se burla de él.
 * Cada disfraz está separado en cabeza y cuerpo (carpeta disfraces/) para poder animarlo.
 *  - face: posición del óvalo de la cara (x, y, ancho, alto) en píxeles de la imagen
 *  - neck: punto sobre el que gira la cabeza
 *  - dance: sway (contoneo) · bounce (saltitos) · stomp (pisotones) · shake (temblor) · float (flotar)
 *  - voice: número de las frases grabadas (carpeta voces/es, voces/en, voces/da; textos en voces/voces.js)
 */
window.STB_COSTUMES = [
 {
  "id": "flamenca",
  "name": {
   "es": "La Flamenca",
   "en": "The Flamenco Dancer",
   "da": "Flamencodanseren"
  },
  "dance": "sway",
  "w": 583,
  "h": 760,
  "face": [
   215.1,
   103.6,
   141.2,
   194.6
  ],
  "neck": [
   285.7,
   300.2
  ],
  "body": "characters/disfraces/flamenca_cuerpo.webp",
  "head": "characters/disfraces/flamenca_cabeza.webp",
  "voice": [
   0,
   1
  ]
 },
 {
  "id": "policia_rizos",
  "name": {
   "es": "La Agente",
   "en": "The Officer",
   "da": "Betjenten"
  },
  "dance": "bounce",
  "w": 480,
  "h": 760,
  "face": [
   144.5,
   123.2,
   179.8,
   291.7
  ],
  "neck": [
   234.5,
   417.0
  ],
  "body": "characters/disfraces/policia_rizos_cuerpo.webp",
  "head": "characters/disfraces/policia_rizos_cabeza.webp",
  "voice": [
   2,
   3
  ]
 },
 {
  "id": "torero",
  "name": {
   "es": "El Torero",
   "en": "The Bullfighter",
   "da": "Tyrefægteren"
  },
  "dance": "sway",
  "w": 474,
  "h": 760,
  "face": [
   89.8,
   105.7,
   181.5,
   303.9
  ],
  "neck": [
   180.5,
   411.6
  ],
  "body": "characters/disfraces/torero_cuerpo.webp",
  "head": "characters/disfraces/torero_cabeza.webp",
  "voice": [
   4,
   5
  ]
 },
 {
  "id": "policia",
  "name": {
   "es": "El Guardia",
   "en": "The Cop",
   "da": "Politimanden"
  },
  "dance": "stomp",
  "w": 321,
  "h": 760,
  "face": [
   56.6,
   144.5,
   190.5,
   285.1
  ],
  "neck": [
   151.9,
   431.6
  ],
  "body": "characters/disfraces/policia_cuerpo.webp",
  "head": "characters/disfraces/policia_cabeza.webp",
  "voice": [
   6,
   7
  ]
 },
 {
  "id": "abeja",
  "name": {
   "es": "La Abeja",
   "en": "The Bee",
   "da": "Bien"
  },
  "dance": "float",
  "w": 616,
  "h": 760,
  "face": [
   173.5,
   129.3,
   147.1,
   259.3
  ],
  "neck": [
   247.1,
   390.6
  ],
  "body": "characters/disfraces/abeja_cuerpo.webp",
  "head": "characters/disfraces/abeja_cabeza.webp",
  "voice": [
   8,
   9
  ]
 },
 {
  "id": "vaca",
  "name": {
   "es": "La Vaca",
   "en": "The Cow",
   "da": "Koen"
  },
  "dance": "bounce",
  "w": 550,
  "h": 760,
  "face": [
   117.4,
   75.2,
   193.3,
   321.3
  ],
  "neck": [
   214.1,
   398.5
  ],
  "body": "characters/disfraces/vaca_cuerpo.webp",
  "head": "characters/disfraces/vaca_cabeza.webp",
  "voice": [
   10,
   11
  ]
 },
 {
  "id": "astronauta",
  "name": {
   "es": "El Astronauta",
   "en": "The Astronaut",
   "da": "Astronauten"
  },
  "dance": "float",
  "w": 629,
  "h": 760,
  "face": [
   181.1,
   19.2,
   211.5,
   290.1
  ],
  "neck": [
   286.8,
   311.3
  ],
  "body": "characters/disfraces/astronauta_cuerpo.webp",
  "head": "characters/disfraces/astronauta_cabeza.webp",
  "voice": [
   12,
   13
  ]
 },
 {
  "id": "pirata",
  "name": {
   "es": "El Pirata",
   "en": "The Pirate",
   "da": "Piraten"
  },
  "dance": "sway",
  "w": 373,
  "h": 760,
  "face": [
   126.0,
   102.9,
   153.7,
   240.8
  ],
  "neck": [
   202.9,
   345.7
  ],
  "body": "characters/disfraces/pirata_cuerpo.webp",
  "head": "characters/disfraces/pirata_cabeza.webp",
  "voice": [
   14,
   15
  ]
 },
 {
  "id": "chef",
  "name": {
   "es": "El Cocinero",
   "en": "The Chef",
   "da": "Kokken"
  },
  "dance": "shake",
  "w": 595,
  "h": 760,
  "face": [
   272.6,
   168.2,
   150.9,
   240.0
  ],
  "neck": [
   348.1,
   410.3
  ],
  "body": "characters/disfraces/chef_cuerpo.webp",
  "head": "characters/disfraces/chef_cabeza.webp",
  "voice": [
   16,
   17
  ]
 },
 {
  "id": "ninja",
  "name": {
   "es": "El Ninja",
   "en": "The Ninja",
   "da": "Ninjaen"
  },
  "dance": "stomp",
  "w": 503,
  "h": 760,
  "face": [
   64.2,
   38.1,
   273.4,
   358.9
  ],
  "neck": [
   200.9,
   399.0
  ],
  "body": "characters/disfraces/ninja_cuerpo.webp",
  "head": "characters/disfraces/ninja_cabeza.webp",
  "voice": [
   18,
   19
  ]
 },
 {
  "id": "payaso",
  "name": {
   "es": "El Bufón",
   "en": "The Jester",
   "da": "Narren"
  },
  "dance": "bounce",
  "w": 600,
  "h": 760,
  "face": [
   239.5,
   102.3,
   156.4,
   255.3
  ],
  "neck": [
   317.7,
   359.6
  ],
  "body": "characters/disfraces/payaso_cuerpo.webp",
  "head": "characters/disfraces/payaso_cabeza.webp",
  "voice": [
   20,
   21
  ]
 },
 {
  "id": "dinosaurio",
  "name": {
   "es": "El Dinosaurio",
   "en": "The Dinosaur",
   "da": "Dinosauren"
  },
  "dance": "stomp",
  "w": 693,
  "h": 760,
  "face": [
   128.1,
   87.8,
   171.7,
   268.7
  ],
  "neck": [
   213.9,
   358.6
  ],
  "body": "characters/disfraces/dinosaurio_cuerpo.webp",
  "head": "characters/disfraces/dinosaurio_cabeza.webp",
  "voice": [
   22,
   23
  ]
 },
 {
  "id": "mariachi",
  "name": {
   "es": "El Mariachi",
   "en": "The Mariachi",
   "da": "Mariachien"
  },
  "dance": "sway",
  "w": 620,
  "h": 760,
  "face": [
   254.9,
   126.1,
   154.0,
   293.4
  ],
  "neck": [
   331.9,
   421.5
  ],
  "body": "characters/disfraces/mariachi_cuerpo.webp",
  "head": "characters/disfraces/mariachi_cabeza.webp",
  "voice": [
   24,
   25
  ]
 }
];
