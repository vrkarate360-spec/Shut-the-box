/*
 * Shut the Box — partida en red (2 a 4 jugadores). Lógica pura, la ejecuta el móvil anfitrión.
 *
 * Reglas de la partida en red:
 *  - Cada jugador tiene su propia caja con las nueve fichas.
 *  - El turno rota tirada a tirada: el jugador lanza, abate fichas y pasa el turno.
 *  - Si un jugador saca una tirada sin combinación posible, queda eliminado con su puntuación.
 *  - Si alguien cierra la caja (abate los nueve números), gana al momento: victoria perfecta.
 *  - Si no, cuando todos han terminado gana la puntuación más baja.
 */
(function (root) {
  'use strict';

  var L = (typeof module !== 'undefined' && module.exports) ? require('./logic.js') : root.STBLogic;
  var MAX_PLAYERS = 4;

  function NetMatch(players, opts) {
    opts = opts || {};
    if (players.length < 2 || players.length > MAX_PLAYERS) throw new Error('Se necesitan de 2 a 4 jugadores');
    var rng = opts.rng || Math.random;
    this.oneDieRule = !!opts.oneDieRule;
    this.players = players.map(function (p) {
      return {
        id: p.id, name: p.name,
        game: new L.Game({ rng: rng, oneDieRule: opts.oneDieRule }),
        finished: false, disconnected: false, won: false
      };
    });
    this.current = 0;
    this.phase = 'playing';     // playing | ended
    this.pending = null;        // null | 'advance' | 'end'  (pausa para que se vean las animaciones)
    this.seq = 1;
    this.event = { type: 'start', player: this.players[0].id };
  }

  NetMatch.prototype.index = function (id) {
    for (var i = 0; i < this.players.length; i++) if (this.players[i].id === id) return i;
    return -1;
  };
  NetMatch.prototype.cur = function () { return this.players[this.current]; };

  /** Acción de un jugador: 'roll' | 'toggle' (n) | 'clear' | 'confirm'. Devuelve true si cambió algo. */
  NetMatch.prototype.handle = function (id, action, n) {
    if (this.phase !== 'playing' || this.pending) return false;
    var p = this.cur();
    if (p.id !== id || p.finished) return false;
    var g = p.game;
    switch (action) {
      case 'roll':
        if (g.state !== 'ready') return false;
        var r = g.roll();
        if (g.state === 'over') {
          p.finished = true;
          this.event = { type: 'stuck', player: id, dice: r.dice, sum: r.sum };
          this.pending = 'advance';
        } else {
          this.event = { type: 'rolled', player: id, dice: r.dice, sum: r.sum };
        }
        break;
      case 'toggle':
        n = Number(n);
        if (!(n >= 1 && n <= 9)) return false;
        if (!g.toggle(n).ok) return false;
        this.event = { type: 'select', player: id };
        break;
      case 'clear':
        if (g.state !== 'choosing') return false;
        g.clearSelection();
        this.event = { type: 'select', player: id };
        break;
      case 'confirm':
        var removed = g.confirm();
        if (!removed) return false;
        if (g.state === 'won') {
          p.finished = true;
          p.won = true;
          this.event = { type: 'won', player: id, removed: removed };
          this.pending = 'end';
        } else {
          this.event = { type: 'confirmed', player: id, removed: removed };
          this.pending = 'advance';
        }
        break;
      default:
        return false;
    }
    this.seq++;
    return true;
  };

  NetMatch.prototype.nextIndex = function () {
    var n = this.players.length;
    for (var k = 1; k <= n; k++) {
      var i = (this.current + k) % n;
      if (!this.players[i].finished) return i;
    }
    return -1;
  };

  /** Pasa el turno (el anfitrión lo llama tras la pausa de animación). */
  NetMatch.prototype.advance = function () {
    if (this.phase !== 'playing' || !this.pending) return false;
    if (this.pending === 'end') return this.finish();
    this.pending = null;
    var next = this.nextIndex();
    if (next === -1) return this.finish();
    this.current = next;
    this.event = { type: 'turn', player: this.players[next].id };
    this.seq++;
    return true;
  };

  NetMatch.prototype.finish = function () {
    this.phase = 'ended';
    this.pending = null;
    this.event = { type: 'ended' };
    this.seq++;
    return true;
  };

  /** Un jugador se desconecta: queda fuera con su puntuación actual. */
  NetMatch.prototype.disconnect = function (id) {
    var i = this.index(id);
    if (i === -1 || this.players[i].disconnected) return false;
    var p = this.players[i];
    p.disconnected = true;
    p.finished = true;
    if (this.phase !== 'playing') { this.seq++; return true; }
    var active = this.players.filter(function (q) { return !q.disconnected; }).length;
    if (active < 1) return this.finish();
    if (i === this.current && this.pending !== 'end') {
      this.pending = null;
      var next = this.nextIndex();
      if (next === -1) return this.finish();
      this.current = next;
      this.event = { type: 'turn', player: this.players[next].id, left: id };
    } else {
      this.event = { type: 'left', player: id };
    }
    this.seq++;
    return true;
  };

  /** Clasificación: primero quien cerró la caja, después de menor a mayor puntuación. */
  NetMatch.prototype.ranking = function () {
    var list = this.players.map(function (p) {
      return { id: p.id, name: p.name, score: p.game.score(), won: p.won, disconnected: p.disconnected };
    });
    list.sort(function (a, b) {
      if (a.won !== b.won) return a.won ? -1 : 1;
      return a.score - b.score;
    });
    var rank = 0, prev = null;
    list.forEach(function (r, i) {
      var key = (r.won ? 'w' : '') + r.score;
      if (key !== prev) { rank = i + 1; prev = key; }
      r.rank = rank;
    });
    return list;
  };

  NetMatch.prototype.snapshot = function () {
    var p = this.cur();
    var g = p.game;
    return {
      phase: this.phase,
      seq: this.seq,
      current: this.current,
      pending: !!this.pending,
      event: this.event,
      players: this.players.map(function (q) {
        return { id: q.id, name: q.name, open: q.game.open.slice(), score: q.game.score(),
                 finished: q.finished, disconnected: q.disconnected, won: q.won, moves: q.game.moves };
      }),
      dice: g.dice.slice(),
      diceSum: g.diceSum,
      selection: g.selection.slice(),
      gstate: g.state,
      ranking: this.phase === 'ended' ? this.ranking() : null
    };
  };

  var api = { NetMatch: NetMatch, MAX_PLAYERS: MAX_PLAYERS };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.STBNetGame = api;
})(typeof window !== 'undefined' ? window : this);
