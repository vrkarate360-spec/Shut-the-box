/*
 * Shut the Box — partida en red (2 a 4 jugadores). Lógica pura, la ejecuta el móvil anfitrión.
 *
 * Reglas de la partida en red:
 *  - Cada jugador tiene su propia caja con las nueve fichas.
 *  - El turno rota tirada a tirada: el jugador lanza, abate fichas y pasa el turno.
 *  - Si un jugador saca una tirada sin combinación posible, queda eliminado con su puntuación.
 *  - Si alguien cierra la caja (abate los nueve números), gana al momento: victoria perfecta.
 *  - Si no, cuando todos han terminado gana la puntuación más baja.
 */
(function (root) {
  'use strict';

  var L = (typeof module !== 'undefined' && module.exports) ? require('./logic.js') : root.STBLogic;
  var MAX_PLAYERS = 4;

  function NetMatch(players, opts) {
    opts = opts || {};
    if (players.length < 2 || players.length > MAX_PLAYERS) throw new Error('Se necesitan de 2 a 4 jugadores');
    var rng = opts.rng || Math.random;
    this.oneDieRule = !!opts.oneDieRule;
    this.players = players.map(function (p) {
      return {
        id: p.id, name: p.name,
        game: new L.Game({ rng: rng, oneDieRule: opts.oneDieRule }),
        finished: false, disconnected: false, won: false
      };
    });
    this.current = 0;
    this.phase = 'playing';     // playing | ended
    this.pending = null;        // null | 'advance' | 'end'  (pausa para que se vean las animaciones)
    this.seq = 1;
    this.event = { type: 'start', player: this.players[0].id };
  }

  NetMatch.prototype.index = function (id) {
    for (var i = 0; i < this.players.length; i++) if (this.players[i].id === id) return i;
    return -1;
  };
  NetMatch.prototype.cur = function () { return this.players[this.current]; };

  /** Acción de un jugador: 'roll' | 'toggle' (n) | 'clear' | 'confirm'. Devuelve true si cambió algo. */
  NetMatch.prototype.handle = function (id, action, n) {
    if (this.phase !== 'playing' || this.pending) return false;
    var p = this.cur();
    if (p.id !== id || p.finished) return false;
    var g = p.game;
    switch (action) {
      case 'roll':
        if (g.state !== 'ready') return false;
        var r = g.roll();
        if (g.state === 'over') {
          p.finished = true;
          this.event = { type: 'stuck', player: id, dice: r.dice, sum: r.sum };
          this.pending = 'advance';
        } else {
          this.event = { type: 'rolled', player: id, dice: r.dice, sum: r.sum };
        }
        break;
      case 'toggle':
        n = Number(n);
        if (!(n >= 1 && n <= 9)) return false;
        if (!g.toggle(n).ok) return false;
        this.event = { type: 'select', player: id };
        break;
      case 'clear':
        if (g.state !== 'choosing') return false;
        g.clearSelection();
        this.event = { type: 'select', player: id };
        break;
      case 'confirm':
        var removed = g.confirm();
        if (!removed) return false;
        if (g.state === 'won') {
          p.finished = true;
          p.won = true;
          this.event = { type: 'won', player: id, removed: removed };
          this.pending = 'end';
        } else {
          this.event = { type: 'confirmed', player: id, removed: removed };
          this.pending = 'advance';
        }
        break;
      default:
        return false;
    }
    this.seq++;
    return true;
  };

  NetMatch.prototype.nextIndex = function () {
    var n = this.players.length;
    for (var k = 1; k <= n; k++) {
      var i = (this.current + k) % n;
      if (!this.players[i].finished) return i;
    }
    return -1;
  };

  /** Pasa el turno (el anfitrión lo llama tras la pausa de animación). */
  NetMatch.prototype.advance = function () {
    if (this.phase !== 'playing' || !this.pending) return false;
    if (this.pending === 'end') return this.finish();
    this.pending = null;
    var next = this.nextIndex();
    if (next === -1) return this.finish();
    this.current = next;
    this.event = { type: 'turn', player: this.players[next].id };
    this.seq++;
    return true;
  };

  NetMatch.prototype.finish = function () {
    this.phase = 'ended';
    this.pending = null;
    this.event = { type: 'ended' };
    this.seq++;
    return true;
  };

  /** Un jugador se desconecta: queda fuera con su puntuación actual. */
  NetMatch.prototype.disconnect = function (id) {
    var i = this.index(id);
    if (i === -1 || this.players[i].disconnected) return false;
    var p = this.players[i];
    p.disconnected = true;
    p.finished = true;
    if (this.phase !== 'playing') { this.seq++; return true; }
    var active = this.players.filter(function (q) { return !q.disconnected; }).length;
    if (active < 1) return this.finish();
    if (i === this.current && this.pending !== 'end') {
      this.pending = null;
      var next = this.nextIndex();
      if (next === -1) return this.finish();
      this.current = next;
      this.event = { type: 'turn', player: this.players[next].id, left: id };
    } else {
      this.event = { type: 'left', player: id };
    }
    this.seq++;
    return true;
  };

  /** Clasificación: primero quien cerró la caja, después de menor a mayor puntuación. */
  NetMatch.prototype.ranking = function () {
    var list = this.players.map(function (p) {
      return { id: p.id, name: p.name, score: p.game.score(), won: p.won, disconnected: p.disconnected };
    });
    list.sort(function (a, b) {
      if (a.won !== b.won) return a.won ? -1 : 1;
      return a.score - b.score;
    });
    var rank = 0, prev = null;
    list.forEach(function (r, i) {
      var key = (r.won ? 'w' : '') + r.score;
      if (key !== prev) { rank = i + 1; prev = key; }
      r.rank = rank;
    });
    return list;
  };

  NetMatch.prototype.snapshot = function () {
    var p = this.cur();
    var g = p.game;
    return {
      phase: this.phase,
      seq: this.seq,
      current: this.current,
      pending: !!this.pending,
      event: this.event,
      players: this.players.map(function (q) {
        return { id: q.id, name: q.name, open: q.game.open.slice(), score: q.game.score(),
                 finished: q.finished, disconnected: q.disconnected, won: q.won, moves: q.game.moves };
      }),
      dice: g.dice.slice(),
      diceSum: g.diceSum,
      selection: g.selection.slice(),
      gstate: g.state,
      ranking: this.phase === 'ended' ? this.ranking() : null
    };
  };

  // ===================================================================== Caja compartida
  /*
   * Modo «Caja compartida»: una sola caja para todos; cada uno juega con lo que deja el anterior.
   *  - El turno pasa después de cada jugada.
   *  - Quien saca una tirada imposible suma a su total lo que queda levantado y empieza otra ronda.
   *  - Si alguien cierra la caja, los demás suman 10 y empieza otra ronda.
   *  - Termina al acabar las rondas elegidas o cuando alguien llega a 45 puntos: gana quien menos tenga.
   */
  var SHUT_PENALTY = 10;
  function SharedMatch(players, opts) {
    opts = opts || {};
    if (players.length < 2 || players.length > MAX_PLAYERS) throw new Error('Se necesitan de 2 a 4 jugadores');
    this.rng = opts.rng || Math.random;
    this.oneDieRule = !!opts.oneDieRule;
    this.limit = opts.limit || 45;
    this.maxRounds = opts.maxRounds || 0;      // 0 = sin límite de rondas
    this.players = players.map(function (p) { return { id: p.id, name: p.name, total: 0, disconnected: false }; });
    this.round = 1;
    this.starter = 0;
    this.current = 0;
    this.phase = 'playing';
    this.pending = null;
    this.seq = 1;
    this.newGame();
    this.event = { type: 'start', player: this.players[0].id };
  }
  SharedMatch.prototype.newGame = function () { this.game = new L.Game({ rng: this.rng, oneDieRule: this.oneDieRule }); };
  SharedMatch.prototype.index = NetMatch.prototype.index;
  SharedMatch.prototype.cur = NetMatch.prototype.cur;
  SharedMatch.prototype.active = function () { return this.players.filter(function (p) { return !p.disconnected; }); };
  SharedMatch.prototype.nextIndex = function (from) {
    var n = this.players.length;
    for (var k = 1; k <= n; k++) { var i = (from + k) % n; if (!this.players[i].disconnected) return i; }
    return -1;
  };
  SharedMatch.prototype.reachedLimit = function () {
    var lim = this.limit;
    return this.active().length < 2 || this.active().some(function (p) { return p.total >= lim; });
  };
  /** Al acabar una ronda: ¿se juega otra o termina la partida? */
  SharedMatch.prototype.roundOver = function () {
    if (this.reachedLimit()) return 'end';
    if (this.maxRounds && this.round >= this.maxRounds) return 'end';
    return 'round';
  };
  SharedMatch.prototype.handle = function (id, action, n) {
    if (this.phase !== 'playing' || this.pending) return false;
    var p = this.cur();
    if (p.id !== id || p.disconnected) return false;
    var g = this.game, self = this;
    switch (action) {
      case 'roll':
        if (g.state !== 'ready') return false;
        var r = g.roll();
        if (g.state === 'over') {
          var add = g.score();
          p.total += add;
          this.event = { type: 'stuck', player: id, dice: r.dice, sum: r.sum, add: add };
          this.pending = this.roundOver();
        } else this.event = { type: 'rolled', player: id, dice: r.dice, sum: r.sum };
        break;
      case 'toggle':
        n = Number(n);
        if (!(n >= 1 && n <= 9) || !g.toggle(n).ok) return false;
        this.event = { type: 'select', player: id };
        break;
      case 'clear':
        if (g.state !== 'choosing') return false;
        g.clearSelection();
        this.event = { type: 'select', player: id };
        break;
      case 'confirm':
        var removed = g.confirm();
        if (!removed) return false;
        if (g.state === 'won') {
          this.active().forEach(function (q) { if (q.id !== id) q.total += SHUT_PENALTY; });
          this.event = { type: 'won', player: id, removed: removed, add: SHUT_PENALTY };
          this.pending = this.roundOver();
        } else {
          this.event = { type: 'confirmed', player: id, removed: removed };
          this.pending = 'advance';
        }
        break;
      default: return false;
    }
    this.seq++;
    return true;
  };
  SharedMatch.prototype.advance = function () {
    if (this.phase !== 'playing' || !this.pending) return false;
    var what = this.pending;
    this.pending = null;
    if (what === 'end' || this.active().length < 2) return this.finish();
    if (what === 'round') {
      this.round++;
      this.starter = this.nextIndex(this.starter);
      this.current = this.starter;
      this.newGame();
      this.event = { type: 'round', player: this.players[this.current].id, round: this.round };
    } else {
      this.current = this.nextIndex(this.current);
      this.event = { type: 'turn', player: this.players[this.current].id };
    }
    this.seq++;
    return true;
  };
  SharedMatch.prototype.finish = NetMatch.prototype.finish;
  SharedMatch.prototype.disconnect = function (id) {
    var i = this.index(id);
    if (i === -1 || this.players[i].disconnected) return false;
    this.players[i].disconnected = true;
    if (this.phase !== 'playing') { this.seq++; return true; }
    if (this.active().length < 2) return this.finish();
    if (i === this.current && (this.pending === null || this.pending === 'advance')) {
      this.pending = null;
      this.current = this.nextIndex(this.current);
      this.event = { type: 'turn', player: this.players[this.current].id, left: id };
    } else {
      if (i === this.starter) this.starter = this.nextIndex(this.starter);
      this.event = { type: 'left', player: id };
    }
    this.seq++;
    return true;
  };
  SharedMatch.prototype.ranking = function () {
    var list = this.players.map(function (p) { return { id: p.id, name: p.name, score: p.total, won: false, disconnected: p.disconnected }; });
    list.sort(function (a, b) { return (a.disconnected - b.disconnected) || (a.score - b.score); });
    var rank = 0, prev = null;
    list.forEach(function (r, i) { var k = r.disconnected ? 'x' + i : r.score; if (k !== prev) { rank = i + 1; prev = k; } r.rank = rank; });
    return list;
  };
  SharedMatch.prototype.snapshot = function () {
    var g = this.game;
    return {
      mode: 'shared', round: this.round, limit: this.limit, maxRounds: this.maxRounds,
      phase: this.phase, seq: this.seq, current: this.current, pending: !!this.pending, event: this.event,
      players: this.players.map(function (q) {
        return { id: q.id, name: q.name, open: g.open.slice(), score: q.total, finished: q.disconnected, disconnected: q.disconnected, won: false, moves: g.moves };
      }),
      dice: g.dice.slice(), diceSum: g.diceSum, selection: g.selection.slice(), gstate: g.state,
      ranking: this.phase === 'ended' ? this.ranking() : null
    };
  };

  var api = { NetMatch: NetMatch, SharedMatch: SharedMatch, MAX_PLAYERS: MAX_PLAYERS, SHUT_PENALTY: SHUT_PENALTY };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.STBNetGame = api;
})(typeof window !== 'undefined' ? window : this);
