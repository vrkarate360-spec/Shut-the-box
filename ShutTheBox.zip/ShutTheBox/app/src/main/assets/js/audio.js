/*
 * Shut the Box — sonidos sintetizados con Web Audio (sin archivos, sin Internet).
 * El contexto de audio se suspende cuando no suena nada para ahorrar batería.
 */
(function (root) {
  'use strict';

  var ctx = null, master = null, noiseBuf = null;
  var enabled = true;
  var suspendTimer = null;

  function ensure() {
    if (!enabled) return null;
    if (!ctx) {
      var AC = root.AudioContext || root.webkitAudioContext;
      if (!AC) return null;
      ctx = new AC();
      master = ctx.createGain();
      master.gain.value = 0.85;
      master.connect(ctx.destination);
      var len = ctx.sampleRate;
      noiseBuf = ctx.createBuffer(1, len, ctx.sampleRate);
      var d = noiseBuf.getChannelData(0);
      for (var i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
    }
    if (ctx.state === 'suspended') ctx.resume();
    return ctx;
  }

  function scheduleSuspend(afterSec) {
    if (suspendTimer) clearTimeout(suspendTimer);
    suspendTimer = setTimeout(function () {
      if (ctx && ctx.state === 'running') ctx.suspend();
    }, (afterSec + 1.5) * 1000);
  }

  function rand(a, b) { return a + Math.random() * (b - a); }

  function noise(t, o) {
    var src = ctx.createBufferSource();
    src.buffer = noiseBuf;
    var f = ctx.createBiquadFilter();
    f.type = o.type || 'bandpass';
    f.frequency.value = o.freq || 2500;
    f.Q.value = o.q || 1;
    var g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(o.gain || 0.4, t + 0.003);
    g.gain.exponentialRampToValueAtTime(0.0001, t + (o.dur || 0.05));
    src.connect(f); f.connect(g); g.connect(master);
    src.start(t, Math.random() * 0.8);
    src.stop(t + (o.dur || 0.05) + 0.03);
  }

  function tone(t, freq, dur, gain, type, freqEnd) {
    var o = ctx.createOscillator();
    o.type = type || 'sine';
    o.frequency.setValueAtTime(freq, t);
    if (freqEnd) o.frequency.exponentialRampToValueAtTime(freqEnd, t + dur);
    var g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(gain, t + 0.006);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g); g.connect(master);
    o.start(t);
    o.stop(t + dur + 0.03);
  }

  /** Dados rodando y rebotando sobre madera. */
  function diceRoll(nDice, duration) {
    if (!ensure()) return;
    duration = duration || 0.95;
    var t0 = ctx.currentTime + 0.02;
    for (var k = 0; k < nDice; k++) {
      var t = t0 + k * rand(0.015, 0.05);
      var gap = 0.035;
      var vol = 0.55;
      while (t < t0 + duration) {
        // golpe seco del dado contra la madera
        noise(t, { freq: rand(1800, 4200), q: rand(0.8, 2.2), gain: vol * rand(0.6, 1), dur: rand(0.025, 0.05) });
        tone(t, rand(170, 280), 0.07, vol * 0.35, 'triangle', rand(90, 130));
        t += gap * rand(0.7, 1.3);
        gap *= 1.17;
        vol *= 0.9;
      }
    }
    scheduleSuspend(duration);
  }

  /** Ficha de madera abatiéndose. */
  function flap(delay) {
    if (!ensure()) return;
    var t = ctx.currentTime + 0.01 + (delay || 0);
    noise(t, { freq: 3200, q: 1.5, gain: 0.25, dur: 0.018 });             // clic de la bisagra
    noise(t + 0.06, { type: 'lowpass', freq: 900, q: 0.7, gain: 0.7, dur: 0.1 }); // golpe al caer
    tone(t + 0.06, 150, 0.13, 0.45, 'sine', 70);
    scheduleSuspend((delay || 0) + 0.3);
  }

  function select() {
    if (!ensure()) return;
    var t = ctx.currentTime + 0.005;
    noise(t, { freq: 2600, q: 3, gain: 0.18, dur: 0.02 });
    tone(t, 520, 0.05, 0.06, 'triangle');
    scheduleSuspend(0.2);
  }

  function error() {
    if (!ensure()) return;
    var t = ctx.currentTime + 0.005;
    tone(t, 160, 0.14, 0.12, 'triangle', 120);
    noise(t, { type: 'lowpass', freq: 500, gain: 0.25, dur: 0.08 });
    scheduleSuspend(0.3);
  }

  function bell(t, f, g) {
    tone(t, f, 1.4, g, 'sine');
    tone(t, f * 2.01, 0.8, g * 0.35, 'sine');
    tone(t, f * 3.02, 0.4, g * 0.12, 'sine');
  }

  function victory() {
    if (!ensure()) return;
    var t = ctx.currentTime + 0.05;
    [523.25, 659.25, 783.99, 1046.5].forEach(function (f, i) { bell(t + i * 0.14, f, 0.16); });
    bell(t + 0.75, 1046.5, 0.12);
    bell(t + 0.75, 783.99, 0.1);
    bell(t + 0.75, 659.25, 0.1);
    scheduleSuspend(2.4);
  }

  function gameOver() {
    if (!ensure()) return;
    var t = ctx.currentTime + 0.05;
    bell(t, 392, 0.1);
    bell(t + 0.22, 311.13, 0.1);
    scheduleSuspend(1.8);
  }

  /** Aviso de turno: campana «ding-dong» que se oye bien. */
  function turnBell() {
    if (!ensure()) return;
    var t = ctx.currentTime + 0.03;
    bell(t, 1318.5, 0.32);
    bell(t + 0.38, 1046.5, 0.32);
    bell(t + 1.0, 1318.5, 0.24);
    bell(t + 1.38, 1046.5, 0.24);
    scheduleSuspend(3);
  }

  /** Risas burlonas sintetizadas (provisionales hasta tener las voces de los personajes). */
  function laugh() {
    if (!ensure()) return;
    var t = ctx.currentTime + 0.03;
    for (var i = 0; i < 6; i++) {
      var f = 330 - i * 14 + rand(-10, 10);
      tone(t + i * 0.16, f, 0.12, 0.13, 'sawtooth', f * 0.8);
      noise(t + i * 0.16, { freq: 1200, q: 1, gain: 0.08, dur: 0.1 });
    }
    scheduleSuspend(1.5);
  }

  var api = {
    turnBell: turnBell,
    laugh: laugh,
    unlock: function () { ensure(); scheduleSuspend(0.5); },
    setEnabled: function (v) {
      enabled = !!v;
      if (!enabled && ctx && ctx.state === 'running') ctx.suspend();
    },
    isEnabled: function () { return enabled; },
    diceRoll: diceRoll,
    flap: flap,
    select: select,
    error: error,
    victory: victory,
    gameOver: gameOver
  };

  if (root.document) {
    root.document.addEventListener('visibilitychange', function () {
      if (root.document.hidden && ctx && ctx.state === 'running') ctx.suspend();
    });
  }

  root.STBAudio = api;
})(window);
