/*
 * Shut the Box — interfaz, animaciones y flujo de partida.
 * Modos:  'solo'  → partida individual (Game directo)
 *         'multi' → varios jugadores, en este móvil o en red (estado recibido de STBNet)
 */
(function () {
  'use strict';

  var I18N = window.STBi18n, t = I18N.t;
  var L = window.STBLogic, S = window.STBStorage, A = window.STBAudio, NET = window.STBNet, PH = window.STBPhoto;
  function $(id) { return document.getElementById(id); }
  function rand(a, b) { return a + Math.random() * (b - a); }
  function esc(t) { return String(t == null ? '' : t).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function sortNum(a) { return a.slice().sort(function (x, y) { return x - y; }); }
  function vibrate(p) { if (settings.vibrate === false) return; try { if (window.AndroidNet) window.AndroidNet.vibrate(p); else if (navigator.vibrate) navigator.vibrate(p.split(',').map(Number)); } catch (e) { } }

  var settings = S.loadSettings();
  var stats = S.loadStats();
  var profile = S.loadProfile();
  A.setEnabled(settings.sound);
  if (I18N.LANGS.indexOf(settings.lang) === -1) { settings.lang = I18N.detect(); S.saveSettings(settings); }
  I18N.set(settings.lang);

  var app = {
    screen: 'menu',
    mode: 'solo',
    game: null,           // solo
    snap: null,           // multi
    faces: {},            // id → {name, photo}
    rolling: false,
    token: 0,
    overlayBack: null,
    matchOver: false,
    sent: false           // multi: acción enviada, esperando respuesta
  };

  // ================================================================ Caras
  function faceHtml(photo, name, cls) {
    var style = photo ? ' style="background-image:url(\'' + photo + '\')"' : '';
    var initial = photo ? '' : '<span class="initial">' + esc((name || '?').trim().charAt(0).toUpperCase() || '?') + '</span>';
    return '<span class="face ' + (cls || 'face-sm') + '"' + style + '>' + initial + '</span>';
  }
  function setFaceEl(el, photo, name) {
    el.style.backgroundImage = photo ? "url('" + photo + "')" : '';
    el.innerHTML = photo ? '' : '<span class="initial">' + esc((name || '?').trim().charAt(0).toUpperCase() || '?') + '</span>';
  }

  // ================================================================ Dados
  var PIPS = { 1: [4], 2: [0, 8], 3: [0, 4, 8], 4: [0, 2, 6, 8], 5: [0, 2, 4, 6, 8], 6: [0, 2, 3, 5, 6, 8] };
  function buildDie(el) {
    el.innerHTML = '';
    for (var i = 0; i < 9; i++) {
      var p = document.createElement('span');
      p.className = 'pip';
      p.style.left = (24 + (i % 3) * 26) + '%';
      p.style.top = (24 + Math.floor(i / 3) * 26) + '%';
      el.appendChild(p);
    }
    setFace(el, parseInt(el.dataset.v, 10) || 1);
  }
  function setFace(el, v) {
    el.dataset.v = v;
    var on = PIPS[v];
    for (var i = 0; i < 9; i++) el.children[i].classList.toggle('on', on.indexOf(i) !== -1);
  }

  var diceEls = [];
  var diceRest = [{ fx: 0.36, fy: 0.45, rot: -8 }, { fx: 0.64, fy: 0.42, rot: 11 }];
  function dieSize() { return diceEls[0].offsetWidth || 60; }
  function placeDice() {
    var tray = $('tray');
    var W = tray.clientWidth, H = tray.clientHeight, d = dieSize();
    diceEls.forEach(function (el, i) {
      var r = diceRest[i];
      el.style.transform = 'translate(' + (r.fx * W - d / 2) + 'px,' + (r.fy * H - d / 2) + 'px) rotate(' + r.rot + 'deg)';
    });
  }
  /** Saltito de los dados al tocarlos. */
  function hopDice() {
    if (app.rolling) return;
    diceEls.forEach(function (el, i) {
      if (el.style.display === 'none' || !el.animate) return;
      var base = el.style.transform || '';
      el.animate([
        { transform: base },
        { transform: base + ' translateY(-' + (16 + i * 4) + 'px) scale(1.12) rotate(' + (i ? -8 : 8) + 'deg)', offset: 0.45 },
        { transform: base }
      ], { duration: 260 + i * 30, easing: 'ease-out' });
    });
    A.select();
  }

  function refreshIcons() {
    $('btn-sound-ig').classList.toggle('off', !settings.sound);
    $('btn-vib-ig').classList.toggle('off', settings.vibrate === false);
  }

  function animateDice(values) {
    return new Promise(function (resolve) {
      var tray = $('tray');
      var W = tray.clientWidth, H = tray.clientHeight, d = dieSize();
      var n = values.length;
      diceEls[1].style.display = n === 2 ? '' : 'none';
      var targets = n === 2
        ? [{ fx: rand(0.27, 0.38), fy: rand(0.36, 0.56) }, { fx: rand(0.6, 0.72), fy: rand(0.34, 0.56) }]
        : [{ fx: rand(0.42, 0.58), fy: rand(0.38, 0.52) }];
      var anims = targets.map(function (t, i) {
        return {
          sx: W + d * rand(0.2, 0.8), sy: rand(-d * 0.3, H - d * 0.7) + i * d * 0.3,
          tx: t.fx * W - d / 2, ty: t.fy * H - d / 2,
          spin: rand(500, 900) * (Math.random() < 0.5 ? -1 : 1), rot: rand(-16, 16), fx: t.fx, fy: t.fy
        };
      });
      var dur = 950, t0 = performance.now(), lastFace = 0;
      A.diceRoll(n, dur / 1000);
      function frame(now) {
        var t = Math.min(1, (now - t0) / dur);
        var e = 1 - Math.pow(1 - t, 3);
        for (var i = 0; i < n; i++) {
          var a = anims[i];
          var hop = Math.abs(Math.sin(t * Math.PI * 3.3)) * (1 - t) * 0.3;
          diceEls[i].style.transform = 'translate(' + (a.sx + (a.tx - a.sx) * e) + 'px,' + (a.sy + (a.ty - a.sy) * e) + 'px) rotate(' +
            (a.rot + a.spin * (1 - e)) + 'deg) scale(' + (1 + hop) + ')';
        }
        if (t < 0.9 && now - lastFace > 55 + t * 150) {
          lastFace = now;
          for (var k = 0; k < n; k++) setFace(diceEls[k], 1 + Math.floor(Math.random() * 6));
        }
        if (t < 1) { requestAnimationFrame(frame); return; }
        for (var j = 0; j < n; j++) {
          setFace(diceEls[j], values[j]);
          diceRest[j] = { fx: anims[j].fx, fy: anims[j].fy, rot: anims[j].rot };
        }
        resolve();
      }
      requestAnimationFrame(frame);
    });
  }

  // ================================================================ Fichas
  var tileEls = [];
  function buildTiles() {
    var c = $('tiles');
    c.innerHTML = '';
    for (var n = 1; n <= 9; n++) {
      var b = document.createElement('button');
      b.className = 'tile';
      b.setAttribute('aria-label', t('tile', { n: n }));
      b.innerHTML = '<span class="slot">' + n + '</span><span class="flap"><span class="num">' + n + '</span></span>';
      (function (num) { b.addEventListener('click', function () { onTile(num); }); })(n);
      c.appendChild(b);
      tileEls[n] = b;
    }
  }
  function flapTiles(removed) {
    removed.forEach(function (n, i) {
      A.flap(i * 0.13);
      var el = tileEls[n];
      el.classList.remove('selected');
      setTimeout(function () { el.classList.add('down'); }, i * 130);
    });
  }
  function shake(n) {
    var el = tileEls[n];
    el.classList.remove('shake'); void el.offsetWidth; el.classList.add('shake');
  }

  // ================================================================ Utilidades UI
  var toastTimer = null;
  function toast(msg) {
    var t = $('toast');
    t.textContent = msg;
    t.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { t.classList.remove('show'); }, 2000);
  }
  function setTrayMsg(msg) { $('tray-msg').textContent = msg || ''; }
  function bump(id, value) {
    var el = $(id);
    if (el.textContent !== String(value)) {
      el.textContent = value;
      el.classList.remove('bump'); void el.offsetWidth; el.classList.add('bump');
    }
  }

  function show(name) {
    var screens = document.querySelectorAll('.screen');
    for (var i = 0; i < screens.length; i++) screens[i].classList.toggle('active', screens[i].id === 'screen-' + name);
    app.screen = name;
    if (name === 'menu') refreshMenu();
    if (name === 'stats') renderStats();
    if (name === 'game') requestAnimationFrame(placeDice);
  }

  function openModal(html, onBack) {
    $('modal').innerHTML = html;
    $('overlay').classList.remove('hidden');
    app.overlayBack = onBack || closeModal;
  }
  function closeModal() {
    $('overlay').classList.add('hidden');
    app.overlayBack = null;
  }

  function bestText() { return stats.best === null ? '—' : String(stats.best); }

  function refreshMenu() {
    $('menu-record').textContent = bestText();
    $('btn-sound').textContent = t(settings.sound ? 'sound_on' : 'sound_off');
    var lb = $('lang-row').children;
    for (var li = 0; li < lb.length; li++) lb[li].classList.toggle('active', lb[li].dataset.lang === settings.lang);
    var canContinue = !app.matchOver && ((app.mode === 'solo' && app.game) || (app.mode === 'multi' && NET.role() === 'local' && app.snap));
    $('btn-continue').classList.toggle('hidden', !canContinue);
    setFaceEl($('profile-face'), profile.photo, profile.name);
    $('profile-name').textContent = profile.name ? profile.name : t('profile_cta');
  }

  function renderStats() {
    $('st-played').textContent = stats.played;
    $('st-perfect').textContent = stats.perfect;
    var avg = S.average(stats);
    $('st-avg').textContent = avg === null ? '—' : avg.toFixed(1).replace('.', ',');
    $('st-best').textContent = bestText();
    var h = S.loadH2H(), people = S.loadPeople();
    var pairs = Object.keys(h).map(function (k) { return h[k]; }).sort(function (a, b) { return b.last - a.last; });
    var photoOf = function (n) { var p = people[S.nkey(n)]; return p ? p.photo : ''; };
    $('h2h-list').innerHTML = !pairs.length ? '<p class="note">' + t('h2h_empty') + '</p>' : pairs.map(function (e) {
      var ties = e.t ? '<small>' + (e.t === 1 ? t('ties1') : t('ties', { s: e.t })) + '</small>' : '';
      var shuts = (e.sa || e.sb) ? '<small>' + t('shuts') + ': ' + e.sa + ' – ' + e.sb + '</small>' : '';
      return '<div class="h2h-item">' +
        '<span class="h2h-p' + (e.wa > e.wb ? ' lead' : '') + '">' + faceHtml(photoOf(e.a), e.a, 'face-md') + '<span>' + esc(e.a) + '</span></span>' +
        '<span class="h2h-score"><b>' + e.wa + ' – ' + e.wb + '</b>' + ties + shuts + '</span>' +
        '<span class="h2h-p' + (e.wb > e.wa ? ' lead' : '') + '">' + faceHtml(photoOf(e.b), e.b, 'face-md') + '<span>' + esc(e.b) + '</span></span></div>';
    }).join('');
    var rb = $('btn-reset-stats');
    rb.dataset.armed = '';
    rb.textContent = t('clear_stats');
  }

  // ================================================================ Vista del tablero
  /** Devuelve un Game con el estado que hay que dibujar. */
  function view() {
    if (app.mode === 'solo') return app.game;
    var s = app.snap;
    var p = s.players[s.current];
    var g = new L.Game();
    g.open = p.open.slice();
    g.selection = s.selection.slice();
    g.state = s.gstate;
    g.diceSum = s.gstate === 'ready' ? null : s.diceSum;
    g.dice = s.dice;
    g.moves = p.moves;
    return g;
  }
  function curPlayer() { return app.snap.players[app.snap.current]; }
  function infoOf(id) { return app.faces[id] || { name: '?', photo: '' }; }
  function isMyTurn() {
    if (app.mode === 'solo') return true;
    var s = app.snap;
    if (!s || s.phase !== 'playing' || s.pending) return false;
    return NET.role() === 'local' || curPlayer().id === NET.myId();
  }

  function render() {
    var g = (app.mode === 'solo') ? app.game : (app.snap ? view() : null);
    if (!g) return;
    var mine = isMyTurn();
    var choosing = g.state === 'choosing' && !app.rolling;

    for (var n = 1; n <= 9; n++) {
      var el = tileEls[n];
      var open = g.isOpen(n);
      var sel = g.selection.indexOf(n) !== -1;
      el.classList.toggle('down', !open);
      el.classList.toggle('selected', sel);
      el.disabled = !open;
    }
    bump('score', g.score());
    bump('remaining', g.open.length);

    var who = '';
    if (app.mode === 'multi') {
      var s = app.snap, cp = curPlayer(), net = NET.role() !== 'local';
      who = cp.name;
      var me = net && cp.id === NET.myId();
      $('player-label').innerHTML = s.phase === 'ended' ? t('ended_label') :
        (me ? t('your_turn') : t('turn_of', { n: esc(cp.name) })) + '<small>' + t(net ? 'net_game' : 'local_multi') + '</small>';
      if (net) {
        var mineP = s.players.filter(function (p) { return p.id === NET.myId(); })[0];
        $('third-label').textContent = t('your_points');
        $('best').textContent = mineP ? mineP.score : '—';
      } else if (s.mode === 'shared') {
        $('third-label').textContent = t('round');
        $('best').textContent = s.round;
      } else {
        $('third-label').textContent = t('in_play');
        $('best').textContent = s.players.filter(function (p) { return !p.finished; }).length + ' / ' + s.players.length;
      }
      renderStrip();
    } else {
      $('player-label').innerHTML = t('solo_label');
      $('third-label').textContent = t('best');
      $('best').textContent = bestText();
    }

    $('dice-sum').textContent = app.rolling ? '…' : (g.diceSum === null ? '–' : g.diceSum);

    var info = '';
    var watching = app.mode === 'multi' && !mine && NET.role() !== 'local';
    if (app.rolling) info = (watching ? t('x_rolls', { n: esc(who) }) : t('rolling'));
    else if (g.state === 'ready') {
      if (watching) info = t('x_will_roll', { n: esc(who) });
      else info = g.moves === 0 ? (app.mode === 'multi' ? t('x_roll_now', { n: esc(who) }) : t('start_roll')) : t('well_played');
    } else if (g.state === 'choosing') {
      var sum = g.selectionSum();
      var pre = watching ? t('x_choosing', { n: esc(who) }) + '<br>' : '';
      if (sum === 0) info = pre + t(watching ? 'needs_sum' : 'choose_sum', { s: g.diceSum });
      else if (sum < g.diceSum) info = pre + t('selected') + ' <b>' + sortNum(g.selection).join(' + ') + ' = ' + sum + '</b><br>' + t('missing', { s: g.diceSum - sum });
      else info = pre + '<span class="okmsg"><b>' + sortNum(g.selection).join(' + ') + ' = ' + sum + '</b> ✓</span>' + (watching ? '' : '<br>' + t('press_confirm'));
    } else if (g.state === 'over') info = t('no_combo', { s: g.diceSum });
    else if (g.state === 'won') info = '<span class="okmsg"><b>' + t('box_shut') + '</b></span>';
    $('sel-indicator').innerHTML = info;

    var canAct = mine && !app.sent;
    $('btn-roll').disabled = !canAct || g.state !== 'ready' || app.rolling;
    var complete = canAct && choosing && g.selectionSum() === g.diceSum;
    var cb = $('btn-confirm');
    if (complete && cb.disabled) { cb.classList.remove('ready'); void cb.offsetWidth; cb.classList.add('ready'); }
    if (!complete) cb.classList.remove('ready');
    cb.disabled = !complete;
    $('btn-cancel').disabled = !(canAct && choosing && g.selection.length > 0);

    $('players-strip').classList.toggle('hidden', app.mode !== 'multi');
    $('btn-restart').classList.toggle('hidden', app.mode === 'multi' && NET.role() !== 'local');
  }

  function renderStrip() {
    var s = app.snap;
    var tallyOn = s.tally && Object.keys(s.tally).some(function (k) { return s.tally[k] > 0; });
    $('players-strip').innerHTML = s.players.map(function (p, i) {
      var f = infoOf(p.id);
      var cls = 'pchip' + (i === s.current && s.phase === 'playing' ? ' turn' : '') + (p.finished ? ' out' : '') +
        (p.disconnected ? ' gone' : '') + (p.id === NET.myId() ? ' me' : '');
      return '<div class="' + cls + '">' + faceHtml(f.photo, p.name, 'face-xs') +
        '<span class="pinfo"><span class="pname">' + esc(p.name) + '</span><span class="pscore">' + p.score + '</span></span>' +
        (tallyOn ? '<span class="ptally">🏆' + ((s.tally && s.tally[p.id]) || 0) + '</span>' : '') + '</div>';
    }).join('');
  }

  // ================================================================ Aviso de turno y burla
  var bannerTimer = null;
  function banner(photo, name, title, sub) {
    var b = $('turn-banner');
    b.innerHTML = faceHtml(photo, name, 'face-lg') + '<div class="bt">' + esc(title) + '</div>' + (sub ? '<div class="bs">' + esc(sub) + '</div>' : '');
    b.classList.remove('hidden');
    b.style.animation = 'none'; void b.offsetWidth; b.style.animation = '';
    clearTimeout(bannerTimer);
    bannerTimer = setTimeout(function () { b.classList.add('hidden'); }, 2300);
  }

  function turnNotice() {
    var s = app.snap;
    if (!s || s.phase !== 'playing') return;
    var cp = curPlayer(), f = infoOf(cp.id);
    if (NET.role() === 'local') {
      A.turnBell(); vibrate('0,200,100,200'); sayLater(26, 1100);
      banner(f.photo, cp.name, t('turn_of', { n: cp.name }), t('pass_phone'));
    } else if (cp.id === NET.myId()) {
      A.turnBell(); vibrate('0,350,150,350'); sayLater(26, 1100);
      banner(f.photo, cp.name, t('your_turn_n', { n: cp.name }), t('roll_the_dice'));
    } else {
      toast(t('turn_of', { n: cp.name }));
    }
  }

  var mockTimer = null, mockDone = null, lastCostume = null, mouthRaf = null, voiceAudio = null;

  // ---------------------------------------------------------------- Voces grabadas
  function voice(idx) {
    if (!settings.sound) return null;
    try {
      var a = new Audio('voces/' + I18N.get() + '/' + (idx < 10 ? '0' : '') + idx + '.mp3');
      a.play().catch(function () { });
      return a;
    } catch (e) { return null; }
  }
  function say(idx) { return voice(idx); }
  function sayLater(idx, ms) { setTimeout(function () { voice(idx); }, ms); }

  /**
   * Figura con la cara del jugador dentro de un disfraz.
   * La foto se guarda con los ojos al 42 % y la boca al 70 % de su altura (guía del editor),
   * así se puede ampliar para llenar el óvalo y cortar la barbilla para mover la boca.
   */
  var MOUTH = 0.70, FACEW = 0.66;
  function costumeHtml(c, photo, name, maxW, maxH) {
    var sc = Math.min(maxW / c.w, maxH / c.h);
    var e = 0.04;
    var W = c.face[2] * (1 + 2 * e) * sc, H = c.face[3] * (1 + 2 * e) * sc;
    var fx = (c.face[0] - c.face[2] * e) / c.w * 100, fy = (c.face[1] - c.face[3] * e) / c.h * 100;
    var origin = (c.neck[0] / c.w * 100) + '% ' + (c.neck[1] / c.h * 100) + '%';
    var size = Math.max(W / FACEW, H / 0.84);      // la cara llena el óvalo (ancho y alto)
    var top = H * 0.02 - size * 0.12;              // frente arriba del óvalo (guía del editor: 13 %)
    var mouthY = Math.max(H * 0.55, Math.min(H * 0.85, top + size * MOUTH));
    var bg = photo ? "background-image:url('" + photo + "');background-size:" + size + 'px ' + size + 'px;background-position:' + ((W - size) / 2) + 'px ' + top + 'px;' : '';
    var initial = photo ? '' : '<span class="initial" style="font-size:' + Math.round(H * 0.42) + 'px">' + esc((name || '?').trim().charAt(0).toUpperCase()) + '</span>';
    return '<div class="costume dance-' + c.dance + '" style="width:' + Math.round(c.w * sc) + 'px;height:' + Math.round(c.h * sc) + 'px">' +
      '<img class="c-body" src="' + c.body + '" alt="">' +
      '<div class="c-head" style="transform-origin:' + origin + '">' +
      '<div class="c-face" style="left:' + fx + '%;top:' + fy + '%;width:' + W + 'px;height:' + H + 'px">' +
      '<div class="c-top" style="' + bg + 'clip-path:inset(0 0 ' + (H - mouthY) + 'px 0)">' + initial + '</div>' +
      '<div class="c-jaw" id="c-jaw" style="' + bg + 'clip-path:inset(' + mouthY + 'px 0 0 0)" data-h="' + H + '"></div>' +
      '</div>' +
      '<img src="' + c.head + '" alt=""></div></div>';
  }

  function pickCostume() {
    var list = window.STB_COSTUMES || [];
    if (!list.length) return null;
    var c;
    do { c = list[Math.floor(Math.random() * list.length)]; } while (list.length > 1 && c === lastCostume);
    lastCostume = c;
    return c;
  }

  /** Mueve la barbilla como un muñeco recortado: con el volumen de la voz o, sin voz, al ritmo del texto. */
  function animateMouth(audio, env, fallbackMs) {
    cancelAnimationFrame(mouthRaf);
    var jaw = $('c-jaw');
    if (!jaw) return;
    var drop = +jaw.dataset.h * 0.13;
    var t0 = performance.now();
    function frame(now) {
      if (!document.body.contains(jaw)) return;
      var v = 0;
      if (audio && env && !audio.paused && !audio.ended) {
        v = env[Math.min(env.length - 1, Math.floor(audio.currentTime * 25))] || 0;
      } else if (!audio && now - t0 < fallbackMs) {
        v = Math.abs(Math.sin((now - t0) / 85)) * (0.5 + 0.5 * Math.abs(Math.sin((now - t0) / 410)));
      } else if (audio && audio.ended) { v = 0; }
      jaw.style.transform = 'translateY(' + (v * drop).toFixed(1) + 'px)';
      if (audio ? !audio.ended || now - t0 < 600 : now - t0 < fallbackMs + 200) mouthRaf = requestAnimationFrame(frame);
      else jaw.style.transform = '';
    }
    mouthRaf = requestAnimationFrame(frame);
  }

  /** Burla: el jugador aparece disfrazado y bailando; dice la frase grabada; los demás se ríen. */
  function showMock(name, photo, score, then, laughers, total) {
    if (!settings.mock) { if (then) then(); return; }
    var c = pickCostume();
    if (!c) { if (then) then(); return; }
    var L = I18N.get();
    var k = c.voice[Math.floor(Math.random() * c.voice.length)];
    var phrase = (window.STB_VOICE_TEXT && window.STB_VOICE_TEXT[L] && window.STB_VOICE_TEXT[L][k]) || '';
    var cname = c.name[L] || c.name.es;
    var jajas = '';
    for (var i = 0; i < 6; i++) {
      jajas += '<span class="jaja" style="left:' + rand(4, 80) + '%;top:' + rand(5, 70) + '%;animation-delay:' + rand(0.3, 1.4).toFixed(2) + 's">' + t(i % 2 ? 'ja' : 'jaja') + '</span>';
    }
    var crowd = (laughers || []).map(function (p, n) {
      return '<span class="laugher" style="animation-delay:' + (n * 0.12) + 's">' + faceHtml(p.photo, p.name, 'face-md') + '<small>' + t('haha') + '</small></span>';
    }).join('');
    var maxW = Math.min(window.innerWidth * 0.88, 460), maxH = window.innerHeight * (crowd ? 0.5 : 0.58);
    var m = $('mock');
    m.innerHTML =
      '<div class="mock-bubble"><small>' + esc(cname) + '</small>' + esc(phrase) + '</div>' +
      '<div class="mock-stage">' + jajas + costumeHtml(c, photo, name, maxW, maxH) + '</div>' +
      '<div class="mock-caption"><b>' + esc(name) + '</b> · ' + (total != null ? '<span class="add">' + t('adds', { a: score, s: total }) + '</span>' : (score === 1 ? t('point1') : t('points', { s: score }))) + '</div>' +
      (crowd ? '<div class="mock-crowd">' + crowd + '</div>' : '') +
      '<div class="mock-hint">' + t('tap_continue') + '</div>';
    m.classList.remove('hidden');
    mockDone = then || null;
    clearTimeout(mockTimer);
    var env = window.STB_VOICE_ENV && window.STB_VOICE_ENV[L] && window.STB_VOICE_ENV[L][k];
    setTimeout(function () {
      if (m.classList.contains('hidden')) return;
      voiceAudio = voice(k);
      animateMouth(voiceAudio, env, 2200);
      if (voiceAudio) voiceAudio.addEventListener('ended', function () { if (!m.classList.contains('hidden')) A.laugh(); });
      else A.laugh();
    }, 450);
    var dur = env ? env.length * 40 : 2200;
    mockTimer = setTimeout(hideMock, Math.max(4300, 450 + dur + 1600));
  }
  function hideMock() {
    clearTimeout(mockTimer);
    cancelAnimationFrame(mouthRaf);
    if (voiceAudio) { try { voiceAudio.pause(); } catch (e) { } voiceAudio = null; }
    var m = $('mock');
    if (m.classList.contains('hidden')) return;
    m.classList.add('hidden');
    m.innerHTML = '';
    var d = mockDone; mockDone = null;
    if (d) d();
  }

  // ================================================================ Partida individual
  function startSolo() {
    NET.stop();
    closeModal();
    app.mode = 'solo';
    app.snap = null;
    app.matchOver = false;
    app.token++;
    app.game = new L.Game({ oneDieRule: settings.oneDie });
    app.rolling = false;
    app.sent = false;
    diceEls[1].style.display = '';
    setTrayMsg(t('press_roll'));
    show('game');
    render();
    placeDice();
  }

  function soloRoll() {
    var g = app.game;
    if (app.rolling || g.state !== 'ready') return;
    app.rolling = true;
    var token = app.token;
    var res = g.roll();
    setTrayMsg('');
    render();
    animateDice(res.dice).then(function () {
      if (token !== app.token) return;
      app.rolling = false;
      render();
      if (g.state === 'over') {
        setTrayMsg(t('no_combos')); say(30);
        A.gameOver();
        setTimeout(function () {
          if (token !== app.token) return;
          showMock(profile.name || t('player_default'), profile.photo, g.score(), function () { if (token === app.token) soloEnd(); });
        }, 1500);
      }
    });
  }

  function soloConfirm() {
    var g = app.game;
    var removed = g.confirm();
    if (!removed) { A.error(); toast(t('sum_exact', { s: g.diceSum })); return; }
    flapTiles(removed);
    var token = app.token;
    setTimeout(function () { if (token === app.token) render(); }, removed.length * 130);
    if (g.state === 'won') {
      setTrayMsg('');
      setTimeout(function () { if (token === app.token) soloVictory(); }, 550 + removed.length * 130);
    } else setTrayMsg(t('roll_again'));
  }

  function recordSolo() {
    var r = S.recordGame(stats, app.game.score());
    stats = r.stats;
    S.saveStats(stats);
    app.matchOver = true;
    return r.newRecord;
  }

  function verdict(score) {
    if (score === 0) return t('v0');
    if (score <= 5) return t('v5');
    if (score <= 10) return t('v10');
    if (score <= 20) return t('v20');
    return t('vbad');
  }
  function chipsHtml(open) {
    return open.length ? '<div class="chips">' + open.map(function (n) { return '<div class="chip">' + n + '</div>'; }).join('') + '</div>' : '';
  }
  function soloButtons() {
    return '<div class="row"><button class="btn" id="m-menu">' + t('menu') + '</button><button class="btn btn-gold" id="m-again">' + t('play_again') + '</button></div>';
  }
  function bindSoloButtons() {
    $('m-menu').onclick = goMenu;
    $('m-again').onclick = startSolo;
  }

  function soloVictory() {
    var rec = recordSolo();
    A.victory(); sayLater(27, 900);
    openModal('<div class="victory-title">¡SHUT THE BOX!</div><p>' + t('all_nine') + '</p>' +
      '<div class="result-grid"><div><small>' + t('tiles_up') + '</small><b>0</b></div><div><small>' + t('final_score') + '</small><b>0</b></div></div>' +
      (rec ? '<span class="badge">' + t('new_record') + '</span>' : '') + soloButtons(), goMenu);
    bindSoloButtons();
    confetti();
  }

  function soloEnd() {
    var g = app.game, score = g.score();
    var rec = recordSolo();
    openModal('<h2>' + t('game_over') + '</h2><p>' + t('rolled_no_combo', { s: g.diceSum }) + '</p>' +
      '<p class="note">' + t('remaining_numbers') + '</p>' + chipsHtml(g.open) +
      '<div class="result-grid"><div><small>' + t('remaining_sum') + '</small><b>' + score + '</b></div><div><small>' + t('final_score') + '</small><b>' + score + '</b></div></div>' +
      '<p class="verdict">' + verdict(score) + '</p>' + (rec ? '<span class="badge">' + t('new_record') + '</span>' : '') + soloButtons(), goMenu);
    bindSoloButtons();
  }

  function confetti() {
    var colors = ['#e3b866', '#f5ead6', '#c59660', '#8d5631', '#f6dc9c'];
    for (var i = 0; i < 40; i++) {
      var c = document.createElement('div');
      c.className = 'confetti';
      c.style.left = rand(0, 100) + 'vw';
      c.style.background = colors[i % colors.length];
      c.style.animationDuration = rand(1.8, 3.4) + 's';
      c.style.animationDelay = rand(0, 0.6) + 's';
      $('overlay').appendChild(c);
      (function (el) { setTimeout(function () { el.remove(); }, 4200); })(c);
    }
  }

  // ================================================================ Varios jugadores (estado común)
  NET.on('state', function (s) {
    var prev = app.snap;
    if (prev && s.seq <= prev.seq && s.event.type !== 'start') return;
    if (s.event.type === 'start') { app.token++; prev = null; }
    var token = app.token;
    app.snap = s;
    app.sent = false;
    var ev = s.event;
    if (app.mode !== 'multi' || app.screen !== 'game') {
      if (ev.type !== 'start' && app.mode !== 'multi') return;
      app.mode = 'multi';
      app.game = null;
    }
    var pname = function (id) { var p = s.players.filter(function (x) { return x.id === id; })[0]; return p ? p.name : ''; };

    switch (ev.type) {
      case 'start':
        closeModal(); hideMock();
        app.matchOver = false; app.rolling = false;
        diceEls[1].style.display = '';
        setTrayMsg('');
        show('game');
        render(); placeDice();
        turnNotice();
        break;
      case 'rolled':
      case 'stuck':
        app.rolling = true;
        setTrayMsg('');
        render();
        animateDice(ev.dice).then(function () {
          if (token !== app.token) return;
          app.rolling = false;
          render();
          if (ev.type === 'stuck') {
            var who = pname(ev.player);
            setTrayMsg(t('cant_make', { n: who, s: ev.sum }));
            A.gameOver(); say(30);
            var pl = s.players.filter(function (x) { return x.id === ev.player; })[0];
            var others = s.players.filter(function (x) { return x.id !== ev.player && !x.disconnected; })
              .map(function (x) { return { name: x.name, photo: infoOf(x.id).photo }; });
            setTimeout(function () { if (token === app.token) showMock(who, infoOf(ev.player).photo, s.mode === 'shared' ? ev.add : (pl ? pl.score : 0), null, others, s.mode === 'shared' && pl ? pl.score : null); }, 1500);
          }
        });
        break;
      case 'select':
        if (NET.role() !== 'local' && curPlayer().id !== NET.myId()) A.select();
        render();
        break;
      case 'confirmed':
      case 'won':
        flapTiles(ev.removed);
        setTimeout(function () { if (token === app.token) render(); }, ev.removed.length * 130);
        if (ev.type === 'won') {
          setTimeout(function () {
            if (token !== app.token) return;
            A.victory(); sayLater(27, 700);
            banner(infoOf(ev.player).photo, pname(ev.player), '¡SHUT THE BOX!', t('x_shut_box', { n: pname(ev.player) }));
            if (s.mode === 'shared' && ev.add) toast(t('others_add', { s: ev.add }));
          }, 600 + ev.removed.length * 130);
        } else setTrayMsg('');
        break;
      case 'round':
        hideMock();
        app.rolling = false;
        diceEls[1].style.display = '';
        setTrayMsg(t('round_n', { n: ev.round }));
        render();
        turnNotice();
        break;
      case 'turn':
        hideMock();
        app.rolling = false;
        setTrayMsg('');
        render();
        if (ev.left) toast(t('x_left', { n: pname(ev.left) }));
        turnNotice();
        break;
      case 'left':
        toast(t('x_left', { n: pname(ev.player) }));
        render();
        break;
      case 'ended':
        app.matchOver = true;
        recordH2H(s);
        render();
        showRanking(s);
        break;
    }
  });

  function showRanking(s) {
    var r = s.ranking || [];
    var top = r[0];
    var tie = r.length > 1 && r[1].rank === 1;
    var iWon = top && !tie && NET.role() !== 'local' && top.id === NET.myId();
    var title = !top ? t('game_over') : tie ? t('tie') : (iWon ? t('you_won') : t('x_wins', { n: top.name }));
    var role = NET.role();
    var buttons;
    if (role === 'client') buttons = '<p class="note">' + t('wait_rematch') + '</p><div class="row"><button class="btn" id="m-menu">' + t('leave') + '</button></div>';
    else buttons = '<div class="row"><button class="btn" id="m-menu">' + t(role === 'host' ? 'leave' : 'menu') + '</button><button class="btn btn-gold" id="m-again">' + t('rematch') + '</button></div>';
    openModal('<h2>' + esc(title) + '</h2>' +
      (top && top.won ? '<p class="verdict">' + t('x_perfect', { n: esc(top.name) }) + '</p>' : '<p class="verdict">' + t(s.mode === 'shared' ? 'shared_end' : 'lowest_wins') + '</p>') +
      '<div class="rank-list">' + r.map(function (p) {
        var f = infoOf(p.id);
        return '<div class="rank-item' + (p.rank === 1 ? ' first' : '') + '"><span class="pos">' + p.rank + '</span>' + faceHtml(f.photo, p.name, 'face-md') +
          '<span class="rname">' + esc(p.name) + (p.won ? '<small>¡Shut the Box!</small>' : p.disconnected ? '<small>' + t('disconnected') + '</small>' : '') + '</span><b>' + p.score + '</b></div>';
      }).join('') + '</div>' + tallyHtml(s) + buttons, leaveMulti);
    $('m-menu').onclick = leaveMulti;
    if ($('m-again')) $('m-again').onclick = function () { closeModal(); NET.rematch(); };
    if (top && !tie) { confetti(); A.victory(); }
    if (tie) sayLater(29, 600); else if (iWon || NET.role() === 'local') sayLater(28, 600);
  }

  function tallyHtml(s) {
    if (!s.tally) return '';
    var rows = s.players.filter(function (p) { return !p.disconnected; }).map(function (p) { return { p: p, w: s.tally[p.id] || 0 }; })
      .sort(function (a, b) { return b.w - a.w; });
    if (!rows.some(function (r) { return r.w > 0; })) return '';
    return '<div class="tally"><small>' + t('tally') + '</small>' + rows.map(function (r) {
      return '<span>' + faceHtml(infoOf(r.p.id).photo, r.p.name, 'face-xs') + esc(r.p.name) + ' <b>' + r.w + '</b></span>';
    }).join('') + '</div>';
  }

  /** Guarda la partida en el historial cara a cara de este móvil. */
  function recordH2H(s) {
    if (!s.ranking || app.h2hSeq === s.seq + ':' + app.token) return;
    app.h2hSeq = s.seq + ':' + app.token;
    S.saveH2H(S.recordPairs(S.loadH2H(), s.ranking));
    S.rememberPeople(s.players.map(function (p) { return { name: p.name, photo: infoOf(p.id).photo }; }));
  }

  function multiRoll() { if (isMyTurn() && !app.sent) { app.sent = NET.role() !== 'local'; NET.act('roll'); render(); } }
  function multiConfirm() { if (isMyTurn() && !app.sent) { app.sent = NET.role() !== 'local'; NET.act('confirm'); render(); } }

  function leaveMulti() {
    closeModal(); hideMock();
    NET.stop();
    app.snap = null;
    app.mode = 'solo';
    app.game = null;
    app.matchOver = true;
    show('menu');
  }

  // ================================================================ Controles comunes
  function onRoll() {
    A.unlock();
    if (app.mode === 'solo') soloRoll(); else multiRoll();
  }

  function onTile(n) {
    if (app.rolling) return;
    var g = app.mode === 'solo' ? app.game : (app.snap ? view() : null);
    if (!g) return;
    if (app.mode === 'multi' && !isMyTurn()) { toast(t(app.snap.phase === 'playing' ? 'wait_turn' : 'game_finished')); return; }
    if (g.state === 'ready') {
      if (g.isOpen(n)) { toast(t('first_roll')); shake(n); A.error(); }
      return;
    }
    if (g.state !== 'choosing') return;
    var r = g.toggle(n);
    if (r.ok) {
      A.select();
      if (app.mode === 'multi') {
        app.snap.selection = g.selection.slice();   // respuesta inmediata en pantalla
        NET.act('toggle', n);
      }
      render();
      return;
    }
    shake(n);
    A.error();
    if (r.reason === 'down') toast(t('already_down'));
    else toast(t('overshoot', { s: g.diceSum - g.selectionSum() }));
  }

  function onCancel() {
    if (app.rolling) return;
    if (app.mode === 'solo') {
      if (app.game.state !== 'choosing') return;
      app.game.clearSelection();
    } else {
      if (!isMyTurn()) return;
      app.snap.selection = [];
      NET.act('clear');
    }
    A.select();
    render();
  }

  function onConfirm() {
    if (app.rolling) return;
    if (app.mode === 'solo') soloConfirm(); else multiConfirm();
  }

  function goMenu() { closeModal(); show('menu'); }

  function leaveGame() {
    if (app.mode === 'multi' && NET.role() !== 'local' && NET.role()) {
      openModal('<h2>' + t('leave_q') + '</h2><p>' + t(NET.role() === 'host' ? 'leave_net_host' : 'leave_net') + '</p>' +
        '<div class="row"><button class="btn" id="m-no">' + t('keep_playing') + '</button><button class="btn btn-gold" id="m-yes">' + t('leave') + '</button></div>');
      $('m-no').onclick = closeModal;
      $('m-yes').onclick = leaveMulti;
      return;
    }
    show('menu');
  }

  function askRestart() {
    var inProgress = app.mode === 'multi' ? true : (app.game && (app.game.moves > 0 || app.game.state === 'choosing'));
    var go = function () { closeModal(); if (app.mode === 'solo') startSolo(); else NET.rematch(); };
    if (!inProgress) { go(); return; }
    openModal('<h2>' + t('restart_q') + '</h2><p>' + t('restart_lost') + '</p>' +
      '<div class="row"><button class="btn" id="m-no">' + t('cancel') + '</button><button class="btn btn-gold" id="m-yes">' + t('restart') + '</button></div>');
    $('m-no').onclick = closeModal;
    $('m-yes').onclick = go;
  }

  // ================================================================ Perfil (nombre + foto)
  function photoMenu(current, name, onChange, onCancel) {
    openModal('<h2>' + t('photo_of', { n: esc(name || t('player')) }) + '</h2>' +
      '<div style="margin:10px 0">' + faceHtml(current, name, 'face-xl') + '</div>' +
      '<div class="menu-buttons"><button class="btn btn-gold" id="ph-cam">' + t('take_photo') + '</button><button class="btn" id="ph-gal">' + t('gallery') + '</button>' +
      (current ? '<button class="btn btn-small" id="ph-del">' + t('remove_photo') + '</button>' : '') +
      '<button class="btn btn-small" id="ph-close">' + t('close') + '</button></div>');
    function pick(cam) {
      closeModal();
      PH.getFace(cam).then(function (data) { if (data) onChange(data); else if (onCancel) onCancel(); });
    }
    $('ph-cam').onclick = function () { pick(true); };
    $('ph-gal').onclick = function () { pick(false); };
    if ($('ph-del')) $('ph-del').onclick = function () { closeModal(); onChange(''); };
    $('ph-close').onclick = closeModal;
  }

  function editProfile(after) {
    var draft = { name: profile.name, photo: profile.photo };
    function draw() {
      openModal('<h2>' + t('your_profile') + '</h2>' +
        '<button class="face face-xl face-btn" id="pf-face"></button>' +
        '<p class="note">' + t('tap_face') + '</p>' +
        '<input type="text" id="pf-name" maxlength="14" placeholder="' + t('your_name') + '" value="' + esc(draft.name) + '" style="width:100%;text-align:center">' +
        '<div class="row"><button class="btn" id="pf-cancel">' + t('cancel') + '</button><button class="btn btn-gold" id="pf-save">' + t('save') + '</button></div>');
      setFaceEl($('pf-face'), draft.photo, draft.name);
      $('pf-face').onclick = function () {
        draft.name = $('pf-name').value.trim();
        photoMenu(draft.photo, draft.name, function (data) { draft.photo = data; draw(); }, draw);
        // al cerrar el menú de foto sin cambios, volver al perfil
        var close = $('ph-close'); if (close) close.onclick = draw;
      };
      $('pf-cancel').onclick = closeModal;
      $('pf-save').onclick = function () {
        draft.name = $('pf-name').value.trim();
        profile = { name: draft.name, photo: draft.photo };
        S.saveProfile(profile);
        closeModal();
        refreshMenu(); refreshNetHome();
        if (after) after();
      };
    }
    draw();
  }

  // ================================================================ Varios jugadores en este móvil
  var setupPlayers = [];
  /** Selector «Cada uno su caja» / «Caja compartida». */
  function renderModePick(container, mode, readonly) {
    var pick = container.querySelector('.mode-pick');
    var bs = pick.querySelectorAll('[data-mode]');
    for (var i = 0; i < bs.length; i++) bs[i].classList.toggle('active', bs[i].dataset.mode === mode);
    pick.classList.toggle('readonly', !!readonly);
    container.querySelector('.mode-desc').textContent = t(mode === 'shared' ? 'mode_shared_desc' : 'mode_boxes_desc');
  }

  function openSetup() {
    var saved = S.loadPlayers();
    if (saved && saved.length >= 2) setupPlayers = saved.slice(0, 4);
    else setupPlayers = [{ name: profile.name || '', photo: profile.photo || '' }, { name: '', photo: '' }];
    renderSetup();
    renderModePick($('screen-setup'), settings.mpMode);
    show('setup');
  }
  function renderSetup() {
    var list = $('setup-list');
    list.innerHTML = setupPlayers.map(function (p, i) {
      return '<div class="setup-card"><button class="face face-md face-btn" data-i="' + i + '"></button>' +
        '<input type="text" maxlength="14" data-i="' + i + '" placeholder="' + t('player_n', { n: i + 1 }) + '" value="' + esc(p.name) + '">' +
        (setupPlayers.length > 2 ? '<button class="del" data-del="' + i + '" aria-label="' + t('remove') + '">✕</button>' : '') + '</div>';
    }).join('');
    var faces = list.querySelectorAll('.face-btn');
    for (var k = 0; k < faces.length; k++) {
      (function (el) {
        var i = +el.dataset.i;
        setFaceEl(el, setupPlayers[i].photo, setupPlayers[i].name || String(i + 1));
        el.onclick = function () {
          readSetupNames();
          photoMenu(setupPlayers[i].photo, setupPlayers[i].name || t('player_n', { n: i + 1 }), function (data) {
            setupPlayers[i].photo = data; S.savePlayers(setupPlayers); renderSetup();
          });
        };
      })(faces[k]);
    }
    var dels = list.querySelectorAll('[data-del]');
    for (var d = 0; d < dels.length; d++) {
      dels[d].onclick = function () { readSetupNames(); setupPlayers.splice(+this.dataset.del, 1); renderSetup(); };
    }
    $('btn-add-player').classList.toggle('hidden', setupPlayers.length >= 4);
  }
  function readSetupNames() {
    var inputs = $('setup-list').querySelectorAll('input');
    for (var i = 0; i < inputs.length; i++) setupPlayers[+inputs[i].dataset.i].name = inputs[i].value.trim();
  }
  function startLocalMatch() {
    readSetupNames();
    var used = {};
    var players = setupPlayers.map(function (p, i) {
      var name = p.name || t('player_n', { n: i + 1 });
      while (used[name]) name += ' ' + (i + 1);
      used[name] = true;
      return { id: 'L' + i, name: name, photo: p.photo || '' };
    });
    S.savePlayers(setupPlayers);
    app.faces = {};
    players.forEach(function (p) { app.faces[p.id] = { name: p.name, photo: p.photo }; });
    app.mode = 'multi';
    app.game = null;
    A.unlock();
    NET.startLocal(players, settings.oneDie, false, settings.mpMode);
  }

  // ================================================================ Partida en red
  function netPanel(name) {
    ['net-home', 'net-search', 'net-lobby'].forEach(function (id) { $(id).classList.toggle('hidden', id !== name); });
  }
  function refreshNetHome() {
    setFaceEl($('net-face'), profile.photo, profile.name);
    $('net-name').textContent = profile.name || t('no_name');
    var ok = NET.available();
    $('net-unavailable').classList.toggle('hidden', ok);
    $('btn-host').disabled = !ok;
    $('btn-search').disabled = !ok;
  }
  function openNet() {
    NET.stop();
    refreshNetHome();
    netPanel('net-home');
    show('net');
  }
  function needProfile(then) {
    if (profile.name) { then(); return; }
    toast(t('need_name'));
    editProfile(then);
  }
  function netBack() {
    var visible = !$('net-home').classList.contains('hidden');
    NET.stop();
    if (visible) show('menu');
    else { refreshNetHome(); netPanel('net-home'); }
  }

  NET.on('lobby', function (players, role, mode) {
    renderModePick($('lobby-mode'), mode || 'boxes', role !== 'host');
    app.faces = {};
    players.forEach(function (p) { app.faces[p.id] = { name: p.name, photo: p.photo }; });
    if (app.screen === 'game' && app.snap && app.snap.phase === 'playing') return;   // alguien nuevo espera la revancha
    if (app.screen !== 'net') show('net');
    netPanel('net-lobby');
    $('lobby-title').textContent = t(role === 'host' ? 'your_game' : 'waiting_room');
    var ipEl = $('lobby-ip');
    ipEl.classList.toggle('hidden', role !== 'host');
    if (role === 'host') ipEl.innerHTML = t('ip_join') + ' <b>' + esc(NET.ip() || t('no_wifi')) + '</b>';
    var html = '';
    for (var i = 0; i < NET.MAX; i++) {
      var p = players[i];
      if (p) html += '<div class="lobby-item">' + faceHtml(p.photo, p.name, 'face-md') + '<span>' + esc(p.name) + '</span>' +
        (i === 0 ? '<span class="tag">' + t('host') + '</span>' : p.id === NET.myId() ? '<span class="tag">' + t('you') + '</span>' : '') + '</div>';
      else html += '<div class="lobby-item empty">' + faceHtml('', '·', 'face-md') + '<span>' + t('waiting_player') + '</span></div>';
    }
    $('lobby-list').innerHTML = html;
    var host = role === 'host';
    $('btn-start-net').classList.toggle('hidden', !host);
    $('btn-start-net').disabled = players.length < 2;
    $('lobby-status').textContent = host
      ? t(players.length < 2 ? 'wait_one' : 'press_start')
      : t('wait_host', { n: players[0] ? players[0].name : t('the_host') });
  });

  NET.on('found', function (list) {
    var el = $('found-list');
    if (!list.length) { el.innerHTML = '<p class="note searching">' + t('searching') + '</p>'; return; }
    el.innerHTML = list.map(function (g) {
      return '<div class="found-item"><span>' + t('game_of', { n: esc(g.name) }) + '</span><button class="btn btn-gold" data-ip="' + esc(g.ip) + '">' + t('join') + '</button></div>';
    }).join('');
    var bs = el.querySelectorAll('[data-ip]');
    for (var i = 0; i < bs.length; i++) bs[i].onclick = function () { joinIp(this.dataset.ip, true); };
  });

  function joinIp(ip, fromList) {
    if (!fromList && !/^\d{1,3}(\.\d{1,3}){3}$/.test(ip)) { toast(t('ip_example')); return; }
    netPanel('net-lobby');
    $('lobby-title').textContent = t('connecting');
    $('lobby-ip').classList.add('hidden');
    $('lobby-list').innerHTML = '';
    $('btn-start-net').classList.add('hidden');
    $('lobby-status').textContent = t('connecting_to', { n: ip });
    NET.join(ip, profile);
  }

  NET.on('status', function (code, p) { $('lobby-status').textContent = t(code, p); });
  NET.on('error', function (code, p) {
    toast(t(code, p));
    if (app.screen === 'net') { refreshNetHome(); netPanel('net-home'); }
  });
  NET.on('left', function (code) {
    hideMock();
    app.snap = null;
    app.mode = 'solo';
    app.game = null;
    app.matchOver = true;
    openModal('<h2>' + t('net_game') + '</h2><p>' + esc(t(code)) + '</p><div class="row"><button class="btn btn-gold" id="m-ok">' + t('ok') + '</button></div>', goMenu);
    $('m-ok').onclick = function () { closeModal(); openNet(); };
  });

  // ================================================================ Botón «atrás» de Android
  window.handleBack = function () {
    if (PH.isEditorOpen()) { PH.cancelEditor(); return true; }
    if (!$('mock').classList.contains('hidden')) { hideMock(); return true; }
    if (!$('overlay').classList.contains('hidden')) { (app.overlayBack || closeModal)(); return true; }
    if (app.screen === 'game') { leaveGame(); return true; }
    if (app.screen === 'net') { netBack(); return true; }
    if (app.screen !== 'menu') { show('menu'); return true; }
    return false;
  };

  // ================================================================ Eventos
  function onAction(action) {
    A.unlock();
    switch (action) {
      case 'new-solo': startSolo(); break;
      case 'setup': openSetup(); break;
      case 'net': openNet(); break;
      case 'net-back': netBack(); break;
      case 'profile': editProfile(); break;
      case 'continue': show('game'); break;
      case 'stats': show('stats'); break;
      case 'rules': show('rules'); break;
      case 'menu': show('menu'); break;
      case 'leave-game': leaveGame(); break;
      case 'restart': askRestart(); break;
      case 'toggle-sound':
        settings.sound = !settings.sound;
        S.saveSettings(settings);
        A.setEnabled(settings.sound);
        if (settings.sound) A.select();
        refreshMenu(); refreshIcons();
        break;
    }
  }

  function init() {
    diceEls = [$('die0'), $('die1')];
    var allDice = document.querySelectorAll('.die');
    for (var i = 0; i < allDice.length; i++) buildDie(allDice[i]);
    buildTiles();

    document.addEventListener('click', function (e) {
      var t = e.target.closest('[data-action]');
      if (t) onAction(t.dataset.action);
    });
    $('mock').addEventListener('click', hideMock);
    var lb = $('lang-row').querySelectorAll('[data-lang]');
    for (var q = 0; q < lb.length; q++) lb[q].addEventListener('click', function () {
      settings.lang = this.dataset.lang;
      S.saveSettings(settings);
      I18N.set(settings.lang);
      refreshMenu(); renderStats(); refreshNetHome();
      renderModePick($('screen-setup'), settings.mpMode);
      renderModePick($('lobby-mode'), NET.mode(), NET.role() === 'client');
      for (var n = 1; n <= 9; n++) tileEls[n].setAttribute('aria-label', t('tile', { n: n }));
      if (app.game || app.snap) render();
    });
    $('btn-roll').addEventListener('click', onRoll);
    // tocar el tapete: los dados dan un saltito y, si se puede, se lanzan
    $('tray').addEventListener('click', function (e) {
      if (e.target.closest('.tray-icons')) return;
      hopDice();
      if (!$('btn-roll').disabled) setTimeout(onRoll, 140);
    });
    $('btn-sound-ig').addEventListener('click', function () {
      settings.sound = !settings.sound; S.saveSettings(settings); A.setEnabled(settings.sound);
      if (settings.sound) A.select();
      toast(t(settings.sound ? 'snd_on' : 'snd_off')); refreshIcons(); refreshMenu();
    });
    $('btn-vib-ig').addEventListener('click', function () {
      settings.vibrate = settings.vibrate === false; S.saveSettings(settings);
      if (settings.vibrate) vibrate('0,60');
      toast(t(settings.vibrate ? 'vib_on' : 'vib_off')); refreshIcons();
      $('opt-vibrate').checked = settings.vibrate;
    });
    var ov = $('opt-vibrate');
    ov.checked = settings.vibrate !== false;
    ov.addEventListener('change', function () { settings.vibrate = ov.checked; S.saveSettings(settings); refreshIcons(); });
    refreshIcons();
    $('btn-confirm').addEventListener('click', onConfirm);
    $('btn-cancel').addEventListener('click', onCancel);

    $('btn-add-player').addEventListener('click', function () {
      readSetupNames();
      if (setupPlayers.length < 4) setupPlayers.push({ name: '', photo: '' });
      renderSetup();
    });
    $('btn-start-local').addEventListener('click', startLocalMatch);
    document.addEventListener('click', function (e) {
      var b = e.target.closest('.mode-pick [data-mode]');
      if (!b || b.parentNode.classList.contains('readonly')) return;
      settings.mpMode = b.dataset.mode;
      S.saveSettings(settings);
      A.select();
      if (app.screen === 'setup') renderModePick($('screen-setup'), settings.mpMode);
      else { NET.setMode(settings.mpMode); renderModePick($('lobby-mode'), settings.mpMode, false); }
    });

    $('btn-host').addEventListener('click', function () {
      needProfile(function () { NET.host(profile, settings.oneDie, settings.mpMode); });
    });
    $('btn-search').addEventListener('click', function () {
      needProfile(function () {
        netPanel('net-search');
        $('found-list').innerHTML = '<p class="note searching">' + t('searching') + '</p>';
        NET.discover();
      });
    });
    $('btn-connect').addEventListener('click', function () { joinIp($('ip-input').value.trim()); });
    $('btn-start-net').addEventListener('click', function () { A.unlock(); NET.hostStartMatch(); });

    $('btn-reset-stats').addEventListener('click', function () {
      var b = this;
      if (b.dataset.armed) { stats = S.resetStats(); S.resetH2H(); renderStats(); toast(t('stats_cleared')); }
      else { b.dataset.armed = '1'; b.textContent = t('press_again'); }
    });

    var opt = $('opt-onedie');
    opt.checked = !!settings.oneDie;
    opt.addEventListener('change', function () {
      settings.oneDie = opt.checked;
      S.saveSettings(settings);
      toast(t('apply_next'));
    });
    var om = $('opt-mock');
    om.checked = settings.mock !== false;
    om.addEventListener('change', function () { settings.mock = om.checked; S.saveSettings(settings); });

    window.addEventListener('resize', function () { if (app.screen === 'game' && !app.rolling) placeDice(); });
    refreshMenu();
  }

  window.STBApp = { state: app };

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();
