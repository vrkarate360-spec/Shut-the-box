/*
 * Shut the Box — interfaz, animaciones y flujo de partida.
 * Modos:  'solo'  → partida individual (Game directo)
 *         'multi' → varios jugadores, en este móvil o en red (estado recibido de STBNet)
 */
(function () {
  'use strict';

  var L = window.STBLogic, S = window.STBStorage, A = window.STBAudio, NET = window.STBNet, PH = window.STBPhoto;
  function $(id) { return document.getElementById(id); }
  function rand(a, b) { return a + Math.random() * (b - a); }
  function esc(t) { return String(t == null ? '' : t).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function sortNum(a) { return a.slice().sort(function (x, y) { return x - y; }); }
  function vibrate(p) { try { if (window.AndroidNet) window.AndroidNet.vibrate(p); else if (navigator.vibrate) navigator.vibrate(p.split(',').map(Number)); } catch (e) { } }

  var settings = S.loadSettings();
  var stats = S.loadStats();
  var profile = S.loadProfile();
  A.setEnabled(settings.sound);

  var app = {
    screen: 'menu',
    mode: 'solo',
    game: null,           // solo
    snap: null,           // multi
    faces: {},            // id → {name, photo}
    rolling: false,
    token: 0,
    overlayBack: null,
    matchOver: false,
    sent: false           // multi: acción enviada, esperando respuesta
  };

  // ================================================================ Caras
  function faceHtml(photo, name, cls) {
    var style = photo ? ' style="background-image:url(\'' + photo + '\')"' : '';
    var initial = photo ? '' : '<span class="initial">' + esc((name || '?').trim().charAt(0).toUpperCase() || '?') + '</span>';
    return '<span class="face ' + (cls || 'face-sm') + '"' + style + '>' + initial + '</span>';
  }
  function setFaceEl(el, photo, name) {
    el.style.backgroundImage = photo ? "url('" + photo + "')" : '';
    el.innerHTML = photo ? '' : '<span class="initial">' + esc((name || '?').trim().charAt(0).toUpperCase() || '?') + '</span>';
  }

  // ================================================================ Dados
  var PIPS = { 1: [4], 2: [0, 8], 3: [0, 4, 8], 4: [0, 2, 6, 8], 5: [0, 2, 4, 6, 8], 6: [0, 2, 3, 5, 6, 8] };
  function buildDie(el) {
    el.innerHTML = '';
    for (var i = 0; i < 9; i++) {
      var p = document.createElement('span');
      p.className = 'pip';
      p.style.left = (24 + (i % 3) * 26) + '%';
      p.style.top = (24 + Math.floor(i / 3) * 26) + '%';
      el.appendChild(p);
    }
    setFace(el, parseInt(el.dataset.v, 10) || 1);
  }
  function setFace(el, v) {
    el.dataset.v = v;
    var on = PIPS[v];
    for (var i = 0; i < 9; i++) el.children[i].classList.toggle('on', on.indexOf(i) !== -1);
  }

  var diceEls = [];
  var diceRest = [{ fx: 0.36, fy: 0.45, rot: -8 }, { fx: 0.64, fy: 0.42, rot: 11 }];
  function dieSize() { return diceEls[0].offsetWidth || 60; }
  function placeDice() {
    var tray = $('tray');
    var W = tray.clientWidth, H = tray.clientHeight, d = dieSize();
    diceEls.forEach(function (el, i) {
      var r = diceRest[i];
      el.style.transform = 'translate(' + (r.fx * W - d / 2) + 'px,' + (r.fy * H - d / 2) + 'px) rotate(' + r.rot + 'deg)';
    });
  }
  function animateDice(values) {
    return new Promise(function (resolve) {
      var tray = $('tray');
      var W = tray.clientWidth, H = tray.clientHeight, d = dieSize();
      var n = values.length;
      diceEls[1].style.display = n === 2 ? '' : 'none';
      var targets = n === 2
        ? [{ fx: rand(0.27, 0.38), fy: rand(0.36, 0.56) }, { fx: rand(0.6, 0.72), fy: rand(0.34, 0.56) }]
        : [{ fx: rand(0.42, 0.58), fy: rand(0.38, 0.52) }];
      var anims = targets.map(function (t, i) {
        return {
          sx: W + d * rand(0.2, 0.8), sy: rand(-d * 0.3, H - d * 0.7) + i * d * 0.3,
          tx: t.fx * W - d / 2, ty: t.fy * H - d / 2,
          spin: rand(500, 900) * (Math.random() < 0.5 ? -1 : 1), rot: rand(-16, 16), fx: t.fx, fy: t.fy
        };
      });
      var dur = 950, t0 = performance.now(), lastFace = 0;
      A.diceRoll(n, dur / 1000);
      function frame(now) {
        var t = Math.min(1, (now - t0) / dur);
        var e = 1 - Math.pow(1 - t, 3);
        for (var i = 0; i < n; i++) {
          var a = anims[i];
          var hop = Math.abs(Math.sin(t * Math.PI * 3.3)) * (1 - t) * 0.3;
          diceEls[i].style.transform = 'translate(' + (a.sx + (a.tx - a.sx) * e) + 'px,' + (a.sy + (a.ty - a.sy) * e) + 'px) rotate(' +
            (a.rot + a.spin * (1 - e)) + 'deg) scale(' + (1 + hop) + ')';
        }
        if (t < 0.9 && now - lastFace > 55 + t * 150) {
          lastFace = now;
          for (var k = 0; k < n; k++) setFace(diceEls[k], 1 + Math.floor(Math.random() * 6));
        }
        if (t < 1) { requestAnimationFrame(frame); return; }
        for (var j = 0; j < n; j++) {
          setFace(diceEls[j], values[j]);
          diceRest[j] = { fx: anims[j].fx, fy: anims[j].fy, rot: anims[j].rot };
        }
        resolve();
      }
      requestAnimationFrame(frame);
    });
  }

  // ================================================================ Fichas
  var tileEls = [];
  function buildTiles() {
    var c = $('tiles');
    c.innerHTML = '';
    for (var n = 1; n <= 9; n++) {
      var b = document.createElement('button');
      b.className = 'tile';
      b.setAttribute('aria-label', 'Ficha ' + n);
      b.innerHTML = '<span class="slot">' + n + '</span><span class="flap"><span class="num">' + n + '</span></span>';
      (function (num) { b.addEventListener('click', function () { onTile(num); }); })(n);
      c.appendChild(b);
      tileEls[n] = b;
    }
  }
  function flapTiles(removed) {
    removed.forEach(function (n, i) {
      A.flap(i * 0.13);
      var el = tileEls[n];
      el.classList.remove('selected');
      setTimeout(function () { el.classList.add('down'); }, i * 130);
    });
  }
  function shake(n) {
    var el = tileEls[n];
    el.classList.remove('shake'); void el.offsetWidth; el.classList.add('shake');
  }

  // ================================================================ Utilidades UI
  var toastTimer = null;
  function toast(msg) {
    var t = $('toast');
    t.textContent = msg;
    t.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { t.classList.remove('show'); }, 2000);
  }
  function setTrayMsg(msg) { $('tray-msg').textContent = msg || ''; }
  function bump(id, value) {
    var el = $(id);
    if (el.textContent !== String(value)) {
      el.textContent = value;
      el.classList.remove('bump'); void el.offsetWidth; el.classList.add('bump');
    }
  }

  function show(name) {
    var screens = document.querySelectorAll('.screen');
    for (var i = 0; i < screens.length; i++) screens[i].classList.toggle('active', screens[i].id === 'screen-' + name);
    app.screen = name;
    if (name === 'menu') refreshMenu();
    if (name === 'stats') renderStats();
    if (name === 'game') requestAnimationFrame(placeDice);
  }

  function openModal(html, onBack) {
    $('modal').innerHTML = html;
    $('overlay').classList.remove('hidden');
    app.overlayBack = onBack || closeModal;
  }
  function closeModal() {
    $('overlay').classList.add('hidden');
    app.overlayBack = null;
  }

  function bestText() { return stats.best === null ? '—' : String(stats.best); }

  function refreshMenu() {
    $('menu-record').textContent = bestText();
    $('btn-sound').textContent = 'Sonido: ' + (settings.sound ? 'activado' : 'desactivado');
    var canContinue = !app.matchOver && ((app.mode === 'solo' && app.game) || (app.mode === 'multi' && NET.role() === 'local' && app.snap));
    $('btn-continue').classList.toggle('hidden', !canContinue);
    setFaceEl($('profile-face'), profile.photo, profile.name);
    $('profile-name').textContent = profile.name ? profile.name : 'Pon tu nombre y tu foto';
  }

  function renderStats() {
    $('st-played').textContent = stats.played;
    $('st-perfect').textContent = stats.perfect;
    var avg = S.average(stats);
    $('st-avg').textContent = avg === null ? '—' : avg.toFixed(1).replace('.', ',');
    $('st-best').textContent = bestText();
    var rb = $('btn-reset-stats');
    rb.dataset.armed = '';
    rb.textContent = 'Borrar estadísticas';
  }

  // ================================================================ Vista del tablero
  /** Devuelve un Game con el estado que hay que dibujar. */
  function view() {
    if (app.mode === 'solo') return app.game;
    var s = app.snap;
    var p = s.players[s.current];
    var g = new L.Game();
    g.open = p.open.slice();
    g.selection = s.selection.slice();
    g.state = s.gstate;
    g.diceSum = s.gstate === 'ready' ? null : s.diceSum;
    g.dice = s.dice;
    g.moves = p.moves;
    return g;
  }
  function curPlayer() { return app.snap.players[app.snap.current]; }
  function infoOf(id) { return app.faces[id] || { name: '?', photo: '' }; }
  function isMyTurn() {
    if (app.mode === 'solo') return true;
    var s = app.snap;
    if (!s || s.phase !== 'playing' || s.pending) return false;
    return NET.role() === 'local' || curPlayer().id === NET.myId();
  }

  function render() {
    var g = (app.mode === 'solo') ? app.game : (app.snap ? view() : null);
    if (!g) return;
    var mine = isMyTurn();
    var choosing = g.state === 'choosing' && !app.rolling;

    for (var n = 1; n <= 9; n++) {
      var el = tileEls[n];
      var open = g.isOpen(n);
      var sel = g.selection.indexOf(n) !== -1;
      el.classList.toggle('down', !open);
      el.classList.toggle('selected', sel);
      el.disabled = !open;
    }
    bump('score', g.score());
    bump('remaining', g.open.length);

    var who = '';
    if (app.mode === 'multi') {
      var s = app.snap, cp = curPlayer(), net = NET.role() !== 'local';
      who = cp.name;
      var me = net && cp.id === NET.myId();
      $('player-label').innerHTML = s.phase === 'ended' ? 'Partida terminada' :
        (me ? '¡Te toca!' : 'Turno de ' + esc(cp.name)) + '<small>' + (net ? 'Partida en red' : 'Varios jugadores · este móvil') + '</small>';
      if (net) {
        var mineP = s.players.filter(function (p) { return p.id === NET.myId(); })[0];
        $('third-label').textContent = 'Tus puntos';
        $('best').textContent = mineP ? mineP.score : '—';
      } else {
        $('third-label').textContent = 'En juego';
        $('best').textContent = s.players.filter(function (p) { return !p.finished; }).length + ' / ' + s.players.length;
      }
      renderStrip();
    } else {
      $('player-label').innerHTML = 'Partida individual';
      $('third-label').textContent = 'Récord';
      $('best').textContent = bestText();
    }

    $('dice-sum').textContent = app.rolling ? '…' : (g.diceSum === null ? '–' : g.diceSum);

    var info = '';
    var watching = app.mode === 'multi' && !mine && NET.role() !== 'local';
    if (app.rolling) info = (watching ? esc(who) + ' lanza…' : 'Lanzando…');
    else if (g.state === 'ready') {
      if (watching) info = esc(who) + ' va a lanzar…';
      else info = g.moves === 0 ? (app.mode === 'multi' ? '<b>' + esc(who) + '</b>, lanza los dados.' : 'Lanza los dados para empezar.') : 'Bien jugado. <b>Lanza de nuevo.</b>';
    } else if (g.state === 'choosing') {
      var sum = g.selectionSum();
      var pre = watching ? esc(who) + ' elige fichas…<br>' : '';
      if (sum === 0) info = pre + (watching ? 'Necesita sumar <b>' + g.diceSum + '</b>.' : 'Elige fichas que sumen <b>' + g.diceSum + '</b>.');
      else if (sum < g.diceSum) info = pre + 'Seleccionado: <b>' + sortNum(g.selection).join(' + ') + ' = ' + sum + '</b><br>Faltan <b>' + (g.diceSum - sum) + '</b>.';
      else info = pre + '<span class="okmsg"><b>' + sortNum(g.selection).join(' + ') + ' = ' + sum + '</b> ✓</span>' + (watching ? '' : '<br>Pulsa <b>Confirmar</b>.');
    } else if (g.state === 'over') info = 'No hay ninguna combinación posible para <b>' + g.diceSum + '</b>.';
    else if (g.state === 'won') info = '<span class="okmsg"><b>¡Caja cerrada!</b></span>';
    $('sel-indicator').innerHTML = info;

    var canAct = mine && !app.sent;
    $('btn-roll').disabled = !canAct || g.state !== 'ready' || app.rolling;
    var complete = canAct && choosing && g.selectionSum() === g.diceSum;
    var cb = $('btn-confirm');
    if (complete && cb.disabled) { cb.classList.remove('ready'); void cb.offsetWidth; cb.classList.add('ready'); }
    if (!complete) cb.classList.remove('ready');
    cb.disabled = !complete;
    $('btn-cancel').disabled = !(canAct && choosing && g.selection.length > 0);

    $('players-strip').classList.toggle('hidden', app.mode !== 'multi');
    $('btn-restart').classList.toggle('hidden', app.mode === 'multi' && NET.role() !== 'local');
  }

  function renderStrip() {
    var s = app.snap;
    $('players-strip').innerHTML = s.players.map(function (p, i) {
      var f = infoOf(p.id);
      var cls = 'pchip' + (i === s.current && s.phase === 'playing' ? ' turn' : '') + (p.finished ? ' out' : '') +
        (p.disconnected ? ' gone' : '') + (p.id === NET.myId() ? ' me' : '');
      return '<div class="' + cls + '">' + faceHtml(f.photo, p.name, 'face-xs') +
        '<span class="pinfo"><span class="pname">' + esc(p.name) + '</span><span class="pscore">' + p.score + '</span></span></div>';
    }).join('');
  }

  // ================================================================ Aviso de turno y burla
  var bannerTimer = null;
  function banner(photo, name, title, sub) {
    var b = $('turn-banner');
    b.innerHTML = faceHtml(photo, name, 'face-lg') + '<div class="bt">' + esc(title) + '</div>' + (sub ? '<div class="bs">' + esc(sub) + '</div>' : '');
    b.classList.remove('hidden');
    b.style.animation = 'none'; void b.offsetWidth; b.style.animation = '';
    clearTimeout(bannerTimer);
    bannerTimer = setTimeout(function () { b.classList.add('hidden'); }, 2300);
  }

  function turnNotice() {
    var s = app.snap;
    if (!s || s.phase !== 'playing') return;
    var cp = curPlayer(), f = infoOf(cp.id);
    if (NET.role() === 'local') {
      A.turnBell(); vibrate('0,200,100,200');
      banner(f.photo, cp.name, 'Turno de ' + cp.name, 'Pásale el móvil');
    } else if (cp.id === NET.myId()) {
      A.turnBell(); vibrate('0,350,150,350');
      banner(f.photo, cp.name, '¡Te toca, ' + cp.name + '!', 'Lanza los dados');
    } else {
      toast('Turno de ' + cp.name);
    }
  }

  var mockTimer = null, mockDone = null;
  function showMock(name, photo, score, then) {
    if (!settings.mock) { if (then) then(); return; }
    var chars = (window.STB_CHARACTERS || []).slice().sort(function () { return Math.random() - 0.5; }).slice(0, 2);
    var talker = chars[0];
    var phrase = '';
    if (talker && talker.phrases && talker.phrases.length) {
      phrase = talker.phrases[Math.floor(Math.random() * talker.phrases.length)]
        .replace(/\{nombre\}/g, name).replace(/\{puntos\}/g, score);
    }
    function charHtml(c, side) {
      if (!c) return '';
      var inner = c.img ? '<img src="' + esc(c.img) + '" alt="">' : c.svg;
      return '<div class="mock-char ' + side + '">' + inner + '</div>';
    }
    var jajas = '';
    for (var i = 0; i < 6; i++) {
      jajas += '<span class="jaja" style="left:' + rand(8, 80) + '%;top:' + rand(5, 60) + '%;animation-delay:' + rand(0.3, 1.4).toFixed(2) + 's">' + (i % 2 ? 'JA' : '¡JA, JA!') + '</span>';
    }
    var m = $('mock');
    m.innerHTML =
      (phrase ? '<div class="mock-bubble"><small>' + esc(talker.name) + '</small>' + esc(phrase) + '</div>' : '') +
      '<div class="mock-stage">' + jajas +
      '<div class="mock-victim">' + faceHtml(photo, name, 'face-xl') +
      '<span class="mock-tear" style="left:30%"></span><span class="mock-tear" style="left:66%;animation-delay:.5s"></span>' +
      '<div class="vname">' + esc(name) + '</div><div class="vscore">' + score + (score === 1 ? ' punto' : ' puntos') + '</div></div>' +
      charHtml(chars[0], 'left') + charHtml(chars[1], 'right') + '</div>' +
      '<div class="mock-hint">Toca para continuar</div>';
    m.classList.remove('hidden');
    A.laugh();
    setTimeout(function () { if (!m.classList.contains('hidden')) A.laugh(); }, 1300);
    mockDone = then || null;
    clearTimeout(mockTimer);
    mockTimer = setTimeout(hideMock, 3800);
  }
  function hideMock() {
    clearTimeout(mockTimer);
    var m = $('mock');
    if (m.classList.contains('hidden')) return;
    m.classList.add('hidden');
    m.innerHTML = '';
    var d = mockDone; mockDone = null;
    if (d) d();
  }

  // ================================================================ Partida individual
  function startSolo() {
    NET.stop();
    closeModal();
    app.mode = 'solo';
    app.snap = null;
    app.matchOver = false;
    app.token++;
    app.game = new L.Game({ oneDieRule: settings.oneDie });
    app.rolling = false;
    app.sent = false;
    diceEls[1].style.display = '';
    setTrayMsg('Pulsa «Lanzar dados»');
    show('game');
    render();
    placeDice();
  }

  function soloRoll() {
    var g = app.game;
    if (app.rolling || g.state !== 'ready') return;
    app.rolling = true;
    var token = app.token;
    var res = g.roll();
    setTrayMsg('');
    render();
    animateDice(res.dice).then(function () {
      if (token !== app.token) return;
      app.rolling = false;
      render();
      if (g.state === 'over') {
        setTrayMsg('Sin combinaciones posibles');
        A.gameOver();
        setTimeout(function () {
          if (token !== app.token) return;
          showMock(profile.name || 'Jugador', profile.photo, g.score(), function () { if (token === app.token) soloEnd(); });
        }, 900);
      }
    });
  }

  function soloConfirm() {
    var g = app.game;
    var removed = g.confirm();
    if (!removed) { A.error(); toast('La suma debe ser exactamente ' + g.diceSum); return; }
    flapTiles(removed);
    var token = app.token;
    setTimeout(function () { if (token === app.token) render(); }, removed.length * 130);
    if (g.state === 'won') {
      setTrayMsg('');
      setTimeout(function () { if (token === app.token) soloVictory(); }, 550 + removed.length * 130);
    } else setTrayMsg('Vuelve a lanzar');
  }

  function recordSolo() {
    var r = S.recordGame(stats, app.game.score());
    stats = r.stats;
    S.saveStats(stats);
    app.matchOver = true;
    return r.newRecord;
  }

  function verdict(score) {
    if (score === 0) return 'Victoria perfecta.';
    if (score <= 5) return '¡Excelente partida!';
    if (score <= 10) return 'Muy buena partida.';
    if (score <= 20) return 'Buena partida.';
    return 'La caja se te ha resistido. ¡Otra!';
  }
  function chipsHtml(open) {
    return open.length ? '<div class="chips">' + open.map(function (n) { return '<div class="chip">' + n + '</div>'; }).join('') + '</div>' : '';
  }
  function soloButtons() {
    return '<div class="row"><button class="btn" id="m-menu">Menú</button><button class="btn btn-gold" id="m-again">Jugar otra vez</button></div>';
  }
  function bindSoloButtons() {
    $('m-menu').onclick = goMenu;
    $('m-again').onclick = startSolo;
  }

  function soloVictory() {
    var rec = recordSolo();
    A.victory();
    openModal('<div class="victory-title">¡SHUT THE BOX!</div><p>Has abatido los nueve números.</p>' +
      '<div class="result-grid"><div><small>Fichas levantadas</small><b>0</b></div><div><small>Puntuación final</small><b>0</b></div></div>' +
      (rec ? '<span class="badge">¡Nuevo récord personal!</span>' : '') + soloButtons(), goMenu);
    bindSoloButtons();
    confetti();
  }

  function soloEnd() {
    var g = app.game, score = g.score();
    var rec = recordSolo();
    openModal('<h2>Fin de partida</h2><p>Ha salido un <b>' + g.diceSum + '</b> y no hay combinación posible.</p>' +
      '<p class="note">Números que quedan levantados:</p>' + chipsHtml(g.open) +
      '<div class="result-grid"><div><small>Suma restante</small><b>' + score + '</b></div><div><small>Puntuación final</small><b>' + score + '</b></div></div>' +
      '<p class="verdict">' + verdict(score) + '</p>' + (rec ? '<span class="badge">¡Nuevo récord personal!</span>' : '') + soloButtons(), goMenu);
    bindSoloButtons();
  }

  function confetti() {
    var colors = ['#e3b866', '#f5ead6', '#c59660', '#8d5631', '#f6dc9c'];
    for (var i = 0; i < 40; i++) {
      var c = document.createElement('div');
      c.className = 'confetti';
      c.style.left = rand(0, 100) + 'vw';
      c.style.background = colors[i % colors.length];
      c.style.animationDuration = rand(1.8, 3.4) + 's';
      c.style.animationDelay = rand(0, 0.6) + 's';
      $('overlay').appendChild(c);
      (function (el) { setTimeout(function () { el.remove(); }, 4200); })(c);
    }
  }

  // ================================================================ Varios jugadores (estado común)
  NET.on('state', function (s) {
    var prev = app.snap;
    if (prev && s.seq <= prev.seq && s.event.type !== 'start') return;
    if (s.event.type === 'start') { app.token++; prev = null; }
    var token = app.token;
    app.snap = s;
    app.sent = false;
    var ev = s.event;
    if (app.mode !== 'multi' || app.screen !== 'game') {
      if (ev.type !== 'start' && app.mode !== 'multi') return;
      app.mode = 'multi';
      app.game = null;
    }
    var pname = function (id) { var p = s.players.filter(function (x) { return x.id === id; })[0]; return p ? p.name : ''; };

    switch (ev.type) {
      case 'start':
        closeModal(); hideMock();
        app.matchOver = false; app.rolling = false;
        diceEls[1].style.display = '';
        setTrayMsg('');
        show('game');
        render(); placeDice();
        turnNotice();
        break;
      case 'rolled':
      case 'stuck':
        app.rolling = true;
        setTrayMsg('');
        render();
        animateDice(ev.dice).then(function () {
          if (token !== app.token) return;
          app.rolling = false;
          render();
          if (ev.type === 'stuck') {
            var who = pname(ev.player);
            setTrayMsg(who + ' no puede hacer ' + ev.sum);
            A.gameOver();
            var pl = s.players.filter(function (x) { return x.id === ev.player; })[0];
            setTimeout(function () { if (token === app.token) showMock(who, infoOf(ev.player).photo, pl ? pl.score : 0); }, 700);
          }
        });
        break;
      case 'select':
        if (NET.role() !== 'local' && curPlayer().id !== NET.myId()) A.select();
        render();
        break;
      case 'confirmed':
      case 'won':
        flapTiles(ev.removed);
        setTimeout(function () { if (token === app.token) render(); }, ev.removed.length * 130);
        if (ev.type === 'won') {
          setTimeout(function () {
            if (token !== app.token) return;
            A.victory();
            banner(infoOf(ev.player).photo, pname(ev.player), '¡SHUT THE BOX!', pname(ev.player) + ' ha cerrado la caja');
          }, 600 + ev.removed.length * 130);
        } else setTrayMsg('');
        break;
      case 'turn':
        app.rolling = false;
        setTrayMsg('');
        render();
        if (ev.left) toast(pname(ev.left) + ' se ha desconectado');
        turnNotice();
        break;
      case 'left':
        toast(pname(ev.player) + ' se ha desconectado');
        render();
        break;
      case 'ended':
        app.matchOver = true;
        render();
        showRanking(s);
        break;
    }
  });

  function showRanking(s) {
    var r = s.ranking || [];
    var top = r[0];
    var tie = r.length > 1 && r[1].rank === 1;
    var title = !top ? 'Fin de la partida' : tie ? '¡Empate!' : (NET.role() !== 'local' && top.id === NET.myId() ? '¡Has ganado!' : '¡Gana ' + top.name + '!');
    var role = NET.role();
    var buttons;
    if (role === 'client') buttons = '<p class="note">Esperando a que el anfitrión decida la revancha…</p><div class="row"><button class="btn" id="m-menu">Salir</button></div>';
    else buttons = '<div class="row"><button class="btn" id="m-menu">' + (role === 'host' ? 'Salir' : 'Menú') + '</button><button class="btn btn-gold" id="m-again">Revancha</button></div>';
    openModal('<h2>' + esc(title) + '</h2>' +
      (top && top.won ? '<p class="verdict">' + esc(top.name) + ' ha cerrado la caja: victoria perfecta.</p>' : '<p class="verdict">Gana la puntuación más baja.</p>') +
      '<div class="rank-list">' + r.map(function (p) {
        var f = infoOf(p.id);
        return '<div class="rank-item' + (p.rank === 1 ? ' first' : '') + '"><span class="pos">' + p.rank + '</span>' + faceHtml(f.photo, p.name, 'face-md') +
          '<span class="rname">' + esc(p.name) + (p.won ? '<small>¡Shut the Box!</small>' : p.disconnected ? '<small>Desconectado</small>' : '') + '</span><b>' + p.score + '</b></div>';
      }).join('') + '</div>' + buttons, leaveMulti);
    $('m-menu').onclick = leaveMulti;
    if ($('m-again')) $('m-again').onclick = function () { closeModal(); NET.rematch(); };
    if (top && !tie) { confetti(); A.victory(); }
  }

  function multiRoll() { if (isMyTurn() && !app.sent) { app.sent = NET.role() !== 'local'; NET.act('roll'); render(); } }
  function multiConfirm() { if (isMyTurn() && !app.sent) { app.sent = NET.role() !== 'local'; NET.act('confirm'); render(); } }

  function leaveMulti() {
    closeModal(); hideMock();
    NET.stop();
    app.snap = null;
    app.mode = 'solo';
    app.game = null;
    app.matchOver = true;
    show('menu');
  }

  // ================================================================ Controles comunes
  function onRoll() {
    A.unlock();
    if (app.mode === 'solo') soloRoll(); else multiRoll();
  }

  function onTile(n) {
    if (app.rolling) return;
    var g = app.mode === 'solo' ? app.game : (app.snap ? view() : null);
    if (!g) return;
    if (app.mode === 'multi' && !isMyTurn()) { toast(app.snap.phase === 'playing' ? 'Espera a tu turno' : 'La partida ha terminado'); return; }
    if (g.state === 'ready') {
      if (g.isOpen(n)) { toast('Primero lanza los dados'); shake(n); A.error(); }
      return;
    }
    if (g.state !== 'choosing') return;
    var r = g.toggle(n);
    if (r.ok) {
      A.select();
      if (app.mode === 'multi') {
        app.snap.selection = g.selection.slice();   // respuesta inmediata en pantalla
        NET.act('toggle', n);
      }
      render();
      return;
    }
    shake(n);
    A.error();
    if (r.reason === 'down') toast('Ese número ya está abatido');
    else toast('Te pasarías: solo faltan ' + (g.diceSum - g.selectionSum()));
  }

  function onCancel() {
    if (app.rolling) return;
    if (app.mode === 'solo') {
      if (app.game.state !== 'choosing') return;
      app.game.clearSelection();
    } else {
      if (!isMyTurn()) return;
      app.snap.selection = [];
      NET.act('clear');
    }
    A.select();
    render();
  }

  function onConfirm() {
    if (app.rolling) return;
    if (app.mode === 'solo') soloConfirm(); else multiConfirm();
  }

  function goMenu() { closeModal(); show('menu'); }

  function leaveGame() {
    if (app.mode === 'multi' && NET.role() !== 'local' && NET.role()) {
      openModal('<h2>¿Salir de la partida?</h2><p>Saldrás de la partida en red' + (NET.role() === 'host' ? ' y se cerrará para todos' : '') + '.</p>' +
        '<div class="row"><button class="btn" id="m-no">Seguir jugando</button><button class="btn btn-gold" id="m-yes">Salir</button></div>');
      $('m-no').onclick = closeModal;
      $('m-yes').onclick = leaveMulti;
      return;
    }
    show('menu');
  }

  function askRestart() {
    var inProgress = app.mode === 'multi' ? true : (app.game && (app.game.moves > 0 || app.game.state === 'choosing'));
    var go = function () { closeModal(); if (app.mode === 'solo') startSolo(); else NET.rematch(); };
    if (!inProgress) { go(); return; }
    openModal('<h2>¿Reiniciar partida?</h2><p>Se perderá la partida en curso.</p>' +
      '<div class="row"><button class="btn" id="m-no">Cancelar</button><button class="btn btn-gold" id="m-yes">Reiniciar</button></div>');
    $('m-no').onclick = closeModal;
    $('m-yes').onclick = go;
  }

  // ================================================================ Perfil (nombre + foto)
  function photoMenu(current, name, onChange, onCancel) {
    openModal('<h2>Foto de ' + esc(name || 'jugador') + '</h2>' +
      '<div style="margin:10px 0">' + faceHtml(current, name, 'face-xl') + '</div>' +
      '<div class="menu-buttons"><button class="btn btn-gold" id="ph-cam">Hacer foto</button><button class="btn" id="ph-gal">Elegir de la galería</button>' +
      (current ? '<button class="btn btn-small" id="ph-del">Quitar foto</button>' : '') +
      '<button class="btn btn-small" id="ph-close">Cerrar</button></div>');
    function pick(cam) {
      closeModal();
      PH.getFace(cam).then(function (data) { if (data) onChange(data); else if (onCancel) onCancel(); });
    }
    $('ph-cam').onclick = function () { pick(true); };
    $('ph-gal').onclick = function () { pick(false); };
    if ($('ph-del')) $('ph-del').onclick = function () { closeModal(); onChange(''); };
    $('ph-close').onclick = closeModal;
  }

  function editProfile(after) {
    var draft = { name: profile.name, photo: profile.photo };
    function draw() {
      openModal('<h2>Tu perfil</h2>' +
        '<button class="face face-xl face-btn" id="pf-face"></button>' +
        '<p class="note">Toca la cara para hacerte una foto.</p>' +
        '<input type="text" id="pf-name" maxlength="14" placeholder="Tu nombre" value="' + esc(draft.name) + '" style="width:100%;text-align:center">' +
        '<div class="row"><button class="btn" id="pf-cancel">Cancelar</button><button class="btn btn-gold" id="pf-save">Guardar</button></div>');
      setFaceEl($('pf-face'), draft.photo, draft.name);
      $('pf-face').onclick = function () {
        draft.name = $('pf-name').value.trim();
        photoMenu(draft.photo, draft.name, function (data) { draft.photo = data; draw(); }, draw);
        // al cerrar el menú de foto sin cambios, volver al perfil
        var close = $('ph-close'); if (close) close.onclick = draw;
      };
      $('pf-cancel').onclick = closeModal;
      $('pf-save').onclick = function () {
        draft.name = $('pf-name').value.trim();
        profile = { name: draft.name, photo: draft.photo };
        S.saveProfile(profile);
        closeModal();
        refreshMenu(); refreshNetHome();
        if (after) after();
      };
    }
    draw();
  }

  // ================================================================ Varios jugadores en este móvil
  var setupPlayers = [];
  function openSetup() {
    var saved = S.loadPlayers();
    if (saved && saved.length >= 2) setupPlayers = saved.slice(0, 4);
    else setupPlayers = [{ name: profile.name || '', photo: profile.photo || '' }, { name: '', photo: '' }];
    renderSetup();
    show('setup');
  }
  function renderSetup() {
    var list = $('setup-list');
    list.innerHTML = setupPlayers.map(function (p, i) {
      return '<div class="setup-card"><button class="face face-md face-btn" data-i="' + i + '"></button>' +
        '<input type="text" maxlength="14" data-i="' + i + '" placeholder="Jugador ' + (i + 1) + '" value="' + esc(p.name) + '">' +
        (setupPlayers.length > 2 ? '<button class="del" data-del="' + i + '" aria-label="Quitar">✕</button>' : '') + '</div>';
    }).join('');
    var faces = list.querySelectorAll('.face-btn');
    for (var k = 0; k < faces.length; k++) {
      (function (el) {
        var i = +el.dataset.i;
        setFaceEl(el, setupPlayers[i].photo, setupPlayers[i].name || String(i + 1));
        el.onclick = function () {
          readSetupNames();
          photoMenu(setupPlayers[i].photo, setupPlayers[i].name || 'Jugador ' + (i + 1), function (data) {
            setupPlayers[i].photo = data; S.savePlayers(setupPlayers); renderSetup();
          });
        };
      })(faces[k]);
    }
    var dels = list.querySelectorAll('[data-del]');
    for (var d = 0; d < dels.length; d++) {
      dels[d].onclick = function () { readSetupNames(); setupPlayers.splice(+this.dataset.del, 1); renderSetup(); };
    }
    $('btn-add-player').classList.toggle('hidden', setupPlayers.length >= 4);
  }
  function readSetupNames() {
    var inputs = $('setup-list').querySelectorAll('input');
    for (var i = 0; i < inputs.length; i++) setupPlayers[+inputs[i].dataset.i].name = inputs[i].value.trim();
  }
  function startLocalMatch() {
    readSetupNames();
    var used = {};
    var players = setupPlayers.map(function (p, i) {
      var name = p.name || 'Jugador ' + (i + 1);
      while (used[name]) name += ' ' + (i + 1);
      used[name] = true;
      return { id: 'L' + i, name: name, photo: p.photo || '' };
    });
    S.savePlayers(setupPlayers);
    app.faces = {};
    players.forEach(function (p) { app.faces[p.id] = { name: p.name, photo: p.photo }; });
    app.mode = 'multi';
    app.game = null;
    A.unlock();
    NET.startLocal(players, settings.oneDie);
  }

  // ================================================================ Partida en red
  function netPanel(name) {
    ['net-home', 'net-search', 'net-lobby'].forEach(function (id) { $(id).classList.toggle('hidden', id !== name); });
  }
  function refreshNetHome() {
    setFaceEl($('net-face'), profile.photo, profile.name);
    $('net-name').textContent = profile.name || 'Sin nombre';
    var ok = NET.available();
    $('net-unavailable').classList.toggle('hidden', ok);
    $('btn-host').disabled = !ok;
    $('btn-search').disabled = !ok;
  }
  function openNet() {
    NET.stop();
    refreshNetHome();
    netPanel('net-home');
    show('net');
  }
  function needProfile(then) {
    if (profile.name) { then(); return; }
    toast('Primero pon tu nombre (y si quieres, tu foto)');
    editProfile(then);
  }
  function netBack() {
    var visible = !$('net-home').classList.contains('hidden');
    NET.stop();
    if (visible) show('menu');
    else { refreshNetHome(); netPanel('net-home'); }
  }

  NET.on('lobby', function (players, role) {
    app.faces = {};
    players.forEach(function (p) { app.faces[p.id] = { name: p.name, photo: p.photo }; });
    if (app.screen === 'game' && app.snap && app.snap.phase === 'playing') return;   // alguien nuevo espera la revancha
    if (app.screen !== 'net') show('net');
    netPanel('net-lobby');
    $('lobby-title').textContent = role === 'host' ? 'Tu partida' : 'Sala de espera';
    var ipEl = $('lobby-ip');
    ipEl.classList.toggle('hidden', role !== 'host');
    if (role === 'host') ipEl.innerHTML = 'IP para unirse: <b>' + esc(NET.ip() || '¿sin WiFi?') + '</b>';
    var html = '';
    for (var i = 0; i < NET.MAX; i++) {
      var p = players[i];
      if (p) html += '<div class="lobby-item">' + faceHtml(p.photo, p.name, 'face-md') + '<span>' + esc(p.name) + '</span>' +
        (i === 0 ? '<span class="tag">Anfitrión</span>' : p.id === NET.myId() ? '<span class="tag">Tú</span>' : '') + '</div>';
      else html += '<div class="lobby-item empty">' + faceHtml('', '·', 'face-md') + '<span>Esperando jugador…</span></div>';
    }
    $('lobby-list').innerHTML = html;
    var host = role === 'host';
    $('btn-start-net').classList.toggle('hidden', !host);
    $('btn-start-net').disabled = players.length < 2;
    $('lobby-status').textContent = host
      ? (players.length < 2 ? 'Esperando a que se una al menos otro jugador…' : 'Pulsa «Empezar» cuando estéis todos (máximo 4).')
      : 'Esperando a que ' + (players[0] ? players[0].name : 'el anfitrión') + ' empiece la partida…';
  });

  NET.on('found', function (list) {
    var el = $('found-list');
    if (!list.length) { el.innerHTML = '<p class="note searching">Buscando partidas en tu WiFi…</p>'; return; }
    el.innerHTML = list.map(function (g) {
      return '<div class="found-item"><span>Partida de <b>' + esc(g.name) + '</b></span><button class="btn btn-gold" data-ip="' + esc(g.ip) + '">Unirse</button></div>';
    }).join('');
    var bs = el.querySelectorAll('[data-ip]');
    for (var i = 0; i < bs.length; i++) bs[i].onclick = function () { joinIp(this.dataset.ip, true); };
  });

  function joinIp(ip, fromList) {
    if (!fromList && !/^\d{1,3}(\.\d{1,3}){3}$/.test(ip)) { toast('Escribe una IP como 192.168.1.20'); return; }
    netPanel('net-lobby');
    $('lobby-title').textContent = 'Conectando…';
    $('lobby-ip').classList.add('hidden');
    $('lobby-list').innerHTML = '';
    $('btn-start-net').classList.add('hidden');
    $('lobby-status').textContent = 'Conectando con ' + ip + '…';
    NET.join(ip, profile);
  }

  NET.on('status', function (msg) { $('lobby-status').textContent = msg; });
  NET.on('error', function (msg) {
    toast(msg);
    if (app.screen === 'net') { refreshNetHome(); netPanel('net-home'); }
  });
  NET.on('left', function (msg) {
    hideMock();
    app.snap = null;
    app.mode = 'solo';
    app.game = null;
    app.matchOver = true;
    openModal('<h2>Partida en red</h2><p>' + esc(msg) + '</p><div class="row"><button class="btn btn-gold" id="m-ok">Aceptar</button></div>', goMenu);
    $('m-ok').onclick = function () { closeModal(); openNet(); };
  });

  // ================================================================ Botón «atrás» de Android
  window.handleBack = function () {
    if (PH.isEditorOpen()) { PH.cancelEditor(); return true; }
    if (!$('mock').classList.contains('hidden')) { hideMock(); return true; }
    if (!$('overlay').classList.contains('hidden')) { (app.overlayBack || closeModal)(); return true; }
    if (app.screen === 'game') { leaveGame(); return true; }
    if (app.screen === 'net') { netBack(); return true; }
    if (app.screen !== 'menu') { show('menu'); return true; }
    return false;
  };

  // ================================================================ Eventos
  function onAction(action) {
    A.unlock();
    switch (action) {
      case 'new-solo': startSolo(); break;
      case 'setup': openSetup(); break;
      case 'net': openNet(); break;
      case 'net-back': netBack(); break;
      case 'profile': editProfile(); break;
      case 'continue': show('game'); break;
      case 'stats': show('stats'); break;
      case 'rules': show('rules'); break;
      case 'menu': show('menu'); break;
      case 'leave-game': leaveGame(); break;
      case 'restart': askRestart(); break;
      case 'toggle-sound':
        settings.sound = !settings.sound;
        S.saveSettings(settings);
        A.setEnabled(settings.sound);
        if (settings.sound) A.select();
        refreshMenu();
        break;
    }
  }

  function init() {
    diceEls = [$('die0'), $('die1')];
    var allDice = document.querySelectorAll('.die');
    for (var i = 0; i < allDice.length; i++) buildDie(allDice[i]);
    buildTiles();

    document.addEventListener('click', function (e) {
      var t = e.target.closest('[data-action]');
      if (t) onAction(t.dataset.action);
    });
    $('mock').addEventListener('click', hideMock);
    $('btn-roll').addEventListener('click', onRoll);
    $('btn-confirm').addEventListener('click', onConfirm);
    $('btn-cancel').addEventListener('click', onCancel);

    $('btn-add-player').addEventListener('click', function () {
      readSetupNames();
      if (setupPlayers.length < 4) setupPlayers.push({ name: '', photo: '' });
      renderSetup();
    });
    $('btn-start-local').addEventListener('click', startLocalMatch);

    $('btn-host').addEventListener('click', function () {
      needProfile(function () { if (NET.host(profile, settings.oneDie)) { /* la sala se muestra con el evento lobby */ } });
    });
    $('btn-search').addEventListener('click', function () {
      needProfile(function () {
        netPanel('net-search');
        $('found-list').innerHTML = '<p class="note searching">Buscando partidas en tu WiFi…</p>';
        NET.discover();
      });
    });
    $('btn-connect').addEventListener('click', function () { joinIp($('ip-input').value.trim()); });
    $('btn-start-net').addEventListener('click', function () { A.unlock(); NET.hostStartMatch(); });

    $('btn-reset-stats').addEventListener('click', function () {
      var b = this;
      if (b.dataset.armed) { stats = S.resetStats(); renderStats(); toast('Estadísticas borradas'); }
      else { b.dataset.armed = '1'; b.textContent = 'Pulsa otra vez para confirmar'; }
    });

    var opt = $('opt-onedie');
    opt.checked = !!settings.oneDie;
    opt.addEventListener('change', function () {
      settings.oneDie = opt.checked;
      S.saveSettings(settings);
      toast('Se aplicará en la próxima partida');
    });
    var om = $('opt-mock');
    om.checked = settings.mock !== false;
    om.addEventListener('change', function () { settings.mock = om.checked; S.saveSettings(settings); });

    window.addEventListener('resize', function () { if (app.screen === 'game' && !app.rolling) placeDice(); });
    refreshMenu();
  }

  window.STBApp = { state: app };

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();
