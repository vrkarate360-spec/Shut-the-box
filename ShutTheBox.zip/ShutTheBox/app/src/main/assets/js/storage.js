/*
 * Shut the Box — guardado local de ajustes, estadísticas y récord (localStorage, sin Internet).
 */
(function (root) {
  'use strict';

  var KEY_STATS = 'stb.stats.v1';
  var KEY_SETTINGS = 'stb.settings.v1';

  var DEFAULT_STATS = { played: 0, perfect: 0, totalScore: 0, best: null };
  var DEFAULT_SETTINGS = { sound: true, oneDie: false, mock: true };
  var KEY_PROFILE = 'stb.profile.v1';
  var KEY_PLAYERS = 'stb.players.v1';

  function clone(o) { return JSON.parse(JSON.stringify(o)); }

  function read(key, def) {
    try {
      var raw = root.localStorage && root.localStorage.getItem(key);
      if (!raw) return clone(def);
      var obj = JSON.parse(raw);
      var out = clone(def);
      for (var k in def) if (Object.prototype.hasOwnProperty.call(obj, k)) out[k] = obj[k];
      return out;
    } catch (e) { return clone(def); }
  }

  function write(key, value) {
    try { root.localStorage && root.localStorage.setItem(key, JSON.stringify(value)); } catch (e) { /* sin espacio: se ignora */ }
  }

  /** Registra una partida terminada (función pura). */
  function recordGame(stats, score) {
    var s = clone(stats);
    s.played += 1;
    s.totalScore += score;
    if (score === 0) s.perfect += 1;
    var newRecord = s.best === null || score < s.best;
    if (newRecord) s.best = score;
    return { stats: s, newRecord: newRecord };
  }

  function average(stats) {
    return stats.played ? stats.totalScore / stats.played : null;
  }

  var api = {
    DEFAULT_STATS: DEFAULT_STATS,
    DEFAULT_SETTINGS: DEFAULT_SETTINGS,
    loadStats: function () { return read(KEY_STATS, DEFAULT_STATS); },
    saveStats: function (s) { write(KEY_STATS, s); },
    resetStats: function () { var s = clone(DEFAULT_STATS); write(KEY_STATS, s); return s; },
    loadSettings: function () { return read(KEY_SETTINGS, DEFAULT_SETTINGS); },
    saveSettings: function (s) { write(KEY_SETTINGS, s); },
    loadProfile: function () { return read(KEY_PROFILE, { name: '', photo: '' }); },
    saveProfile: function (p) { write(KEY_PROFILE, { name: p.name || '', photo: p.photo || '' }); },
    loadPlayers: function () {
      try { var a = JSON.parse(root.localStorage.getItem(KEY_PLAYERS)); return Array.isArray(a) ? a : null; } catch (e) { return null; }
    },
    savePlayers: function (list) { write(KEY_PLAYERS, list.map(function (p) { return { name: p.name || '', photo: p.photo || '' }; })); },
    recordGame: recordGame,
    average: average
  };

  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.STBStorage = api;
})(typeof window !== 'undefined' ? window : this);
