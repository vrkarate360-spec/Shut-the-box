/*
 * Shut the Box — guardado local de ajustes, estadísticas y récord (localStorage, sin Internet).
 */
(function (root) {
  'use strict';

  var KEY_STATS = 'stb.stats.v1';
  var KEY_SETTINGS = 'stb.settings.v1';

  var DEFAULT_STATS = { played: 0, perfect: 0, totalScore: 0, best: null };
  var DEFAULT_SETTINGS = { sound: true, oneDie: false, mock: true, lang: '' };
  var KEY_PROFILE = 'stb.profile.v1';
  var KEY_H2H = 'stb.h2h.v1';
  var KEY_PEOPLE = 'stb.people.v1';
  var KEY_PLAYERS = 'stb.players.v1';

  function clone(o) { return JSON.parse(JSON.stringify(o)); }

  function read(key, def) {
    try {
      var raw = root.localStorage && root.localStorage.getItem(key);
      if (!raw) return clone(def);
      var obj = JSON.parse(raw);
      var out = clone(def);
      for (var k in def) if (Object.prototype.hasOwnProperty.call(obj, k)) out[k] = obj[k];
      return out;
    } catch (e) { return clone(def); }
  }

  function write(key, value) {
    try { root.localStorage && root.localStorage.setItem(key, JSON.stringify(value)); } catch (e) { /* sin espacio: se ignora */ }
  }

  /** Registra una partida terminada (función pura). */
  function recordGame(stats, score) {
    var s = clone(stats);
    s.played += 1;
    s.totalScore += score;
    if (score === 0) s.perfect += 1;
    var newRecord = s.best === null || score < s.best;
    if (newRecord) s.best = score;
    return { stats: s, newRecord: newRecord };
  }

  function nkey(name) { return String(name || '').trim().toLowerCase(); }

  /**
   * Suma una partida de varios jugadores al historial cara a cara (función pura).
   * ranking: [{name, rank, won, disconnected}]; por cada pareja gana quien queda mejor clasificado.
   */
  function recordPairs(h2h, ranking) {
    var out = clone(h2h || {});
    var list = (ranking || []).filter(function (r) { return !r.disconnected && nkey(r.name); });
    var now = Date.now();
    for (var i = 0; i < list.length; i++) {
      for (var j = i + 1; j < list.length; j++) {
        var a = list[i], b = list[j];
        if (nkey(a.name) === nkey(b.name)) continue;
        if (nkey(a.name) > nkey(b.name)) { var tmp = a; a = b; b = tmp; }
        var k = nkey(a.name) + '|' + nkey(b.name);
        var e = out[k] || { a: a.name, b: b.name, wa: 0, wb: 0, t: 0, sa: 0, sb: 0, last: 0 };
        e.a = a.name; e.b = b.name;
        if (a.rank < b.rank) e.wa++; else if (b.rank < a.rank) e.wb++; else e.t++;
        if (a.won) e.sa++;
        if (b.won) e.sb++;
        e.last = now;
        out[k] = e;
      }
    }
    return out;
  }

  function average(stats) {
    return stats.played ? stats.totalScore / stats.played : null;
  }

  var api = {
    DEFAULT_STATS: DEFAULT_STATS,
    DEFAULT_SETTINGS: DEFAULT_SETTINGS,
    loadStats: function () { return read(KEY_STATS, DEFAULT_STATS); },
    saveStats: function (s) { write(KEY_STATS, s); },
    resetStats: function () { var s = clone(DEFAULT_STATS); write(KEY_STATS, s); return s; },
    loadSettings: function () { return read(KEY_SETTINGS, DEFAULT_SETTINGS); },
    saveSettings: function (s) { write(KEY_SETTINGS, s); },
    loadProfile: function () { return read(KEY_PROFILE, { name: '', photo: '' }); },
    saveProfile: function (p) { write(KEY_PROFILE, { name: p.name || '', photo: p.photo || '' }); },
    loadPlayers: function () {
      try { var a = JSON.parse(root.localStorage.getItem(KEY_PLAYERS)); return Array.isArray(a) ? a : null; } catch (e) { return null; }
    },
    savePlayers: function (list) { write(KEY_PLAYERS, list.map(function (p) { return { name: p.name || '', photo: p.photo || '' }; })); },
    recordGame: recordGame,
    recordPairs: recordPairs,
    loadH2H: function () { try { return JSON.parse(root.localStorage.getItem(KEY_H2H)) || {}; } catch (e) { return {}; } },
    saveH2H: function (h) { write(KEY_H2H, h); },
    resetH2H: function () { write(KEY_H2H, {}); return {}; },
    /** Última foto conocida de cada jugador (para el historial). Máximo 30 personas. */
    rememberPeople: function (list) {
      var people;
      try { people = JSON.parse(root.localStorage.getItem(KEY_PEOPLE)) || {}; } catch (e) { people = {}; }
      list.forEach(function (p) { var k = nkey(p.name); if (k) people[k] = { name: p.name, photo: p.photo || (people[k] && people[k].photo) || '', ts: Date.now() }; });
      var keys = Object.keys(people).sort(function (x, y) { return people[y].ts - people[x].ts; });
      keys.slice(30).forEach(function (k) { delete people[k]; });
      write(KEY_PEOPLE, people);
    },
    loadPeople: function () { try { return JSON.parse(root.localStorage.getItem(KEY_PEOPLE)) || {}; } catch (e) { return {}; } },
    nkey: nkey,
    average: average
  };

  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.STBStorage = api;
})(typeof window !== 'undefined' ? window : this);
