/*
 * Shut the Box — lógica del juego (sin dependencias de interfaz).
 * Se puede usar en el navegador (window.STBLogic) y en Node (require) para los tests.
 */
(function (root) {
  'use strict';

  var ALL = [1, 2, 3, 4, 5, 6, 7, 8, 9];

  function sum(arr) {
    var s = 0;
    for (var i = 0; i < arr.length; i++) s += arr[i];
    return s;
  }

  /** Todas las combinaciones (sin repetir números) de `open` que suman exactamente `target`. */
  function combos(target, open) {
    var res = [];
    var arr = open.slice().sort(function (a, b) { return a - b; });
    if (target <= 0) return res;
    (function rec(i, acc, cur) {
      if (acc === target) { res.push(cur.slice()); return; }
      for (var j = i; j < arr.length; j++) {
        if (acc + arr[j] > target) break;
        cur.push(arr[j]);
        rec(j + 1, acc + arr[j], cur);
        cur.pop();
      }
    })(0, 0, []);
    return res;
  }

  /** ¿Existe al menos una combinación válida? (versión rápida, sin listar todas) */
  function hasMove(target, open) {
    if (target <= 0) return false;
    var arr = open.slice().sort(function (a, b) { return b - a; });
    return (function rec(i, rest) {
      if (rest === 0) return true;
      for (var j = i; j < arr.length; j++) {
        if (arr[j] <= rest && rec(j + 1, rest - arr[j])) return true;
      }
      return false;
    })(0, target);
  }

  /** Una selección es válida si: no hay repetidos, todos están levantados y la suma coincide. */
  function isValidSelection(sel, open, target) {
    if (!sel || sel.length === 0) return false;
    var seen = {};
    for (var i = 0; i < sel.length; i++) {
      var n = sel[i];
      if (seen[n]) return false;
      seen[n] = true;
      if (open.indexOf(n) === -1) return false;
    }
    return sum(sel) === target;
  }

  function Game(opts) {
    opts = opts || {};
    this.oneDieRule = !!opts.oneDieRule;
    this.assist = !!opts.assist;   // true: solo deja elegir fichas que completan una combinación
    this.rng = opts.rng || Math.random;
    this.reset();
  }

  Game.prototype.reset = function () {
    this.open = ALL.slice();      // fichas levantadas
    this.dice = [];               // valores de la última tirada
    this.diceSum = null;
    this.selection = [];
    this.state = 'ready';         // ready | choosing | over | won
    this.moves = 0;
    this.lastRemoved = [];
  };

  Game.prototype.isOpen = function (n) { return this.open.indexOf(n) !== -1; };
  Game.prototype.score = function () { return sum(this.open); };
  Game.prototype.selectionSum = function () { return sum(this.selection); };
  Game.prototype.isFinished = function () { return this.state === 'over' || this.state === 'won'; };

  /** Regla opcional clásica: con 7, 8 y 9 abatidos se lanza un solo dado. */
  Game.prototype.diceCount = function () {
    if (!this.oneDieRule) return 2;
    for (var i = 0; i < this.open.length; i++) if (this.open[i] >= 7) return 2;
    return 1;
  };

  /** Lanza los dados. `forced` (opcional) fija los valores, útil para tests. */
  Game.prototype.roll = function (forced) {
    if (this.state !== 'ready') throw new Error('No se puede lanzar en el estado ' + this.state);
    var k = this.diceCount();
    var dice;
    if (forced) {
      if (forced.length !== k) throw new Error('Número de dados incorrecto');
      forced.forEach(function (v) { if (v < 1 || v > 6 || v !== Math.floor(v)) throw new Error('Valor de dado no válido'); });
      dice = forced.slice();
    } else {
      dice = [];
      for (var i = 0; i < k; i++) dice.push(1 + Math.floor(this.rng() * 6));
    }
    this.dice = dice;
    this.diceSum = sum(dice);
    this.selection = [];
    this.state = hasMove(this.diceSum, this.open) ? 'choosing' : 'over';
    return { dice: dice.slice(), sum: this.diceSum, state: this.state };
  };

  /**
   * ¿Se puede añadir `n` a la selección actual?
   * Solo si está levantada, no está ya seleccionada y la selección resultante
   * todavía puede completarse hasta la suma exacta de los dados.
   */
  Game.prototype.canSelect = function (n) {
    if (this.state !== 'choosing') return false;
    if (!this.isOpen(n) || this.selection.indexOf(n) !== -1) return false;
    var rest = this.diceSum - this.selectionSum() - n;
    if (rest < 0) return false;          // nunca se puede pasar de la suma
    if (rest === 0 || !this.assist) return true;
    var sel = this.selection;
    var avail = this.open.filter(function (x) { return x !== n && sel.indexOf(x) === -1; });
    return hasMove(rest, avail);
  };

  /** Selecciona o deselecciona una ficha. Devuelve {ok, selected?, reason?}. */
  Game.prototype.toggle = function (n) {
    if (this.state !== 'choosing') return { ok: false, reason: 'state' };
    if (!this.isOpen(n)) return { ok: false, reason: 'down' };
    var idx = this.selection.indexOf(n);
    if (idx !== -1) {
      this.selection.splice(idx, 1);
      return { ok: true, selected: false };
    }
    if (!this.canSelect(n)) return { ok: false, reason: 'nofit' };
    this.selection.push(n);
    return { ok: true, selected: true };
  };

  Game.prototype.clearSelection = function () { this.selection = []; };

  /** Confirma la jugada. Devuelve las fichas abatidas o null si no es válida. */
  Game.prototype.confirm = function () {
    if (this.state !== 'choosing') return null;
    if (!isValidSelection(this.selection, this.open, this.diceSum)) return null;
    var removed = this.selection.slice().sort(function (a, b) { return a - b; });
    this.open = this.open.filter(function (x) { return removed.indexOf(x) === -1; });
    this.selection = [];
    this.moves++;
    this.lastRemoved = removed;
    this.state = this.open.length === 0 ? 'won' : 'ready';
    return removed;
  };

  var api = {
    ALL: ALL,
    sum: sum,
    combos: combos,
    hasMove: hasMove,
    isValidSelection: isValidSelection,
    Game: Game
  };

  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.STBLogic = api;
})(this);
