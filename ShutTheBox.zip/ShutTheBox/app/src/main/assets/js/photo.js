/*
 * Shut the Box — fotos de los jugadores: hacer foto / elegir de la galería y encuadrar la cara.
 * En Android usa la cámara del móvil (AndroidApp); en el navegador, un selector de archivos.
 */
(function (root) {
  'use strict';

  var OUT = 256;          // tamaño final de la cara (px)
  var pending = null;

  function fromBrowser(useCamera) {
    return new Promise(function (resolve) {
      var inp = document.createElement('input');
      inp.type = 'file';
      inp.accept = 'image/*';
      if (useCamera) inp.setAttribute('capture', 'user');
      inp.onchange = function () {
        var f = inp.files && inp.files[0];
        if (!f) return resolve(null);
        var r = new FileReader();
        r.onload = function () { resolve(r.result); };
        r.onerror = function () { resolve(null); };
        r.readAsDataURL(f);
      };
      inp.click();
    });
  }

  /** Obtiene una imagen (dataURL) de la cámara o la galería. */
  function capture(useCamera) {
    if (root.AndroidApp) {
      return new Promise(function (resolve) {
        pending = resolve;
        if (useCamera) root.AndroidApp.takePhoto(); else root.AndroidApp.pickPhoto();
      });
    }
    return fromBrowser(useCamera);
  }

  // Llamado desde Android con el resultado
  function _done(dataUrl) {
    var p = pending;
    pending = null;
    if (p) p(dataUrl || null);
  }

  /** Editor: arrastrar y ampliar para encuadrar la cara en el círculo. Devuelve dataURL o null. */
  function editor(src) {
    return new Promise(function (resolve) {
      var layer = document.getElementById('photo-editor');
      layer.innerHTML =
        '<div class="pe-box wood">' +
        '<h2>' + t('pe_title') + '</h2>' +
        '<div class="pe-frame" id="pe-frame"><img id="pe-img" alt=""><div class="pe-guide"><span class="g-eyes"></span><span class="g-mouth"></span></div></div>' +
        '<p class="note">' + t('pe_note') + '</p>' +
        '<input type="range" id="pe-zoom" min="1" max="4" step="0.01" value="1.6">' +
        '<div class="row"><button class="btn" id="pe-cancel">' + t('cancel') + '</button><button class="btn btn-gold" id="pe-ok">' + t('use_photo') + '</button></div>' +
        '</div>';
      layer.classList.remove('hidden');

      var frame = document.getElementById('pe-frame');
      var img = document.getElementById('pe-img');
      var zoom = document.getElementById('pe-zoom');
      var D, bs, dx = 0, dy = 0;

      function size() { return { w: img.naturalWidth * bs * zoom.value, h: img.naturalHeight * bs * zoom.value }; }
      function clamp() {
        var s = size();
        var mx = Math.max(0, (s.w - D) / 2), my = Math.max(0, (s.h - D) / 2);
        dx = Math.max(-mx, Math.min(mx, dx));
        dy = Math.max(-my, Math.min(my, dy));
      }
      function draw() {
        clamp();
        var s = size();
        img.style.width = s.w + 'px';
        img.style.height = s.h + 'px';
        img.style.left = ((D - s.w) / 2 + dx) + 'px';
        img.style.top = ((D - s.h) / 2 + dy) + 'px';
      }

      img.onload = function () {
        D = frame.clientWidth;
        bs = Math.max(D / img.naturalWidth, D / img.naturalHeight);
        dy = img.naturalHeight > img.naturalWidth ? D * 0.08 : 0;   // caras suelen estar arriba
        draw();
      };
      img.src = src;

      var drag = null;
      frame.addEventListener('pointerdown', function (e) {
        drag = { x: e.clientX, y: e.clientY, dx: dx, dy: dy };
        frame.setPointerCapture(e.pointerId);
      });
      frame.addEventListener('pointermove', function (e) {
        if (!drag) return;
        dx = drag.dx + (e.clientX - drag.x);
        dy = drag.dy + (e.clientY - drag.y);
        draw();
      });
      frame.addEventListener('pointerup', function () { drag = null; });
      frame.addEventListener('pointercancel', function () { drag = null; });
      zoom.addEventListener('input', draw);

      function close(result) {
        layer.classList.add('hidden');
        layer.innerHTML = '';
        resolve(result);
      }
      document.getElementById('pe-cancel').onclick = function () { close(null); };
      document.getElementById('pe-ok').onclick = function () {
        var s = size();
        var k = OUT / D;
        var c = document.createElement('canvas');
        c.width = c.height = OUT;
        var ctx = c.getContext('2d');
        ctx.fillStyle = '#6f3f1f';
        ctx.fillRect(0, 0, OUT, OUT);
        ctx.drawImage(img, ((D - s.w) / 2 + dx) * k, ((D - s.h) / 2 + dy) * k, s.w * k, s.h * k);
        close(c.toDataURL('image/jpeg', 0.82));
      };
      api.cancelEditor = function () { close(null); };
    });
  }

  /** Flujo completo: cámara o galería → encuadre. */
  function getFace(useCamera) {
    return capture(useCamera).then(function (src) { return src ? editor(src) : null; });
  }

  var api = {
    getFace: getFace,
    _done: _done,
    isEditorOpen: function () { var l = document.getElementById('photo-editor'); return l && !l.classList.contains('hidden'); },
    cancelEditor: function () {}
  };
  root.STBPhoto = api;
})(window);
