/*
 * Shut the Box — idiomas: español (es), inglés (en) y danés (da).
 * Cada móvil guarda su propio idioma; en las partidas en red cada uno ve el suyo.
 * Uso: t('clave', {n: 'Alex', s: 8})  ·  en HTML: data-i18n="clave" (texto) / data-i18n-html / data-i18n-ph (placeholder)
 */
(function (root) {
  'use strict';

  var D = {
    es: {
      lang_name: 'Español', opt_vibrate: 'Vibración del móvil (aviso de turno).', vib_on: 'Vibración activada', vib_off: 'Vibración desactivada', snd_on: 'Sonido activado', snd_off: 'Sonido desactivado', author: 'Un juego de Alex Gabarró',
      mode_boxes: 'Cada uno su caja', mode_shared: 'Caja compartida', mode_boxes_desc: 'Cada jugador tiene su propia caja. Gana la puntuación más baja.', mode_shared_desc: 'Una sola caja: juegas con lo que deja el otro. Quien no puede jugar suma lo que queda levantado; si alguien cierra la caja, los demás suman 10. Cuando alguien llega a 45, gana quien menos tenga.', round: 'Ronda', round_n: 'Ronda {n}', adds: '+{a} · total {s}', others_add: 'Los demás suman {s}', shared_end: 'Alguien ha llegado a 45: gana quien menos ha acumulado.',
      tally: 'Marcador', h2h_title: 'Cara a cara', h2h_empty: 'Todavía no hay partidas contra otros jugadores.', h2h_note: 'Partidas de varios jugadores jugadas con este móvil.', ties1: '1 empate', ties: '{s} empates', shuts: 'cajas cerradas', wins_short: 'victorias',
      profile_cta: 'Pon tu nombre y tu foto', subtitle: 'Cierra la caja', continue: 'Continuar partida', new_game: 'Nueva partida',
      local_multi: 'Varios jugadores · este móvil', net_multi: 'Jugar en red · varios móviles', stats: 'Estadísticas', rules: 'Reglas',
      sound_on: 'Sonido: activado', sound_off: 'Sonido: desactivado', record: 'Récord personal:', version: 'Versión 2.0',
      menu_btn: '‹ Menú', back: '‹ Volver', restart_btn: '↻ Reiniciar', score: 'Puntuación', left: 'Quedan', best: 'Récord', dice: 'Dados',
      roll: 'LANZAR DADOS', cancel: 'Cancelar', confirm: 'Confirmar', solo_label: 'Partida individual', ended_label: 'Partida terminada',
      your_turn: '¡Te toca!', turn_of: 'Turno de {n}', net_game: 'Partida en red', your_points: 'Tus puntos', in_play: 'En juego',
      rolling: 'Lanzando…', x_rolls: '{n} lanza…', x_will_roll: '{n} va a lanzar…', x_roll_now: '<b>{n}</b>, lanza los dados.',
      start_roll: 'Lanza los dados para empezar.', well_played: 'Bien jugado. <b>Lanza de nuevo.</b>', x_choosing: '{n} elige fichas…',
      needs_sum: 'Necesita sumar <b>{s}</b>.', choose_sum: 'Elige fichas que sumen <b>{s}</b>.', selected: 'Seleccionado:',
      missing: 'Faltan <b>{s}</b>.', press_confirm: 'Pulsa <b>Confirmar</b>.', no_combo: 'No hay ninguna combinación posible para <b>{s}</b>.',
      box_shut: '¡Caja cerrada!', pass_phone: 'Pásale el móvil', your_turn_n: '¡Te toca, {n}!', roll_the_dice: 'Lanza los dados',
      press_roll: 'Toca el tapete o pulsa «Lanzar dados»', no_combos: 'Sin combinaciones posibles', roll_again: 'Vuelve a lanzar', cant_make: '{n} no puede hacer {s}',
      sum_exact: 'La suma debe ser exactamente {s}', first_roll: 'Primero lanza los dados', already_down: 'Ese número ya está abatido',
      overshoot: 'Te pasarías: solo faltan {s}', wait_turn: 'Espera a tu turno', game_finished: 'La partida ha terminado', tile: 'Ficha {n}',
      points: '{s} puntos', point1: '1 punto', tap_continue: 'Toca para continuar', haha: '¡Ja, ja!', ja: 'JA', jaja: '¡JA, JA!',
      v0: 'Victoria perfecta.', v5: '¡Excelente partida!', v10: 'Muy buena partida.', v20: 'Buena partida.', vbad: 'La caja se te ha resistido. ¡Otra!',
      menu: 'Menú', play_again: 'Jugar otra vez', all_nine: 'Has abatido los nueve números.', tiles_up: 'Fichas levantadas',
      final_score: 'Puntuación final', new_record: '¡Nuevo récord personal!', game_over: 'Fin de partida',
      rolled_no_combo: 'Ha salido un <b>{s}</b> y no hay combinación posible.', remaining_numbers: 'Números que quedan levantados:',
      remaining_sum: 'Suma restante', x_shut_box: '{n} ha cerrado la caja', x_left: '{n} se ha desconectado', tie: '¡Empate!',
      you_won: '¡Has ganado!', x_wins: '¡Gana {n}!', wait_rematch: 'Esperando a que el anfitrión decida la revancha…', leave: 'Salir',
      rematch: 'Revancha', x_perfect: '{n} ha cerrado la caja: victoria perfecta.', lowest_wins: 'Gana la puntuación más baja.',
      disconnected: 'Desconectado', leave_q: '¿Salir de la partida?', leave_net: 'Saldrás de la partida en red.',
      leave_net_host: 'Saldrás de la partida en red y se cerrará para todos.', keep_playing: 'Seguir jugando', restart_q: '¿Reiniciar partida?',
      restart_lost: 'Se perderá la partida en curso.', restart: 'Reiniciar', photo_of: 'Foto de {n}', player: 'jugador', take_photo: 'Hacer foto',
      gallery: 'Elegir de la galería', remove_photo: 'Quitar foto', close: 'Cerrar', your_profile: 'Tu perfil',
      tap_face: 'Toca la cara para hacerte una foto.', your_name: 'Tu nombre', save: 'Guardar', player_n: 'Jugador {n}', remove: 'Quitar',
      no_name: 'Sin nombre', need_name: 'Primero pon tu nombre (y si quieres, tu foto)', your_game: 'Tu partida', waiting_room: 'Sala de espera',
      ip_join: 'IP para unirse:', no_wifi: '¿sin WiFi?', host: 'Anfitrión', you: 'Tú', waiting_player: 'Esperando jugador…',
      wait_one: 'Esperando a que se una al menos otro jugador…', press_start: 'Pulsa «Empezar» cuando estéis todos (máximo 4).',
      wait_host: 'Esperando a que {n} empiece la partida…', the_host: 'el anfitrión', searching: 'Buscando partidas en tu WiFi…',
      game_of: 'Partida de <b>{n}</b>', join: 'Unirse', ip_example: 'Escribe una IP como 192.168.1.20', connecting: 'Conectando…',
      connecting_to: 'Conectando con {n}…', connected_wait: 'Conectado. Esperando…', ok: 'Aceptar', apply_next: 'Se aplicará en la próxima partida',
      stats_cleared: 'Estadísticas borradas', clear_stats: 'Borrar estadísticas', press_again: 'Pulsa otra vez para confirmar',
      only_android: 'La partida en red solo funciona en la app de Android.', create_fail: 'No se pudo crear la partida.',
      discover_fail: 'No se pueden buscar partidas automáticamente. Escribe la IP del anfitrión.',
      join_fail: 'No se pudo conectar con {n}. Comprobad que estáis en la misma WiFi.',
      r_version: 'Versión del juego diferente. Actualizad todos la app.', r_started: 'La partida ya ha empezado.',
      r_full: 'La partida está completa (máximo 4 jugadores).', host_closed: 'El anfitrión ha cerrado la partida.',
      conn_lost: 'Se ha perdido la conexión con el anfitrión.', player_default: 'Jugador', host_default: 'Anfitrión',
      players_title: 'Jugadores', setup_note: 'De 2 a 4 jugadores en este móvil, sin conexión. Cada uno pone su nombre y se hace una foto. El turno va pasando tirada a tirada.',
      add_player: '+ Añadir jugador', start: 'EMPEZAR', net_title: 'Jugar en red', change_profile: 'Cambiar nombre o foto',
      net_note: 'Hasta 4 móviles conectados a la misma WiFi (o al punto de acceso de uno de ellos). Uno crea la partida y los demás se unen.',
      create_game: 'Crear partida', join_game: 'Unirse a una partida', found_title: 'Partidas encontradas', or_ip: 'O escribe la IP del anfitrión',
      connect: 'Conectar', ip_note: 'La IP aparece en la pantalla del móvil que ha creado la partida.', start_game: 'Empezar partida',
      st_played: 'Partidas jugadas', st_perfect: 'Victorias perfectas', st_avg: 'Puntuación media', st_best: 'Récord personal',
      st_note: 'Arriba, las partidas individuales terminadas. Cuanto menor sea la puntuación, mejor: 0 es una victoria perfecta.',
      options: 'Opciones', opt_mock: 'Burlas: el jugador que se queda sin jugada aparece disfrazado y bailando con su cara.',
      opt_onedie: 'Regla clásica opcional: con el 7, el 8 y el 9 abatidos se lanza un solo dado.',
      pe_title: 'Encuadra la cara', pe_note: 'Pon los ojos en la línea azul y la boca justo en la línea roja: por ahí se corta la cara y se abre la boca al hablar. Arrastra la foto y usa la barra para acercar.',
      use_photo: 'Usar foto', language: 'Idioma', g_eyes: 'ojos', g_cut: 'aquí se abre la boca',
      rules_html:
        '<h3>Objetivo</h3><p>Abatir las nueve fichas, del 1 al 9. Si lo consigues, has cerrado la caja: <b>¡Shut the Box!</b></p>' +
        '<h3>Cómo se juega</h3><ol><li>Pulsa <b>Lanzar dados</b> o toca el tapete. Se suman los dos dados.</li>' +
        '<li>Toca una o varias fichas levantadas que sumen <b>exactamente</b> lo mismo. Con un 8, por ejemplo: 8, 7+1, 6+2, 5+3, 5+2+1 o 4+3+1.</li>' +
        '<li>Puedes cambiar la selección (tocando otra vez una ficha o con <b>Cancelar</b>) antes de pulsar <b>Confirmar</b>.</li>' +
        '<li>Las fichas confirmadas se abaten y ya no se pueden usar.</li><li>Vuelve a lanzar y repite.</li></ol>' +
        '<p>El juego no avisa de qué fichas sirven: tienes que pensarlo tú. Solo impide pasarse de la suma y confirmar una jugada que no sea exacta.</p>' +
        '<h3>Final de la partida</h3><p>La partida acaba cuando sale una tirada que no puedes formar con las fichas que quedan. Tu puntuación es la suma de las fichas levantadas: <b>cuanto menor, mejor</b>. Cero es la victoria perfecta.</p>' +
        '<h3>Varios jugadores</h3><p>De 2 a 4 jugadores, en el mismo móvil o en varios móviles conectados a la misma WiFi (cada móvil con su idioma). Cada uno tiene su caja y el turno pasa al siguiente después de cada jugada. Al que le toca le suena una campana y le vibra el móvil.</p>' +
        '<p>Quien saca una tirada imposible se queda con su puntuación (y aparece disfrazado bailando mientras los demás se ríen). Si alguien cierra la caja, gana al momento. Si no, gana la puntuación más baja.</p>' +
        '<h3>Caja compartida</h3><p>Una sola caja para todos: cada uno juega con lo que deja el anterior. Quien no puede jugar suma a su total lo que queda levantado y empieza otra ronda. Si alguien cierra la caja, los demás suman 10. Cuando alguien llega a 45 puntos, gana quien menos haya acumulado.</p>'
    },

    en: {
      lang_name: 'English', opt_vibrate: 'Phone vibration (turn alert).', vib_on: 'Vibration on', vib_off: 'Vibration off', snd_on: 'Sound on', snd_off: 'Sound off', author: 'A game by Alex Gabarró',
      mode_boxes: 'Own box each', mode_shared: 'Shared box', mode_boxes_desc: 'Each player has their own box. Lowest score wins.', mode_shared_desc: 'One box for everyone: you play with what the other player leaves. Whoever can’t play adds the open tiles to their total; if someone shuts the box, the others add 10. When someone reaches 45, the lowest total wins.', round: 'Round', round_n: 'Round {n}', adds: '+{a} · total {s}', others_add: 'Everyone else adds {s}', shared_end: 'Someone reached 45: the lowest total wins.',
      tally: 'Scoreboard', h2h_title: 'Head to head', h2h_empty: 'No games against other players yet.', h2h_note: 'Multiplayer games played on this phone.', ties1: '1 tie', ties: '{s} ties', shuts: 'boxes shut', wins_short: 'wins',
      profile_cta: 'Add your name and photo', subtitle: 'Close the box', continue: 'Continue game', new_game: 'New game',
      local_multi: 'Several players · this phone', net_multi: 'Network game · several phones', stats: 'Statistics', rules: 'Rules',
      sound_on: 'Sound: on', sound_off: 'Sound: off', record: 'Personal best:', version: 'Version 2.0',
      menu_btn: '‹ Menu', back: '‹ Back', restart_btn: '↻ Restart', score: 'Score', left: 'Left', best: 'Best', dice: 'Dice',
      roll: 'ROLL DICE', cancel: 'Cancel', confirm: 'Confirm', solo_label: 'Single player', ended_label: 'Game over',
      your_turn: 'Your turn!', turn_of: '{n}’s turn', net_game: 'Network game', your_points: 'Your score', in_play: 'Playing',
      rolling: 'Rolling…', x_rolls: '{n} is rolling…', x_will_roll: '{n} is about to roll…', x_roll_now: '<b>{n}</b>, roll the dice.',
      start_roll: 'Roll the dice to start.', well_played: 'Well played. <b>Roll again.</b>', x_choosing: '{n} is choosing tiles…',
      needs_sum: 'Needs to make <b>{s}</b>.', choose_sum: 'Pick tiles that add up to <b>{s}</b>.', selected: 'Selected:',
      missing: '<b>{s}</b> to go.', press_confirm: 'Press <b>Confirm</b>.', no_combo: 'There is no possible combination for <b>{s}</b>.',
      box_shut: 'Box shut!', pass_phone: 'Hand them the phone', your_turn_n: 'Your turn, {n}!', roll_the_dice: 'Roll the dice',
      press_roll: 'Tap the felt or press “Roll dice”', no_combos: 'No possible combinations', roll_again: 'Roll again', cant_make: '{n} can’t make {s}',
      sum_exact: 'The total must be exactly {s}', first_roll: 'Roll the dice first', already_down: 'That number is already shut',
      overshoot: 'Too much: only {s} to go', wait_turn: 'Wait for your turn', game_finished: 'The game is over', tile: 'Tile {n}',
      points: '{s} points', point1: '1 point', tap_continue: 'Tap to continue', haha: 'Ha ha!', ja: 'HA', jaja: 'HA HA!',
      v0: 'Perfect victory.', v5: 'Excellent game!', v10: 'Very good game.', v20: 'Good game.', vbad: 'The box got the better of you. Again!',
      menu: 'Menu', play_again: 'Play again', all_nine: 'You shut all nine numbers.', tiles_up: 'Tiles up',
      final_score: 'Final score', new_record: 'New personal best!', game_over: 'Game over',
      rolled_no_combo: 'You rolled <b>{s}</b> and there is no possible combination.', remaining_numbers: 'Numbers still up:',
      remaining_sum: 'Remaining total', x_shut_box: '{n} shut the box', x_left: '{n} has disconnected', tie: 'It’s a tie!',
      you_won: 'You win!', x_wins: '{n} wins!', wait_rematch: 'Waiting for the host to decide on a rematch…', leave: 'Leave',
      rematch: 'Rematch', x_perfect: '{n} shut the box: perfect victory.', lowest_wins: 'Lowest score wins.',
      disconnected: 'Disconnected', leave_q: 'Leave the game?', leave_net: 'You will leave the network game.',
      leave_net_host: 'You will leave the network game and it will end for everyone.', keep_playing: 'Keep playing', restart_q: 'Restart the game?',
      restart_lost: 'The current game will be lost.', restart: 'Restart', photo_of: 'Photo of {n}', player: 'player', take_photo: 'Take photo',
      gallery: 'Choose from gallery', remove_photo: 'Remove photo', close: 'Close', your_profile: 'Your profile',
      tap_face: 'Tap the face to take a photo.', your_name: 'Your name', save: 'Save', player_n: 'Player {n}', remove: 'Remove',
      no_name: 'No name', need_name: 'First add your name (and a photo if you like)', your_game: 'Your game', waiting_room: 'Waiting room',
      ip_join: 'IP to join:', no_wifi: 'no Wi-Fi?', host: 'Host', you: 'You', waiting_player: 'Waiting for player…',
      wait_one: 'Waiting for at least one more player to join…', press_start: 'Press “Start” when everyone is here (max 4).',
      wait_host: 'Waiting for {n} to start the game…', the_host: 'the host', searching: 'Looking for games on your Wi-Fi…',
      game_of: '<b>{n}</b>’s game', join: 'Join', ip_example: 'Type an IP like 192.168.1.20', connecting: 'Connecting…',
      connecting_to: 'Connecting to {n}…', connected_wait: 'Connected. Waiting…', ok: 'OK', apply_next: 'It will apply from the next game',
      stats_cleared: 'Statistics cleared', clear_stats: 'Clear statistics', press_again: 'Press again to confirm',
      only_android: 'Network games only work in the Android app.', create_fail: 'Could not create the game.',
      discover_fail: 'Can’t search for games automatically. Type the host’s IP.',
      join_fail: 'Could not connect to {n}. Check that you are on the same Wi-Fi.',
      r_version: 'Different game version. Everyone should update the app.', r_started: 'The game has already started.',
      r_full: 'The game is full (max 4 players).', host_closed: 'The host has closed the game.',
      conn_lost: 'Lost connection to the host.', player_default: 'Player', host_default: 'Host',
      players_title: 'Players', setup_note: '2 to 4 players on this phone, offline. Everyone adds their name and takes a photo. The turn passes after every roll.',
      add_player: '+ Add player', start: 'START', net_title: 'Network game', change_profile: 'Change name or photo',
      net_note: 'Up to 4 phones on the same Wi-Fi (or on one phone’s hotspot). One creates the game and the others join.',
      create_game: 'Create game', join_game: 'Join a game', found_title: 'Games found', or_ip: 'Or type the host’s IP',
      connect: 'Connect', ip_note: 'The IP is shown on the phone that created the game.', start_game: 'Start game',
      st_played: 'Games played', st_perfect: 'Perfect wins', st_avg: 'Average score', st_best: 'Personal best',
      st_note: 'Above: finished single-player games. The lower the score, the better: 0 is a perfect victory.',
      options: 'Options', opt_mock: 'Taunts: a player with no moves left appears in costume, dancing with their own face.',
      opt_onedie: 'Optional classic rule: once 7, 8 and 9 are shut, roll only one die.',
      pe_title: 'Frame the face', pe_note: 'Put the eyes on the blue line and the mouth right on the red line: that is where the face is cut and the mouth opens when talking. Drag the photo and use the slider to zoom.',
      use_photo: 'Use photo', language: 'Language', g_eyes: 'eyes', g_cut: 'the mouth opens here',
      rules_html:
        '<h3>Goal</h3><p>Shut all nine tiles, from 1 to 9. If you manage it, you have shut the box: <b>Shut the Box!</b></p>' +
        '<h3>How to play</h3><ol><li>Press <b>Roll dice</b> or tap the felt. The two dice are added up.</li>' +
        '<li>Tap one or more open tiles that add up to <b>exactly</b> the same. With an 8, for example: 8, 7+1, 6+2, 5+3, 5+2+1 or 4+3+1.</li>' +
        '<li>You can change your selection (tap a tile again or press <b>Cancel</b>) before pressing <b>Confirm</b>.</li>' +
        '<li>Confirmed tiles are shut and can’t be used again.</li><li>Roll again and repeat.</li></ol>' +
        '<p>The game doesn’t tell you which tiles work: you have to think it through. It only stops you from going over the total and from confirming a move that isn’t exact.</p>' +
        '<h3>End of the game</h3><p>The game ends when you roll a number you can’t make with the tiles left. Your score is the total of the open tiles: <b>the lower, the better</b>. Zero is a perfect victory.</p>' +
        '<h3>Several players</h3><p>2 to 4 players, on the same phone or on several phones on the same Wi-Fi (each phone in its own language). Everyone has their own box and the turn passes after every move. When it’s your turn a bell rings and your phone vibrates.</p>' +
        '<p>Whoever rolls an impossible number keeps their score (and appears in costume dancing while the others laugh). If someone shuts the box they win at once. Otherwise the lowest score wins.</p>' +
        '<h3>Shared box</h3><p>One box for everyone: each player plays with what the previous one leaves. Whoever can’t play adds the open tiles to their total and a new round starts. If someone shuts the box, the others add 10. When someone reaches 45 points, the lowest total wins.</p>'
    },

    da: {
      lang_name: 'Dansk', opt_vibrate: 'Vibration (besked om tur).', vib_on: 'Vibration til', vib_off: 'Vibration fra', snd_on: 'Lyd til', snd_off: 'Lyd fra', author: 'Et spil af Alex Gabarró',
      mode_boxes: 'Hver sin kasse', mode_shared: 'Fælles kasse', mode_boxes_desc: 'Hver spiller har sin egen kasse. Laveste score vinder.', mode_shared_desc: 'Én fælles kasse: du spiller med det, den anden efterlader. Den, der ikke kan spille, lægger de åbne brikker til sin sum; lukker nogen kassen, får de andre 10. Når nogen når 45, vinder den med færrest point.', round: 'Runde', round_n: 'Runde {n}', adds: '+{a} · i alt {s}', others_add: 'De andre får {s}', shared_end: 'Nogen har nået 45: den laveste sum vinder.',
      tally: 'Stilling', h2h_title: 'Indbyrdes', h2h_empty: 'Endnu ingen spil mod andre spillere.', h2h_note: 'Spil med flere spillere på denne telefon.', ties1: '1 uafgjort', ties: '{s} uafgjorte', shuts: 'lukkede kasser', wins_short: 'sejre',
      profile_cta: 'Tilføj dit navn og billede', subtitle: 'Luk kassen', continue: 'Fortsæt spillet', new_game: 'Nyt spil',
      local_multi: 'Flere spillere · denne telefon', net_multi: 'Netværksspil · flere telefoner', stats: 'Statistik', rules: 'Regler',
      sound_on: 'Lyd: til', sound_off: 'Lyd: fra', record: 'Personlig rekord:', version: 'Version 2.0',
      menu_btn: '‹ Menu', back: '‹ Tilbage', restart_btn: '↻ Genstart', score: 'Point', left: 'Tilbage', best: 'Rekord', dice: 'Terninger',
      roll: 'SLÅ TERNINGER', cancel: 'Annuller', confirm: 'Bekræft', solo_label: 'Enkelt spiller', ended_label: 'Spillet er slut',
      your_turn: 'Din tur!', turn_of: 'Tur: {n}', net_game: 'Netværksspil', your_points: 'Dine point', in_play: 'I spil',
      rolling: 'Slår…', x_rolls: '{n} slår…', x_will_roll: '{n} skal til at slå…', x_roll_now: '<b>{n}</b>, slå med terningerne.',
      start_roll: 'Slå med terningerne for at begynde.', well_played: 'Godt spillet. <b>Slå igen.</b>', x_choosing: '{n} vælger brikker…',
      needs_sum: 'Skal ramme <b>{s}</b>.', choose_sum: 'Vælg brikker, der tilsammen giver <b>{s}</b>.', selected: 'Valgt:',
      missing: 'Mangler <b>{s}</b>.', press_confirm: 'Tryk på <b>Bekræft</b>.', no_combo: 'Der er ingen mulig kombination for <b>{s}</b>.',
      box_shut: 'Kassen er lukket!', pass_phone: 'Giv telefonen videre', your_turn_n: 'Din tur, {n}!', roll_the_dice: 'Slå med terningerne',
      press_roll: 'Tryk på filten eller på »Slå terninger«', no_combos: 'Ingen mulige kombinationer', roll_again: 'Slå igen', cant_make: '{n} kan ikke lave {s}',
      sum_exact: 'Summen skal være præcis {s}', first_roll: 'Slå med terningerne først', already_down: 'Det tal er allerede lukket',
      overshoot: 'For meget: der mangler kun {s}', wait_turn: 'Vent på din tur', game_finished: 'Spillet er slut', tile: 'Brik {n}',
      points: '{s} point', point1: '1 point', tap_continue: 'Tryk for at fortsætte', haha: 'Ha ha!', ja: 'HA', jaja: 'HA HA!',
      v0: 'Perfekt sejr.', v5: 'Fremragende spil!', v10: 'Rigtig godt spil.', v20: 'Godt spil.', vbad: 'Kassen var for svær. En gang til!',
      menu: 'Menu', play_again: 'Spil igen', all_nine: 'Du har lukket alle ni tal.', tiles_up: 'Brikker oppe',
      final_score: 'Slutscore', new_record: 'Ny personlig rekord!', game_over: 'Spillet er slut',
      rolled_no_combo: 'Du slog <b>{s}</b>, og der er ingen mulig kombination.', remaining_numbers: 'Tal, der stadig er oppe:',
      remaining_sum: 'Resterende sum', x_shut_box: '{n} har lukket kassen', x_left: '{n} har forladt spillet', tie: 'Uafgjort!',
      you_won: 'Du har vundet!', x_wins: '{n} vinder!', wait_rematch: 'Venter på, at værten beslutter en revanche…', leave: 'Forlad',
      rematch: 'Revanche', x_perfect: '{n} har lukket kassen: perfekt sejr.', lowest_wins: 'Laveste score vinder.',
      disconnected: 'Afbrudt', leave_q: 'Forlad spillet?', leave_net: 'Du forlader netværksspillet.',
      leave_net_host: 'Du forlader netværksspillet, og det slutter for alle.', keep_playing: 'Spil videre', restart_q: 'Genstart spillet?',
      restart_lost: 'Det igangværende spil går tabt.', restart: 'Genstart', photo_of: 'Billede af {n}', player: 'spiller', take_photo: 'Tag billede',
      gallery: 'Vælg fra galleri', remove_photo: 'Fjern billede', close: 'Luk', your_profile: 'Din profil',
      tap_face: 'Tryk på ansigtet for at tage et billede.', your_name: 'Dit navn', save: 'Gem', player_n: 'Spiller {n}', remove: 'Fjern',
      no_name: 'Intet navn', need_name: 'Tilføj først dit navn (og gerne et billede)', your_game: 'Dit spil', waiting_room: 'Venterum',
      ip_join: 'IP for at deltage:', no_wifi: 'intet wifi?', host: 'Vært', you: 'Dig', waiting_player: 'Venter på spiller…',
      wait_one: 'Venter på, at mindst én spiller mere deltager…', press_start: 'Tryk på »Start«, når alle er her (højst 4).',
      wait_host: 'Venter på, at {n} starter spillet…', the_host: 'værten', searching: 'Leder efter spil på dit wifi…',
      game_of: 'Spil: <b>{n}</b>', join: 'Deltag', ip_example: 'Skriv en IP som 192.168.1.20', connecting: 'Forbinder…',
      connecting_to: 'Forbinder til {n}…', connected_wait: 'Forbundet. Venter…', ok: 'OK', apply_next: 'Gælder fra næste spil',
      stats_cleared: 'Statistik slettet', clear_stats: 'Slet statistik', press_again: 'Tryk igen for at bekræfte',
      only_android: 'Netværksspil virker kun i Android-appen.', create_fail: 'Kunne ikke oprette spillet.',
      discover_fail: 'Kan ikke søge efter spil automatisk. Skriv værtens IP.',
      join_fail: 'Kunne ikke forbinde til {n}. Tjek, at I er på samme wifi.',
      r_version: 'Forskellig spilversion. Alle skal opdatere appen.', r_started: 'Spillet er allerede startet.',
      r_full: 'Spillet er fuldt (højst 4 spillere).', host_closed: 'Værten har lukket spillet.',
      conn_lost: 'Forbindelsen til værten blev afbrudt.', player_default: 'Spiller', host_default: 'Vært',
      players_title: 'Spillere', setup_note: '2 til 4 spillere på denne telefon, uden forbindelse. Alle skriver deres navn og tager et billede. Turen går videre efter hvert slag.',
      add_player: '+ Tilføj spiller', start: 'START', net_title: 'Netværksspil', change_profile: 'Skift navn eller billede',
      net_note: 'Op til 4 telefoner på samme wifi (eller på én telefons hotspot). Én opretter spillet, og de andre deltager.',
      create_game: 'Opret spil', join_game: 'Deltag i et spil', found_title: 'Fundne spil', or_ip: 'Eller skriv værtens IP',
      connect: 'Forbind', ip_note: 'IP’en vises på den telefon, der har oprettet spillet.', start_game: 'Start spillet',
      st_played: 'Spillede spil', st_perfect: 'Perfekte sejre', st_avg: 'Gennemsnitlig score', st_best: 'Personlig rekord',
      st_note: 'Øverst: færdige enkeltspil. Jo lavere score, jo bedre: 0 er en perfekt sejr.',
      options: 'Indstillinger', opt_mock: 'Drillerier: en spiller uden flere træk dukker op udklædt og dansende med sit eget ansigt.',
      opt_onedie: 'Valgfri klassisk regel: når 7, 8 og 9 er lukket, slås der kun med én terning.',
      pe_title: 'Placér ansigtet', pe_note: 'Placér øjnene på den blå linje og munden lige på den røde linje: her deles ansigtet, og munden åbner sig, når der tales. Træk billedet og brug skyderen til at zoome.',
      use_photo: 'Brug billede', language: 'Sprog', g_eyes: 'øjne', g_cut: 'her åbner munden sig',
      rules_html:
        '<h3>Mål</h3><p>Luk alle ni brikker, fra 1 til 9. Lykkes det, har du lukket kassen: <b>Shut the Box!</b></p>' +
        '<h3>Sådan spiller man</h3><ol><li>Tryk på <b>Slå terninger</b> eller på filten. De to terninger lægges sammen.</li>' +
        '<li>Tryk på en eller flere åbne brikker, der tilsammen giver <b>præcis</b> det samme. Med 8 for eksempel: 8, 7+1, 6+2, 5+3, 5+2+1 eller 4+3+1.</li>' +
        '<li>Du kan ændre dit valg (tryk på en brik igen eller på <b>Annuller</b>), før du trykker på <b>Bekræft</b>.</li>' +
        '<li>Bekræftede brikker lukkes og kan ikke bruges igen.</li><li>Slå igen og gentag.</li></ol>' +
        '<p>Spillet fortæller ikke, hvilke brikker der passer: du må selv tænke dig om. Det forhindrer kun, at du går over summen eller bekræfter et træk, der ikke er præcist.</p>' +
        '<h3>Slut på spillet</h3><p>Spillet slutter, når du slår et tal, som du ikke kan lave med de resterende brikker. Din score er summen af de åbne brikker: <b>jo lavere, jo bedre</b>. Nul er en perfekt sejr.</p>' +
        '<h3>Flere spillere</h3><p>2 til 4 spillere, på samme telefon eller på flere telefoner på samme wifi (hver telefon på sit eget sprog). Alle har deres egen kasse, og turen går videre efter hvert træk. Når det er din tur, ringer en klokke, og telefonen vibrerer.</p>' +
        '<p>Den, der slår et umuligt tal, beholder sin score (og dukker op udklædt og dansende, mens de andre griner). Lukker nogen kassen, vinder de med det samme. Ellers vinder den laveste score.</p>' +
        '<h3>Fælles kasse</h3><p>Én kasse til alle: hver spiller spiller med det, den forrige efterlader. Den, der ikke kan spille, lægger de åbne brikker til sin sum, og en ny runde begynder. Lukker nogen kassen, får de andre 10. Når nogen når 45 point, vinder den med den laveste sum.</p>'
    }
  };

  var lang = 'es';

  function t(key, p) {
    var s = (D[lang] && D[lang][key]) || D.es[key] || key;
    if (p) s = s.replace(/\{(\w+)\}/g, function (m, k) { return p[k] != null ? p[k] : m; });
    return s;
  }

  function apply(rootEl) {
    rootEl = rootEl || document;
    var els = rootEl.querySelectorAll('[data-i18n]');
    for (var i = 0; i < els.length; i++) els[i].textContent = t(els[i].getAttribute('data-i18n'));
    els = rootEl.querySelectorAll('[data-i18n-html]');
    for (i = 0; i < els.length; i++) els[i].innerHTML = t(els[i].getAttribute('data-i18n-html'));
    els = rootEl.querySelectorAll('[data-i18n-ph]');
    for (i = 0; i < els.length; i++) els[i].setAttribute('placeholder', t(els[i].getAttribute('data-i18n-ph')));
    document.documentElement.lang = lang;
  }

  function detect() {
    var n = (navigator.language || 'es').toLowerCase();
    if (n.indexOf('da') === 0) return 'da';
    if (n.indexOf('en') === 0) return 'en';
    return 'es';
  }

  root.STBi18n = {
    LANGS: ['es', 'en', 'da'],
    t: t,
    apply: apply,
    detect: detect,
    get: function () { return lang; },
    set: function (l) { if (D[l]) lang = l; apply(); },
    name: function (l) { return D[l].lang_name; }
  };
  root.t = t;
})(window);
