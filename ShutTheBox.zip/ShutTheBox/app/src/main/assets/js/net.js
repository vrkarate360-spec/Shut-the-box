/*
 * Shut the Box — partidas de varios jugadores.
 *  - «local»: varios jugadores en el mismo móvil, sin conexión.
 *  - «host» / «client»: varios móviles en la misma WiFi (puente nativo AndroidNet).
 * En todos los casos manda un Controller con la lógica de NetMatch; la interfaz solo
 * recibe «fotos» del estado (snapshots) y envía acciones.
 */
(function (root) {
  'use strict';

  var NG = root.STBNetGame;
  var PROTO = 4;
  var cb = {};          // callbacks de la interfaz: lobby, state, found, error, left, status
  var S = { role: null, myId: null, lobby: [], ctrl: null, found: {}, prune: null, oneDie: false, profile: null, ip: '', tally: {}, mode: 'boxes', rounds: 5 };

  function bridge() { return root.AndroidNet || null; }
  function call(name) { if (cb[name]) cb[name].apply(null, Array.prototype.slice.call(arguments, 1)); }

  // Pausas para que todos vean las animaciones antes de pasar el turno
  function delayFor(ev) {
    switch (ev.type) {
      case 'stuck': return 8200;     // dados + «sin jugadas» + burla con voz
      case 'confirmed': return 1300;
      case 'won': return 4200;
      case 'round': return 0;
      default: return 0;
    }
  }

  // ------------------------------------------------------------------ Controller
  function Controller(players, opts, broadcast) {
    this.match = opts.mode === 'shared' ? new NG.SharedMatch(players, opts) : new NG.NetMatch(players, opts);
    this.broadcast = broadcast;
    this.timer = null;
    this.stopped = false;
  }
  Controller.prototype.publish = function () {
    var snap = this.match.snapshot();
    if (snap.phase === 'ended' && !this.counted) {
      this.counted = true;
      var r = snap.ranking || [];
      var winners = r.filter(function (x) { return x.rank === 1 && !x.disconnected; });
      if (winners.length === 1) S.tally[winners[0].id] = (S.tally[winners[0].id] || 0) + 1;
    }
    snap.tally = JSON.parse(JSON.stringify(S.tally));
    if (this.broadcast) this.broadcast(snap);
    call('state', snap);
    this.schedule();
  };
  Controller.prototype.schedule = function () {
    var self = this;
    if (!this.match.pending || this.timer) return;
    this.timer = setTimeout(function () {
      self.timer = null;
      if (self.stopped) return;
      if (self.match.advance()) self.publish();
    }, delayFor(this.match.event));
  };
  Controller.prototype.act = function (id, a, n) { if (!this.stopped && this.match.handle(id, a, n)) this.publish(); };
  Controller.prototype.drop = function (id) { if (!this.stopped && this.match.disconnect(id)) this.publish(); };
  Controller.prototype.stop = function () { this.stopped = true; clearTimeout(this.timer); };

  // ------------------------------------------------------------------ Local (mismo móvil)
  function startLocal(players, oneDie, keepTally, mode, rounds) {
    var tally = keepTally ? S.tally : {};
    stop();
    S.tally = tally;
    S.mode = mode || 'boxes';
    if (rounds != null) S.rounds = rounds;
    S.role = 'local';
    S.oneDie = !!oneDie;
    S.lobby = players;
    S.ctrl = new Controller(players.map(function (p) { return { id: p.id, name: p.name }; }), { oneDieRule: S.oneDie, mode: S.mode, maxRounds: S.rounds }, null);
    S.ctrl.publish();
  }

  // ------------------------------------------------------------------ Anfitrión
  function sendAll(obj) { var b = bridge(); if (b) b.hostSendAll(JSON.stringify(obj)); }
  function sendTo(id, obj) { var b = bridge(); if (b) b.hostSendTo(id, JSON.stringify(obj)); }

  function lobbyMsg() {
    return { t: 'lobby', players: S.lobby.map(function (p) { return { id: p.id, name: p.name, photo: p.photo || '' }; }), max: NG.MAX_PLAYERS, oneDie: S.oneDie, mode: S.mode, rounds: S.rounds };
  }
  function broadcastLobby() { sendAll(lobbyMsg()); call('lobby', S.lobby, S.role, S.mode); }

  function uniqueName(name) {
    name = (name || 'Player').slice(0, 14);
    var base = name, k = 2;
    while (S.lobby.some(function (p) { return p.name === name; })) name = base + ' ' + (k++);
    return name;
  }

  function host(profile, oneDie, mode, rounds) {
    stop();
    var b = bridge();
    if (!b) { call('error', 'only_android'); return false; }
    S.role = 'host';
    S.myId = 'H';
    S.tally = {};
    S.mode = mode || 'boxes';
    if (rounds != null) S.rounds = rounds;
    S.oneDie = !!oneDie;
    S.profile = profile;
    S.lobby = [{ id: 'H', name: profile.name || 'Host', photo: profile.photo || '' }];
    if (!b.hostStart(S.lobby[0].name)) { S.role = null; return false; }
    b.keepAwake(true);
    S.ip = b.localIp();
    call('lobby', S.lobby, S.role, S.mode);
    return true;
  }

  function hostStartMatch() {
    if (S.role !== 'host' || S.lobby.length < 2) return;
    if (S.ctrl) S.ctrl.stop();
    bridge().hostBeacon(false);
    S.ctrl = new Controller(S.lobby.map(function (p) { return { id: p.id, name: p.name }; }), { oneDieRule: S.oneDie, mode: S.mode, maxRounds: S.rounds },
      function (snap) { sendAll({ t: 'state', s: snap }); });
    S.ctrl.publish();
  }

  function onHostMessage(id, line) {
    var m;
    try { m = JSON.parse(line); } catch (e) { return; }
    if (m.t === 'hello') {
      var reason = null;
      if (m.proto !== PROTO) reason = 'r_version';
      else if (S.ctrl && S.ctrl.match.phase === 'playing') reason = 'r_started';
      else if (S.lobby.length >= NG.MAX_PLAYERS) reason = 'r_full';
      if (reason) {
        sendTo(id, { t: 'reject', reason: reason });
        setTimeout(function () { bridge().hostKick(id); }, 500);
        return;
      }
      S.lobby.push({ id: id, name: uniqueName(m.name), photo: typeof m.photo === 'string' && m.photo.length < 120000 ? m.photo : '' });
      sendTo(id, { t: 'welcome', id: id });
      broadcastLobby();
      if (S.ctrl && S.ctrl.match.phase === 'ended') { /* se unirá en la revancha */ }
    } else if (m.t === 'act' && S.ctrl) {
      S.ctrl.act(id, m.a, m.n);
    }
  }

  function onHostDisconnect(id) {
    var p = S.lobby.filter(function (x) { return x.id === id; })[0];
    S.lobby = S.lobby.filter(function (x) { return x.id !== id; });
    if (p && S.ctrl && S.ctrl.match.phase === 'playing') S.ctrl.drop(id);
    broadcastLobby();
  }

  // ------------------------------------------------------------------ Cliente
  function discover() {
    var b = bridge();
    if (!b) return;
    S.found = {};
    b.discoverStart();
    clearInterval(S.prune);
    S.prune = setInterval(function () {
      var now = Date.now(), changed = false;
      Object.keys(S.found).forEach(function (ip) { if (now - S.found[ip].ts > 4500) { delete S.found[ip]; changed = true; } });
      if (changed) call('found', foundList());
    }, 1500);
  }
  function stopDiscover() {
    clearInterval(S.prune);
    var b = bridge();
    if (b) b.discoverStop();
  }
  function foundList() {
    return Object.keys(S.found).map(function (ip) { return { ip: ip, name: S.found[ip].name }; });
  }

  function join(ip, profile) {
    var b = bridge();
    if (!b) { call('error', 'only_android'); return; }
    stopDiscover();
    if (S.ctrl) S.ctrl.stop();
    S.ctrl = null;
    S.role = 'client';
    S.myId = null;
    S.profile = profile;
    S.lobby = [];
    b.keepAwake(true);
    call('status', 'connecting_to', { n: ip });
    b.join(ip);
  }

  function onClientMessage(line) {
    var m;
    try { m = JSON.parse(line); } catch (e) { return; }
    switch (m.t) {
      case 'welcome': S.myId = m.id; break;
      case 'lobby':
        S.lobby = m.players;
        S.oneDie = !!m.oneDie;
        S.mode = m.mode || 'boxes';
        S.rounds = m.rounds || 0;
        call('lobby', S.lobby, S.role, S.mode);
        break;
      case 'state': call('state', m.s); break;
      case 'reject': stop(); call('left', m.reason); break;
      case 'bye': stop(); call('left', 'host_closed'); break;
    }
  }

  // ------------------------------------------------------------------ Eventos del puente nativo
  function _emit(type, a, b) {
    switch (type) {
      case 'cconnect': break;                        // esperamos su «hello»
      case 'cmsg': if (S.role === 'host') onHostMessage(a, b); break;
      case 'cdisconnect': if (S.role === 'host') onHostDisconnect(a); break;
      case 'found':
        if (!S.found[a]) { S.found[a] = { name: b, ts: Date.now() }; call('found', foundList()); }
        else S.found[a].ts = Date.now();
        break;
      case 'joined':
        bridge().send(JSON.stringify({ t: 'hello', proto: PROTO, name: S.profile.name || 'Player', photo: S.profile.photo || '' }));
        call('status', 'connected_wait');
        break;
      case 'joinfail': stop(); call('error', 'join_fail', { n: a }); break;
      case 'msg': if (S.role === 'client') onClientMessage(a); break;
      case 'lost': if (S.role === 'client') { stop(); call('left', 'conn_lost'); } break;
      case 'error': call('error', a); break;
    }
  }

  // ------------------------------------------------------------------ API común
  function act(a, n) {
    if (S.role === 'local') { if (S.ctrl) S.ctrl.act(S.ctrl.match.cur().id, a, n); }
    else if (S.role === 'host') { if (S.ctrl) S.ctrl.act('H', a, n); }
    else if (S.role === 'client') { var b = bridge(); if (b) b.send(JSON.stringify({ t: 'act', a: a, n: n })); }
  }

  function rematch() {
    if (S.role === 'local') startLocal(S.lobby, S.oneDie, true, S.mode, S.rounds);
    else if (S.role === 'host') hostStartMatch();
  }

  function stop() {
    var b = bridge();
    if (S.ctrl) S.ctrl.stop();
    if (b) {
      if (S.role === 'host') { try { b.hostSendAll(JSON.stringify({ t: 'bye' })); } catch (e) { } setTimeout(function () { b.hostStop(); }, 300); }
      if (S.role === 'client') b.leave();
      stopDiscover();
      b.keepAwake(false);
    }
    S.role = null; S.myId = null; S.ctrl = null; S.lobby = [];
  }

  root.STBNet = {
    MAX: NG.MAX_PLAYERS,
    available: function () { return !!bridge(); },
    on: function (name, fn) { cb[name] = fn; },
    role: function () { return S.role; },
    myId: function () { return S.myId; },
    lobby: function () { return S.lobby; },
    ip: function () { return S.ip; },
    startLocal: startLocal,
    host: host,
    hostStartMatch: hostStartMatch,
    discover: discover,
    stopDiscover: stopDiscover,
    join: join,
    act: act,
    rematch: rematch,
    mode: function () { return S.mode; },
    rounds: function () { return S.rounds; },
    setRounds: function (r) { S.rounds = r; if (S.role === 'host' && !(S.ctrl && S.ctrl.match.phase === 'playing')) broadcastLobby(); },
    setMode: function (m) { S.mode = m; if (S.role === 'host' && !(S.ctrl && S.ctrl.match.phase === 'playing')) broadcastLobby(); },
    stop: stop,
    _emit: _emit
  };
})(window);
