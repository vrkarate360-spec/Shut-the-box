package com.alex.shutthebox;

import android.app.Activity;
import android.content.Context;
import android.net.wifi.WifiManager;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.InterfaceAddress;
import java.net.NetworkInterface;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Red local entre móviles (misma WiFi o punto de acceso de uno de ellos).
 *  - El anfitrión abre un servidor TCP y anuncia la partida por UDP broadcast.
 *  - Los demás descubren la partida y se conectan por TCP.
 *  - Los mensajes son líneas de texto JSON; toda la lógica del juego está en JavaScript.
 * Expuesto a JavaScript como «AndroidNet».
 */
public class NetBridge {

    static final int TCP_PORT = 47820;
    static final int UDP_PORT = 47821;
    static final String BEACON = "STB1";

    private final Activity activity;
    private final WebView web;
    private final ExecutorService sendExec = Executors.newSingleThreadExecutor();

    // Anfitrión
    private volatile ServerSocket server;
    private final Map<String, Conn> clients = new ConcurrentHashMap<>();
    private int nextId = 1;
    private volatile boolean beaconOn = false;
    private volatile String hostName = "";

    // Cliente
    private volatile Conn hostConn;
    private volatile boolean leaving = false;

    // Descubrimiento
    private volatile DatagramSocket discoverSock;
    private volatile boolean discoverOn = false;
    private WifiManager.MulticastLock mlock;

    volatile boolean keepAwake = false;

    NetBridge(Activity activity, WebView web) {
        this.activity = activity;
        this.web = web;
    }

    private static class Conn {
        final Socket socket;
        final PrintWriter out;
        final String id;

        Conn(Socket s, String id) throws Exception {
            this.socket = s;
            this.id = id;
            this.out = new PrintWriter(new OutputStreamWriter(s.getOutputStream(), StandardCharsets.UTF_8), true);
        }

        synchronized void send(String line) {
            out.print(line);
            out.print('\n');
            out.flush();
        }

        void close() {
            try { socket.close(); } catch (Exception ignored) { }
        }
    }

    // ------------------------------------------------------------------ eventos hacia JS

    private void emit(String type, String a, String b) {
        final String js = "window.STBNet && STBNet._emit(" + JSONObject.quote(type) + ","
                + JSONObject.quote(a == null ? "" : a) + "," + JSONObject.quote(b == null ? "" : b) + ")";
        web.post(() -> web.evaluateJavascript(js, null));
    }

    // ------------------------------------------------------------------ utilidades

    @JavascriptInterface
    public String localIp() {
        String fallback = "";
        try {
            for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!ni.isUp() || ni.isLoopback()) continue;
                for (InetAddress a : Collections.list(ni.getInetAddresses())) {
                    if (a instanceof Inet4Address && !a.isLoopbackAddress()) {
                        String name = ni.getName();
                        String ip = a.getHostAddress();
                        if (name.startsWith("wlan") || name.startsWith("ap") || name.startsWith("swlan")) return ip;
                        if (fallback.isEmpty() && a.isSiteLocalAddress()) fallback = ip;
                    }
                }
            }
        } catch (Exception ignored) { }
        return fallback;
    }

    private List<InetAddress> broadcastAddresses() {
        List<InetAddress> list = new ArrayList<>();
        try {
            list.add(InetAddress.getByName("255.255.255.255"));
            for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!ni.isUp() || ni.isLoopback()) continue;
                for (InterfaceAddress ia : ni.getInterfaceAddresses()) {
                    if (ia.getBroadcast() != null) list.add(ia.getBroadcast());
                }
            }
        } catch (Exception ignored) { }
        return list;
    }

    @JavascriptInterface
    public void vibrate(String pattern) {
        try {
            String[] parts = pattern.split(",");
            long[] p = new long[parts.length];
            for (int i = 0; i < parts.length; i++) p[i] = Long.parseLong(parts[i].trim());
            Vibrator v = (Vibrator) activity.getSystemService(Context.VIBRATOR_SERVICE);
            if (v != null && v.hasVibrator()) v.vibrate(VibrationEffect.createWaveform(p, -1));
        } catch (Exception ignored) { }
    }

    /** Mantiene la pantalla encendida y el juego activo durante la partida en red. */
    @JavascriptInterface
    public void keepAwake(boolean on) {
        keepAwake = on;
        activity.runOnUiThread(() -> {
            if (on) activity.getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            else activity.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        });
    }

    // ------------------------------------------------------------------ anfitrión

    @JavascriptInterface
    public boolean hostStart(String name) {
        stopAll();
        hostName = name == null ? "" : name.replace("|", " ");
        try {
            ServerSocket ss = new ServerSocket();
            ss.setReuseAddress(true);
            ss.bind(new InetSocketAddress(TCP_PORT));
            server = ss;
        } catch (Exception e) {
            emit("error", "No se pudo crear la partida: " + e.getMessage(), "");
            return false;
        }

        Thread accept = new Thread(() -> {
            ServerSocket ss = server;
            while (ss != null && !ss.isClosed()) {
                try {
                    Socket s = ss.accept();
                    s.setTcpNoDelay(true);
                    s.setKeepAlive(true);
                    final String id;
                    synchronized (this) { id = "c" + (nextId++); }
                    final Conn c = new Conn(s, id);
                    clients.put(id, c);
                    emit("cconnect", id, s.getInetAddress().getHostAddress());
                    new Thread(() -> readLoopHost(c), "stb-client-" + id).start();
                } catch (Exception e) {
                    break;
                }
            }
        }, "stb-accept");
        accept.start();

        hostBeacon(true);
        return true;
    }

    private void readLoopHost(Conn c) {
        try {
            BufferedReader in = new BufferedReader(new InputStreamReader(c.socket.getInputStream(), StandardCharsets.UTF_8));
            String line;
            while ((line = in.readLine()) != null) emit("cmsg", c.id, line);
        } catch (Exception ignored) { }
        c.close();
        if (clients.remove(c.id) != null) emit("cdisconnect", c.id, "");
    }

    @JavascriptInterface
    public void hostBeacon(boolean on) {
        if (on == beaconOn) return;
        beaconOn = on;
        if (!on) return;
        new Thread(() -> {
            DatagramSocket ds = null;
            try {
                ds = new DatagramSocket();
                ds.setBroadcast(true);
                while (beaconOn && server != null) {
                    byte[] data = (BEACON + "|" + hostName + "|" + TCP_PORT).getBytes(StandardCharsets.UTF_8);
                    for (InetAddress addr : broadcastAddresses()) {
                        try { ds.send(new DatagramPacket(data, data.length, addr, UDP_PORT)); } catch (Exception ignored) { }
                    }
                    Thread.sleep(1000);
                }
            } catch (Exception ignored) {
            } finally {
                if (ds != null) ds.close();
            }
        }, "stb-beacon").start();
    }

    @JavascriptInterface
    public void hostSendAll(String line) {
        sendExec.execute(() -> {
            for (Conn c : clients.values()) {
                try { c.send(line); } catch (Exception ignored) { }
            }
        });
    }

    @JavascriptInterface
    public void hostSendTo(String id, String line) {
        sendExec.execute(() -> {
            Conn c = clients.get(id);
            if (c != null) try { c.send(line); } catch (Exception ignored) { }
        });
    }

    @JavascriptInterface
    public void hostKick(String id) {
        sendExec.execute(() -> {
            Conn c = clients.remove(id);
            if (c != null) c.close();
        });
    }

    @JavascriptInterface
    public void hostStop() {
        beaconOn = false;
        ServerSocket ss = server;
        server = null;
        if (ss != null) try { ss.close(); } catch (Exception ignored) { }
        for (Conn c : clients.values()) c.close();
        clients.clear();
    }

    // ------------------------------------------------------------------ descubrimiento

    @JavascriptInterface
    public void discoverStart() {
        if (discoverOn) return;
        discoverOn = true;
        try {
            WifiManager wm = (WifiManager) activity.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            if (wm != null) {
                mlock = wm.createMulticastLock("stb-discover");
                mlock.setReferenceCounted(false);
                mlock.acquire();
            }
        } catch (Exception ignored) { }

        new Thread(() -> {
            try {
                DatagramSocket ds = new DatagramSocket(null);
                ds.setReuseAddress(true);
                ds.setBroadcast(true);
                ds.bind(new InetSocketAddress(UDP_PORT));
                ds.setSoTimeout(1000);
                discoverSock = ds;
                byte[] buf = new byte[512];
                while (discoverOn) {
                    try {
                        DatagramPacket pk = new DatagramPacket(buf, buf.length);
                        ds.receive(pk);
                        String msg = new String(pk.getData(), 0, pk.getLength(), StandardCharsets.UTF_8);
                        String[] parts = msg.split("\\|");
                        if (parts.length >= 2 && BEACON.equals(parts[0])) {
                            emit("found", pk.getAddress().getHostAddress(), parts[1]);
                        }
                    } catch (java.net.SocketTimeoutException ignored) {
                    }
                }
            } catch (Exception e) {
                if (discoverOn) emit("error", "No se pueden buscar partidas automáticamente. Escribe la IP del anfitrión.", "");
            } finally {
                DatagramSocket ds = discoverSock;
                discoverSock = null;
                if (ds != null) ds.close();
            }
        }, "stb-discover").start();
    }

    @JavascriptInterface
    public void discoverStop() {
        discoverOn = false;
        DatagramSocket ds = discoverSock;
        if (ds != null) ds.close();
        try { if (mlock != null && mlock.isHeld()) mlock.release(); } catch (Exception ignored) { }
    }

    // ------------------------------------------------------------------ cliente

    @JavascriptInterface
    public void join(String ip) {
        leave();
        leaving = false;
        new Thread(() -> {
            Conn c;
            try {
                Socket s = new Socket();
                s.connect(new InetSocketAddress(ip.trim(), TCP_PORT), 5000);
                s.setTcpNoDelay(true);
                s.setKeepAlive(true);
                c = new Conn(s, "host");
                hostConn = c;
            } catch (Exception e) {
                emit("joinfail", ip, String.valueOf(e.getMessage()));
                return;
            }
            emit("joined", ip, "");
            try {
                BufferedReader in = new BufferedReader(new InputStreamReader(c.socket.getInputStream(), StandardCharsets.UTF_8));
                String line;
                while ((line = in.readLine()) != null) emit("msg", line, "");
            } catch (Exception ignored) { }
            c.close();
            if (hostConn == c) hostConn = null;
            if (!leaving) emit("lost", "", "");
        }, "stb-join").start();
    }

    @JavascriptInterface
    public void send(String line) {
        sendExec.execute(() -> {
            Conn c = hostConn;
            if (c != null) try { c.send(line); } catch (Exception ignored) { }
        });
    }

    @JavascriptInterface
    public void leave() {
        leaving = true;
        Conn c = hostConn;
        hostConn = null;
        if (c != null) c.close();
    }

    // ------------------------------------------------------------------

    void stopAll() {
        discoverStop();
        hostStop();
        leave();
    }

    void shutdown() {
        stopAll();
        sendExec.shutdownNow();
    }
}
