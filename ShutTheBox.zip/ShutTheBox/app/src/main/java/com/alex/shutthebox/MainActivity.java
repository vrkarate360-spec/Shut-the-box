package com.alex.shutthebox;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.Window;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;

/**
 * Contenedor nativo: muestra el juego (HTML/JS en assets/) a pantalla completa,
 * guarda los datos en local y gestiona el botón «atrás».
 */
public class MainActivity extends Activity {

    private WebView web;
    private NetBridge net;

    private static final int REQ_CAMERA = 41;
    private static final int REQ_GALLERY = 42;

    /** Fotos de los jugadores. Expuesto a JavaScript como «AndroidApp». */
    public class AppBridge {
        @JavascriptInterface
        public void takePhoto() {
            runOnUiThread(() -> {
                Intent i = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                // Pedir la cámara frontal (cada fabricante usa una clave distinta)
                i.putExtra("android.intent.extras.CAMERA_FACING", 1);
                i.putExtra("android.intent.extras.LENS_FACING_FRONT", 1);
                i.putExtra("android.intent.extra.USE_FRONT_CAMERA", true);
                try { startActivityForResult(i, REQ_CAMERA); } catch (Exception e) { photoResult(""); }
            });
        }

        @JavascriptInterface
        public void pickPhoto() {
            runOnUiThread(() -> {
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.setType("image/*");
                try { startActivityForResult(Intent.createChooser(i, null), REQ_GALLERY); } catch (Exception e) { photoResult(""); }
            });
        }
    }

    private void photoResult(String dataUrl) {
        final String js = "window.STBPhoto && STBPhoto._done(" + JSONObject.quote(dataUrl) + ")";
        web.post(() -> web.evaluateJavascript(js, null));
    }

    private static String toDataUrl(Bitmap bm) {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        bm.compress(Bitmap.CompressFormat.JPEG, 90, bos);
        return "data:image/jpeg;base64," + Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP);
    }

    private Bitmap loadScaled(Uri uri, int maxSide) throws Exception {
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inJustDecodeBounds = true;
        try (InputStream in = getContentResolver().openInputStream(uri)) { BitmapFactory.decodeStream(in, null, o); }
        int sample = 1;
        while (Math.max(o.outWidth, o.outHeight) / (sample * 2) >= maxSide) sample *= 2;
        BitmapFactory.Options o2 = new BitmapFactory.Options();
        o2.inSampleSize = sample;
        try (InputStream in = getContentResolver().openInputStream(uri)) { return BitmapFactory.decodeStream(in, null, o2); }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_CAMERA && requestCode != REQ_GALLERY) return;
        String result = "";
        try {
            if (resultCode == RESULT_OK && data != null) {
                Bitmap bm = null;
                if (requestCode == REQ_CAMERA && data.getExtras() != null) {
                    Object o = data.getExtras().get("data");
                    if (o instanceof Bitmap) bm = (Bitmap) o;
                }
                if (bm == null && data.getData() != null) bm = loadScaled(data.getData(), 900);
                if (bm != null) result = toDataUrl(bm);
            }
        } catch (Exception ignored) { }
        photoResult(result);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Window w = getWindow();
        w.setStatusBarColor(Color.parseColor("#1B110A"));
        w.setNavigationBarColor(Color.parseColor("#140C06"));

        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#1B110A"));
        web.setVerticalScrollBarEnabled(false);
        web.setHorizontalScrollBarEnabled(false);
        web.setOverScrollMode(WebView.OVER_SCROLL_NEVER);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);            // estadísticas y récord (localStorage)
        s.setAllowFileAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setTextZoom(100);                       // el diseño no se rompe con letra grande del sistema
        s.setSupportZoom(false);

        web.setWebViewClient(new WebViewClient());
        net = new NetBridge(this, web);
        web.addJavascriptInterface(net, "AndroidNet");   // partida en red local
        web.addJavascriptInterface(new AppBridge(), "AndroidApp");
        setContentView(web);

        if (savedInstanceState != null) {
            web.restoreState(savedInstanceState);
        } else {
            web.loadUrl("file:///android_asset/index.html");
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        web.saveState(outState);
    }

    @Override
    public void onBackPressed() {
        web.evaluateJavascript("(window.handleBack && window.handleBack()) ? 'true' : 'false'", value -> {
            if (value == null || !value.contains("true")) {
                finish();
            }
        });
    }

    @Override
    protected void onPause() {
        super.onPause();
        // Durante una partida en red el juego sigue activo para recibir el aviso de turno
        if (net == null || !net.keepAwake) {
            web.onPause();
            web.pauseTimers();   // ahorro de batería en segundo plano
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        web.onResume();
        web.resumeTimers();
    }

    @Override
    protected void onDestroy() {
        if (net != null) net.shutdown();
        if (web != null) web.destroy();
        super.onDestroy();
    }
}
