/*
 * Tests de la partida en red (2-4 jugadores).  node tests/netgame.test.js
 */
'use strict';
const path = require('path');
const L = require(path.join(__dirname, '../app/src/main/assets/js/logic.js'));
const N = require(path.join(__dirname, '../app/src/main/assets/js/netgame.js'));

let passed = 0;
function ok(c, m) { if (!c) { console.error('FALLO: ' + m); process.exit(1); } passed++; }
function mulberry32(a) { return function () { a |= 0; a = a + 0x6D2B79F5 | 0; let t = Math.imul(a ^ a >>> 15, 1 | a); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }
const P = n => Array.from({ length: n }, (_, i) => ({ id: 'p' + i, name: 'J' + (i + 1) }));

// Límites de jugadores
let threw = false; try { new N.NetMatch(P(1)); } catch (e) { threw = true; } ok(threw, '1 jugador no vale');
threw = false; try { new N.NetMatch(P(5)); } catch (e) { threw = true; } ok(threw, '5 jugadores no vale');

// Solo actúa a quien le toca, y se respeta la pausa
{
  const m = new N.NetMatch(P(3), { rng: () => 0.99 }); // siempre 6+6 = 12
  ok(m.handle('p1', 'roll') === false, 'p1 no puede lanzar en el turno de p0');
  ok(m.handle('p0', 'roll'), 'p0 lanza');
  ok(m.snapshot().diceSum === 12, 'suma 12');
  ok(m.handle('p0', 'toggle', 9) && m.handle('p0', 'toggle', 3), 'p0 elige 9+3');
  ok(m.handle('p1', 'confirm') === false, 'p1 no confirma por p0');
  ok(m.handle('p0', 'confirm'), 'p0 confirma');
  ok(m.pending && m.handle('p0', 'roll') === false, 'pausa: nadie actúa');
  m.advance();
  ok(m.cur().id === 'p1' && m.event.type === 'turn', 'turno de p1');
  ok(m.snapshot().players[0].open.join() === '1,2,4,5,6,7,8', 'caja de p0 guardada');
  ok(m.snapshot().players[1].open.length === 9, 'caja de p1 intacta');
}

// Simulación masiva: 2, 3 y 4 jugadores, con desconexiones aleatorias
{
  const rnd = mulberry32(99);
  for (let i = 0; i < 6000; i++) {
    const n = 2 + (i % 3);
    const m = new N.NetMatch(P(n), { rng: rnd, oneDieRule: i % 4 === 0 });
    let guard = 0, lastSeq = m.seq;
    while (m.phase === 'playing' && guard++ < 400) {
      if (rnd() < 0.01) { const v = 'p' + Math.floor(rnd() * n); m.disconnect(v); }
      if (m.phase !== 'playing') break;
      if (m.pending) { m.advance(); continue; }
      const p = m.cur();
      ok(!p.finished, 'el turno nunca es de un jugador terminado');
      // un intruso intenta jugar
      const other = m.players.find(q => q.id !== p.id);
      ok(m.handle(other.id, 'roll') === false, 'intruso rechazado');
      m.handle(p.id, 'roll');
      if (m.event.type === 'stuck') { ok(!L.hasMove(m.event.sum, p.game.open), 'stuck correcto'); continue; }
      const c = L.combos(p.game.diceSum, p.game.open);
      const pick = c[Math.floor(rnd() * c.length)];
      pick.forEach(x => ok(m.handle(p.id, 'toggle', x), 'selección válida aceptada'));
      ok(m.handle(p.id, 'confirm'), 'confirmación válida');
      ok(m.seq > lastSeq, 'seq crece'); lastSeq = m.seq;
      m.players.forEach(q => ok(L.sum(q.game.open) === q.game.score(), 'puntuación coherente'));
    }
    ok(m.phase === 'ended', 'la partida termina');
    const r = m.ranking();
    ok(r.length === n, 'ranking completo');
    for (let k = 1; k < r.length; k++) {
      ok((r[k - 1].won && !r[k].won) || (r[k - 1].won === r[k].won && r[k - 1].score <= r[k].score), 'ranking ordenado');
    }
    const winners = m.players.filter(q => q.won);
    ok(winners.length <= 1, 'como mucho un ganador perfecto');
    if (winners.length) ok(r[0].won && r[0].score === 0 && r[0].rank === 1, 'la victoria perfecta va primero');
  }
}

// Empates comparten puesto
{
  const m = new N.NetMatch(P(3));
  m.players[0].game.open = [1, 2];
  m.players[1].game.open = [3];
  m.players[2].game.open = [9];
  m.finish();
  const r = m.ranking();
  ok(r[0].rank === 1 && r[1].rank === 1 && r[2].rank === 3, 'empate a 3 comparte el primer puesto');
}

// Desconexión del jugador en turno pasa el turno
{
  const m = new N.NetMatch(P(3));
  m.disconnect('p0');
  ok(m.cur().id === 'p1' && m.event.type === 'turn', 'turno pasa a p1');
  m.disconnect('p1'); m.disconnect('p2');
  ok(m.phase === 'ended', 'sin jugadores, fin');
}

// Victoria perfecta termina la partida
{
  const m = new N.NetMatch(P(2));
  m.players[0].game.open = [4, 5];
  m.players[0].game.rng = (() => { const v = [0.5, 0.7]; let k = 0; return () => v[k++ % 2]; })(); // 4+5
  m.handle('p0', 'roll'); m.handle('p0', 'toggle', 4); m.handle('p0', 'toggle', 5); m.handle('p0', 'confirm');
  ok(m.event.type === 'won', 'evento de victoria');
  m.advance();
  ok(m.phase === 'ended' && m.ranking()[0].id === 'p0', 'gana p0');
}

console.log(`OK — ${passed} comprobaciones de la partida en red superadas.`);
