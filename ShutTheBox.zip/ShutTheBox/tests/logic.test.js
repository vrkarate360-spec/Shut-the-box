/*
 * Tests de validación de Shut the Box. Ejecutar con:  node tests/logic.test.js
 * Se ejecutan también automáticamente en GitHub antes de compilar el APK.
 */
'use strict';
const path = require('path');
const L = require(path.join(__dirname, '../app/src/main/assets/js/logic.js'));
const S = require(path.join(__dirname, '../app/src/main/assets/js/storage.js'));

let passed = 0;
function ok(cond, msg) {
  if (!cond) { console.error('FALLO: ' + msg); process.exit(1); }
  passed++;
}
function key(c) { return c.slice().sort((a, b) => a - b).join('+'); }
function subsets(arr) {
  const out = [];
  for (let m = 0; m < (1 << arr.length); m++) out.push(arr.filter((_, i) => m & (1 << i)));
  return out;
}
// Generador pseudoaleatorio reproducible
function mulberry32(a) {
  return function () {
    a |= 0; a = a + 0x6D2B79F5 | 0;
    let t = Math.imul(a ^ a >>> 15, 1 | a);
    t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
    return ((t ^ t >>> 14) >>> 0) / 4294967296;
  };
}

// 1. Combinaciones matemáticas: comparación exhaustiva con fuerza bruta
//    (512 estados posibles de la caja × sumas 1..12)
for (const open of subsets(L.ALL)) {
  const brute = subsets(open);
  for (let t = 1; t <= 12; t++) {
    const expected = new Set(brute.filter(s => s.length && L.sum(s) === t).map(key));
    const got = L.combos(t, open);
    const gotSet = new Set(got.map(key));
    ok(got.length === gotSet.size, `combinaciones duplicadas t=${t} open=${open}`);
    ok(expected.size === gotSet.size && [...expected].every(k => gotSet.has(k)),
      `combinaciones incorrectas t=${t} open=${open}`);
    for (const c of got) {
      ok(L.sum(c) === t, 'la suma no coincide');
      ok(new Set(c).size === c.length, 'número repetido en combinación');
      ok(c.every(n => open.includes(n)), 'combinación con número abatido');
    }
    ok(L.hasMove(t, open) === (expected.size > 0), `hasMove incorrecto t=${t} open=${open}`);
  }
}

// 2. Ejemplo del enunciado: con un 8 y todo levantado
const eight = new Set(L.combos(8, L.ALL).map(key));
['8', '1+7', '2+6', '3+5', '1+2+5', '1+3+4'].forEach(k => ok(eight.has(k), 'falta la combinación ' + k));
ok(eight.size === 6, 'el 8 debe tener exactamente 6 combinaciones');

// 3. Reglas de selección
{
  const g = new L.Game();
  ok(g.toggle(5).ok === false, 'no se puede seleccionar antes de lanzar');
  g.roll([3, 5]);                                   // suma 8
  ok(g.state === 'choosing', 'tras lanzar 8 debe poder elegir');
  ok(g.toggle(9).ok === false, '9 > 8 no se puede seleccionar');
  ok(g.toggle(5).ok, 'seleccionar 5');
  ok(g.toggle(4).ok === false, '5+4 se pasa de 8');
  ok(g.confirm() === null, 'no se confirma una suma incompleta');
  ok(g.toggle(5).ok && g.selection.length === 0, 'deseleccionar (modificar selección)');
  g.toggle(5); g.toggle(3);
  ok(g.selectionSum() === 8, 'selección 5+3');
  const removed = g.confirm();
  ok(key(removed) === '3+5', 'se abaten 3 y 5');
  ok(!g.isOpen(3) && !g.isOpen(5), '3 y 5 abatidos');
  ok(g.state === 'ready', 'vuelve a estado de lanzar');
  ok(g.score() === 45 - 8, 'puntuación = suma de levantados');
  g.roll([2, 1]);                                   // suma 3
  ok(g.toggle(3).ok === false, 'no se puede seleccionar un número abatido');
  ok(g.toggle(2).ok === true, '2 encaja (2+1)');
  ok(g.toggle(2).ok === true, 'deseleccionar 2');
  g.selection = [1, 1, 1];                          // manipulación directa: repetidos
  ok(g.confirm() === null, 'nunca se aceptan repetidos');
  g.selection = [3];                                // manipulación directa: abatido
  ok(g.confirm() === null, 'nunca se acepta un número abatido');
}

// 4. canSelect coherente: n es seleccionable ⇔ existe combinación que contiene selección ∪ {n}
{
  const rnd = mulberry32(7);
  for (let i = 0; i < 4000; i++) {
    const g = new L.Game({ rng: rnd });
    // estado aleatorio de la caja
    g.open = L.ALL.filter(() => rnd() < 0.6);
    if (!g.open.length) continue;
    g.roll();
    if (g.state !== 'choosing') { ok(!L.hasMove(g.diceSum, g.open), 'fin de partida mal detectado'); continue; }
    const all = L.combos(g.diceSum, g.open);
    // selección parcial aleatoria válida
    const c = all[Math.floor(rnd() * all.length)];
    const part = c.filter(() => rnd() < 0.5);
    part.forEach(n => ok(g.toggle(n).ok, 'selección parcial válida rechazada'));
    for (const n of L.ALL) {
      const expected = g.isOpen(n) && !part.includes(n) &&
        all.some(cc => cc.includes(n) && part.every(p => cc.includes(p)));
      ok(g.canSelect(n) === expected, `canSelect(${n}) incorrecto`);
    }
  }
}

// 5. Victoria: abatir los nueve números
{
  const g = new L.Game();
  const plan = [[[4, 5], [9]], [[4, 4], [8]], [[3, 4], [7]], [[3, 3], [6]], [[2, 3], [5]], [[2, 2], [4]], [[1, 2], [3]], [[1, 2], [1, 2]]];
  for (const [dice, sel] of plan) {
    g.roll(dice);
    sel.forEach(n => ok(g.toggle(n).ok, 'jugada de victoria rechazada'));
    ok(g.confirm() !== null, 'confirmación de victoria rechazada');
  }
  ok(g.state === 'won', 'debe reconocer la victoria');
  ok(g.score() === 0, 'victoria = puntuación 0');
  ok(g.open.length === 0, 'no quedan fichas');
  let threw = false; try { g.roll(); } catch (e) { threw = true; }
  ok(threw, 'no se puede lanzar tras ganar');
}

// 6. Simulación masiva de partidas con jugadas aleatorias (incluidas ilegales)
{
  const rnd = mulberry32(2026);
  let wins = 0, overs = 0;
  for (let i = 0; i < 30000; i++) {
    const g = new L.Game({ rng: rnd, oneDieRule: i % 2 === 1 });
    const removedAll = [];
    let guard = 0;
    while (!g.isFinished() && guard++ < 50) {
      const r = g.roll();
      ok(r.dice.every(v => v >= 1 && v <= 6), 'dado fuera de rango');
      ok(r.dice.length === g.diceCount() || r.dice.length === (g.open.some(n => n >= 7) || !g.oneDieRule ? 2 : 1), 'nº de dados');
      if (g.state === 'over') { ok(!L.hasMove(r.sum, g.open), 'fin falso'); break; }
      ok(L.hasMove(r.sum, g.open), 'debería haber jugada');
      // intentos ilegales aleatorios
      for (let k = 0; k < 4; k++) {
        const n = 1 + Math.floor(rnd() * 9);
        const before = g.selection.slice();
        const res = g.toggle(n);
        if (!res.ok) ok(key(before) === key(g.selection), 'un intento ilegal modificó la selección');
      }
      ok(g.selectionSum() <= g.diceSum, 'la selección nunca supera la suma');
      g.clearSelection();
      const all = L.combos(r.sum, g.open);
      const c = all[Math.floor(rnd() * all.length)];
      c.forEach(n => ok(g.toggle(n).ok, 'combinación válida rechazada'));
      const removed = g.confirm();
      ok(removed && key(removed) === key(c), 'confirmación incorrecta');
      removed.forEach(n => { ok(!removedAll.includes(n), 'número abatido dos veces'); removedAll.push(n); });
      ok(g.score() === L.sum(g.open), 'puntuación incoherente');
      ok(L.sum(removedAll) + g.score() === 45, 'la suma total debe ser 45');
    }
    if (g.state === 'won') { wins++; ok(g.score() === 0 && g.open.length === 0, 'victoria incoherente'); }
    else { overs++; ok(g.score() > 0, 'fin de partida con puntuación 0'); }
  }
  ok(wins > 0 && overs > 0, 'deben darse victorias y derrotas');
  console.log(`  simulación: ${wins} victorias perfectas y ${overs} partidas terminadas en 30.000 partidas`);
}

// 7. Regla opcional de un dado
{
  const g = new L.Game({ oneDieRule: true });
  ok(g.diceCount() === 2, 'al principio, dos dados');
  g.open = [1, 2, 3];
  ok(g.diceCount() === 1, 'con 7-8-9 abatidos, un dado');
  g.roll([1]);
  ok(g.state === 'choosing' && g.diceSum === 1, 'suma 1 con un dado');
  const g2 = new L.Game();
  g2.open = [1];
  ok(g2.diceCount() === 2, 'sin la regla, siempre dos dados');
  g2.roll([1, 1]);
  ok(g2.state === 'over', 'solo queda el 1 y sale 2: fin');
}

// 8. Reinicio sin errores
{
  const g = new L.Game();
  g.roll([6, 6]); g.toggle(9); g.toggle(3); g.confirm();
  g.reset();
  ok(g.open.length === 9 && g.state === 'ready' && g.selection.length === 0 && g.diceSum === null, 'reinicio limpio');
  ok(g.score() === 45, 'puntuación inicial 45');
}

// 9. Estadísticas y récord
{
  let st = S.DEFAULT_STATS;
  let r = S.recordGame(st, 12); st = r.stats; ok(r.newRecord && st.best === 12, 'primer récord');
  r = S.recordGame(st, 20); st = r.stats; ok(!r.newRecord && st.best === 12, 'no es récord');
  r = S.recordGame(st, 0); st = r.stats; ok(r.newRecord && st.best === 0 && st.perfect === 1, 'victoria perfecta');
  ok(st.played === 3 && st.totalScore === 32, 'acumulados');
  ok(Math.abs(S.average(st) - 32 / 3) < 1e-9, 'media');
  ok(S.average(S.DEFAULT_STATS) === null, 'media sin partidas');
  ok(S.DEFAULT_STATS.played === 0, 'los valores por defecto no se modifican');
}

console.log(`OK — ${passed} comprobaciones superadas.`);
